# GitHub Setup Guide for NEXUS Z4

Complete guide for building NEXUS Z4 using GitHub Actions and installing on your Android device.

## Table of Contents
1. [Quick Start](#quick-start)
2. [Setting Up GitHub Repository](#setting-up-github-repository)
3. [Configuring Secrets](#configuring-secrets)
4. [Running Builds](#running-builds)
5. [Installing on Device](#installing-on-device)
6. [Troubleshooting](#troubleshooting)

## Quick Start

### 1. Fork/Create Repository

```bash
# Option 1: Fork this repository (if it exists)
# Click "Fork" button on GitHub

# Option 2: Create new repository and push
gh repo create NEXUS-Z4 --public
cd /path/to/NEXUS-Z4
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/NEXUS-Z4.git
git push -u origin main
```

### 2. Trigger Build

Go to **Actions** → **Build NEXUS Z4** → **Run workflow**

### 3. Download APK

After build completes, download from **Artifacts** section

### 4. Install on Device

```bash
adb install nexus-z4-debug.apk
```

---

## Setting Up GitHub Repository

### Step 1: Create Repository

1. Go to https://github.com/new
2. Name: `NEXUS-Z4`
3. Visibility: Public (or Private)
4. Initialize with README: No
5. Click **Create repository**

### Step 2: Upload Source Code

#### Option A: Using Git Command Line

```bash
cd /path/to/NEXUS-Z4

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: NEXUS Z4 Sovereign AI"

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/NEXUS-Z4.git

# Push
git push -u origin main
```

#### Option B: Using GitHub Web Interface

1. Download NEXUS-Z4 folder as ZIP
2. Extract on your computer
3. Drag and drop files into GitHub repository
4. Commit changes

#### Option C: Using GitHub Desktop

1. Download GitHub Desktop: https://desktop.github.com/
2. Add local repository
3. Select NEXUS-Z4 folder
4. Publish to GitHub

---

## Configuring Secrets (For Release Builds)

### Step 1: Generate Signing Key

On your computer (not on Android):

```bash
# Generate keystore
keytool -genkey -v \
  -keystore nexus-z4-release.keystore \
  -alias nexusz4 \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

# Convert to base64 for GitHub
base64 nexus-z4-release.keystore > keystore.base64
```

### Step 2: Add Secrets to GitHub

1. Go to your repository on GitHub
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Add these secrets:

| Secret Name | Value |
|-------------|-------|
| `KEYSTORE_BASE64` | Content of `keystore.base64` file |
| `KEYSTORE_PASSWORD` | Your keystore password |
| `KEY_ALIAS` | `nexusz4` (or your alias) |
| `KEY_PASSWORD` | Your key password |

### Step 3: Optional Secrets

| Secret Name | Purpose |
|-------------|---------|
| `DISCORD_WEBHOOK` | For build notifications |

---

## Running Builds

### Automatic Builds

Builds trigger automatically on:
- Push to `main` or `develop` branches
- Pull requests to `main`
- Every night at 2 AM UTC (nightly builds)

### Manual Builds

#### Build Debug APK

1. Go to **Actions** tab
2. Click **Build NEXUS Z4**
3. Click **Run workflow**
4. Select branch (usually `main`)
5. Build type: `debug`
6. Click **Run workflow**

#### Build Release APK

1. Go to **Actions** tab
2. Click **Build NEXUS Z4**
3. Click **Run workflow**
4. Select branch
5. Build type: `release`
6. Click **Run workflow**

#### Create Release

1. Go to **Actions** tab
2. Click **Create Release**
3. Click **Run workflow**
4. Enter version (e.g., `1.0.0`)
5. Click **Run workflow**

Or push a tag:

```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

---

## Installing on Device

### Method 1: Direct Download (Recommended)

1. Open GitHub Actions build page
2. Wait for build to complete (5-15 minutes)
3. Scroll to **Artifacts** section
4. Click on APK file to download
5. Transfer to Android device
6. Install:
   ```bash
   adb install nexus-z4-debug.apk
   ```

### Method 2: Using GitHub CLI

```bash
# Install gh CLI on your computer
# https://cli.github.com/

# Login
ght auth login

# Download latest artifact
gh run download --repo YOUR_USERNAME/NEXUS-Z4 \
  --name nexus-z4-debug-LATEST

# Install
adb install nexus-z4-debug.apk
```

### Method 3: Using Termux on Device

```bash
# Install Termux from F-Droid
pkg install -y gh

# Login to GitHub
gh auth login

# Download latest build
cd ~/Downloads
gh run download --repo YOUR_USERNAME/NEXUS-Z4 \
  --name nexus-z4-debug-$(gh run list --repo YOUR_USERNAME/NEXUS-Z4 --workflow build.yml --json databaseId -q '.[0].databaseId')

# Install
pm install -r nexus-z4-debug.apk
```

### Method 4: QR Code Download

1. Get download URL from GitHub Actions artifact
2. Generate QR code: https://qr-code-generator.com/
3. Scan with Android device
4. Download and install

---

## Downloading Models

After installing NEXUS Z4, you need to download a GGUF model:

### Option 1: Direct Download on Device

```bash
# Using Termux
mkdir -p /sdcard/Android/data/com.nexusz4/files/models/

# Download Mistral 7B (4.1GB)
cd /sdcard/Android/data/com.nexusz4/files/models/
wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf

# Or download smaller Phi-3 Mini (2.3GB)
wget https://huggingface.co/TheBloke/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct.Q4_K_M.gguf
```

### Option 2: Transfer from Computer

```bash
# On computer
adb push mistral-7b-instruct-v0.2.Q4_K_M.gguf \
  /sdcard/Android/data/com.nexusz4/files/models/
```

### Option 3: Download via Browser

1. Open browser on Android
2. Go to: https://huggingface.co/TheBloke
3. Find desired model
4. Download GGUF file (Q4_K_M recommended)
5. Move to `/sdcard/Android/data/com.nexusz4/files/models/`

---

## Build Status Badge

Add this to your README.md:

```markdown
[![Build Status](https://github.com/YOUR_USERNAME/NEXUS-Z4/workflows/Build%20NEXUS%20Z4/badge.svg)](https://github.com/YOUR_USERNAME/NEXUS-Z4/actions)
[![Release](https://img.shields.io/github/v/release/YOUR_USERNAME/NEXUS-Z4)](https://github.com/YOUR_USERNAME/NEXUS-Z4/releases)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
```

---

## Troubleshooting

### Build Fails with "NDK not found"

**Solution:** The workflow installs NDK automatically. If it fails:

1. Check GitHub Actions logs
2. Re-run the workflow
3. Or update NDK version in workflow file

### Build Times Out

**Solution:** 
- GitHub Actions has 6-hour limit
- Native builds can take 30-60 minutes
- If timeout occurs, re-run the job

### APK Won't Install

**Solution:**
```bash
# Check for existing installation
adb shell pm list packages | grep nexusz4

# Uninstall if exists
adb uninstall com.nexusz4

# Reinstall
adb install -r nexus-z4-debug.apk
```

### "App not installed" Error

**Causes:**
- Incompatible Android version (need API 28+)
- Corrupted APK (re-download)
- Storage full (free up space)

### Model Won't Load

**Check:**
1. Model file exists in correct location
2. File is not corrupted (check MD5)
3. Sufficient RAM available (6GB+)

---

## Advanced: Custom Build Configuration

### Modify Build Settings

Edit `.github/workflows/build.yml`:

```yaml
# Change Java version
env:
  JAVA_VERSION: '17'  # or '21'

# Change Android API
  ANDROID_API_LEVEL: '34'

# Change NDK version
  NDK_VERSION: '25.2.9519653'
```

### Add Custom Build Steps

```yaml
- name: Custom Step
  run: |
    echo "Running custom build step"
    # Your commands here
```

### Schedule Different Builds

```yaml
on:
  schedule:
    # Every Monday at 9 AM
    - cron: '0 9 * * 1'
    # Every day at midnight
    - cron: '0 0 * * *'
```

---

## Monitoring Builds

### GitHub Actions Notifications

1. Go to **Settings** → **Notifications**
2. Enable "Actions" notifications
3. Choose email or web notifications

### Discord Notifications

1. Create Discord webhook
2. Add `DISCORD_WEBHOOK` secret
3. Builds will notify on failure

---

## Next Steps

1. ✅ Set up GitHub repository
2. ✅ Configure secrets (for releases)
3. ✅ Trigger first build
4. ✅ Download and install APK
5. ✅ Download GGUF model
6. ✅ Enjoy NEXUS Z4!

---

## Support

- **Build Issues:** Check Actions logs
- **Install Issues:** Check ADB connection
- **Runtime Issues:** Check logcat

```bash
# View device logs
adb logcat -s "NEXUS-Z4:*"
```

---

**Happy building! 🚀**
