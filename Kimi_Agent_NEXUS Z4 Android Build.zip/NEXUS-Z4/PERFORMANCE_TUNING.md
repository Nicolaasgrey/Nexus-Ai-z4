# NEXUS Z4 Performance Tuning Guide

This guide provides detailed instructions for optimizing NEXUS Z4 performance on the Samsung Galaxy Z Flip 4 (Snapdragon 8+ Gen 1, 8GB RAM).

## Table of Contents
1. [Hardware Optimization](#hardware-optimization)
2. [Model Selection](#model-selection)
3. [Memory Management](#memory-management)
4. [GPU Acceleration](#gpu-acceleration)
5. [Cognitive Scaling](#cognitive-scaling)
6. [Battery Optimization](#battery-optimization)
7. [Thermal Management](#thermal-management)
8. [Troubleshooting](#troubleshooting)

## Hardware Optimization

### Snapdragon 8+ Gen 1 Specific Settings

```kotlin
// Optimal settings for Snapdragon 8+ Gen 1
val modelConfig = ModelConfig(
    contextSize = 4096,      // Maximum for 8GB RAM
    batchSize = 512,         // Balanced throughput
    useGpu = true,           // Enable Adreno GPU
    gpuLayers = 35,          // Offload ~70% to GPU
    threads = 4              // Use 4 CPU threads
)
```

### RAM Allocation

| Component | Recommended | Maximum |
|-----------|-------------|---------|
| Model (7B Q4) | 4.5 GB | 5.5 GB |
| KV Cache | 512 MB | 1 GB |
| Vector DB | 256 MB | 512 MB |
| App Overhead | 512 MB | 1 GB |
| **Total** | **~6 GB** | **~8 GB** |

## Model Selection

### Performance Comparison

| Model | Size | Tokens/sec | Quality | Best For |
|-------|------|------------|---------|----------|
| Mistral 7B Q4_K_M | 4.1 GB | 15-20 | ★★★★★ | General use |
| Llama 3 8B Q4_K_M | 4.9 GB | 12-16 | ★★★★★ | Reasoning |
| Phi-3 Mini Q4 | 2.3 GB | 25-30 | ★★★★☆ | Speed |
| Qwen2 7B Q4 | 4.4 GB | 14-18 | ★★★★☆ | Multilingual |
| Gemma 2B Q4 | 1.6 GB | 35-40 | ★★★☆☆ | Constrained |

### Model Download URLs

```bash
# Mistral 7B (Recommended)
wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf

# Llama 3 8B
wget https://huggingface.co/TheBloke/Meta-Llama-3-8B-Instruct-GGUF/resolve/main/Meta-Llama-3-8B-Instruct.Q4_K_M.gguf

# Phi-3 Mini
wget https://huggingface.co/TheBloke/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct.Q4_K_M.gguf
```

## Memory Management

### Chunking Configuration

```kotlin
// For 8GB RAM devices
val memoryConfig = MemoryConfig(
    chunkSize = 512,           // Tokens per chunk
    chunkOverlap = 128,        // 25% overlap
    maxRetrievalResults = 5,   // Max memories per query
    similarityThreshold = 0.7f // Minimum relevance
)
```

### Vector Database Tuning

```kotlin
// FAISS parameters
vectorDatabase.initialize(
    indexPath = "...",
    dimension = 384,           // MiniLM embeddings
    nlist = 100,               // IVF clusters
    nprobe = 10                // Search probes
)
```

### Memory Cleanup Triggers

```kotlin
// Automatic cleanup at 80% RAM
when (ramUsagePercent) {
    in 80.0..90.0 -> scaleDown()
    in 90.0..100.0 -> emergencyReduce()
}
```

## GPU Acceleration

### Vulkan Configuration

```kotlin
// Enable Vulkan for Adreno 730
val vulkanConfig = mapOf(
    "GGML_VULKAN_CHECK_RESULTS" to "0",
    "GGML_VULKAN_DEBUG" to "0",
    "GGML_VULKAN_MEMORY_DEBUG" to "0",
    "GGML_VULKAN_PERF" to "0"
)
```

### GPU Layer Offloading

| GPU Layers | VRAM Used | CPU Load | Speed |
|------------|-----------|----------|-------|
| 0 | 0 GB | 100% | Baseline |
| 15 | 1.5 GB | 70% | +30% |
| 25 | 2.5 GB | 50% | +50% |
| 35 | 3.5 GB | 30% | +70% |
| All | 4.5 GB | 10% | +90% |

### Optimal GPU Settings

```kotlin
// For Snapdragon 8+ Gen 1 with Adreno 730
val gpuConfig = GpuConfig(
    layers = 35,               // Sweet spot
    splitMode = LAYER_SPLIT,   // Even distribution
    mainGpu = 0,               // Primary GPU
    tensorSplit = floatArrayOf(1.0f)
)
```

## Cognitive Scaling

### Level Definitions

| Level | Condition | Max Tokens | Reflection | Critic |
|-------|-----------|------------|------------|--------|
| 0 | RAM > 90% | 512 | No | No |
| 1 | RAM > 80% | 1024 | No | No |
| 2 | Normal | 2048 | Yes | No |
| 3 | RAM < 70% | 3072 | Yes | Yes |
| 4 | Optimal | 4096 | Yes | Yes |

### Dynamic Scaling

```kotlin
// Automatic adjustment based on metrics
fun updateCognitiveLevel(metrics: SystemMetrics): Int {
    var level = 2  // Default
    
    // RAM impact
    level -= when {
        metrics.ramUsedPercent >= 90 -> 2
        metrics.ramUsedPercent >= 80 -> 1
        else -> 0
    }
    
    // Battery impact
    level -= when {
        metrics.batteryPercent <= 10 -> 2
        metrics.batteryPercent <= 20 -> 1
        else -> 0
    }
    
    // Temperature impact
    level -= when {
        metrics.batteryTemperature >= 50 -> 2
        metrics.batteryTemperature >= 45 -> 1
        else -> 0
    }
    
    return level.coerceIn(0, 4)
}
```

## Battery Optimization

### Power-Aware Settings

```kotlin
// Reduce GPU usage when unplugged
val useGpu = when {
    isCharging -> true
    batteryPercent > 50 -> true
    else -> false
}

// Reduce max tokens on low battery
val maxTokens = when {
    batteryPercent < 20 -> 512
    batteryPercent < 50 -> 1024
    else -> 2048
}
```

### Background Processing

```kotlin
// Use WorkManager for battery-efficient tasks
val constraints = Constraints.Builder()
    .setRequiresBatteryNotLow(true)
    .setRequiresCharging(false)
    .build()

val workRequest = OneTimeWorkRequestBuilder<EmbeddingWorker>()
    .setConstraints(constraints)
    .build()
```

## Thermal Management

### Temperature Thresholds

| Temperature | Action |
|-------------|--------|
| < 40°C | Optimal - full performance |
| 40-45°C | Monitor - reduce GPU layers |
| 45-50°C | Warning - disable GPU |
| > 50°C | Critical - minimal mode |

### Thermal Throttling

```kotlin
fun handleThermalState(temperature: Float) {
    when {
        temperature >= 50f -> {
            disableGpu()
            setCognitiveLevel(0)
        }
        temperature >= 45f -> {
            reduceGpuLayers(15)
            setCognitiveLevel(1)
        }
        temperature >= 40f -> {
            monitorClosely()
        }
    }
}
```

## Troubleshooting

### Common Issues

#### 1. Model Fails to Load
```
Symptom: "Failed to load model" error
Cause: Insufficient memory or corrupted file
Solution:
- Check available RAM (need 6GB free)
- Verify GGUF file integrity
- Try smaller model (Phi-3 Mini)
```

#### 2. Slow Token Generation
```
Symptom: < 5 tokens/second
Cause: Running on CPU only or thermal throttling
Solution:
- Enable GPU acceleration
- Check temperature
- Reduce context size
- Close background apps
```

#### 3. App Crashes During Generation
```
Symptom: App closes unexpectedly
Cause: Out of memory
Solution:
- Reduce maxTokens
- Lower gpuLayers
- Clear memory cache
- Restart app
```

#### 4. High Battery Drain
```
Symptom: Battery drops rapidly
Cause: Continuous GPU usage
Solution:
- Disable GPU when unplugged
- Reduce generation frequency
- Use power save mode
```

### Performance Monitoring

```kotlin
// Log performance metrics
Timber.d("""
    Performance Stats:
    - Tokens/sec: $tokensPerSecond
    - RAM: ${ramUsedPercent}%
    - CPU: ${cpuUsagePercent}%
    - GPU: ${gpuUsagePercent}%
    - Temp: ${batteryTemperature}°C
    - Battery: ${batteryPercent}%
""")
```

### Benchmarking

Run these commands to measure performance:

```bash
# Token generation speed
adb shell am start -a android.intent.action.MAIN \
    -n com.nexusz4/.ui.MainActivity \
    --es "benchmark" "tokenspeed"

# Memory usage
adb shell dumpsys meminfo com.nexusz4

# CPU/GPU usage
adb shell top -p $(adb shell pidof com.nexusz4) -m 10
```

## Recommended Settings Summary

### Samsung Galaxy Z Flip 4 Optimal Config

```kotlin
val optimalConfig = NexusConfig(
    model = ModelPreset.MISTRAL_7B_Q4,
    modelConfig = ModelConfig(
        contextSize = 4096,
        batchSize = 512,
        useGpu = true,
        gpuLayers = 35
    ),
    generationConfig = GenerationConfig(
        temperature = 0.7f,
        topP = 0.9f,
        maxTokens = 2048
    ),
    memoryConfig = MemoryConfig(
        chunkSize = 512,
        maxRetrievalResults = 5
    ),
    cognitiveScaling = true,
    powerOptimization = true
)
```

### Expected Performance

| Metric | Target | Acceptable |
|--------|--------|------------|
| Token Speed | 15-20 t/s | 10+ t/s |
| RAM Usage | < 6 GB | < 7 GB |
| Temperature | < 45°C | < 50°C |
| Battery/Hour | < 15% | < 25% |

---

For additional support, refer to the main README.md or open an issue on GitHub.
