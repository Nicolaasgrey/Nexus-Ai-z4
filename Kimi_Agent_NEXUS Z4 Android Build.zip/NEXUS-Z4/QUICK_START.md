# NEXUS Z4 Quick Start Guide

Get up and running with NEXUS Z4 in 5 minutes.

## Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- NDK 25.2.9519653
- Samsung Galaxy Z Flip 4 (or similar Android 14 device)
- 10GB free storage

## Step 1: Download Models

Download a GGUF model and place it on your device:

```bash
# Option 1: Mistral 7B (Recommended, 4.1GB)
wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf

# Option 2: Phi-3 Mini (Faster, 2.3GB)
wget https://huggingface.co/TheBloke/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct.Q4_K_M.gguf
```

Transfer to device:
```bash
adb shell mkdir -p /sdcard/Android/data/com.nexusz4/files/models/
adb push mistral-7b-instruct-v0.2.Q4_K_M.gguf /sdcard/Android/data/com.nexusz4/files/models/
```

## Step 2: Build the App

```bash
# Clone repository
git clone <repository-url>
cd NEXUS-Z4

# Build debug APK
./gradlew assembleDebug

# Install to device
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Step 3: First Launch

1. Open NEXUS Z4 app
2. Tap **System** tab
3. Tap **Load Model**
4. Select your downloaded model
5. Wait for model to load (~30-60 seconds)

## Step 4: Start Chatting

1. Go to **Chat** tab
2. Type your message
3. Tap send button
4. Watch the AI respond!

## Basic Usage

### Chat Features
- **Memory Toggle**: Enable/disable RAG memory retrieval
- **Settings**: Adjust temperature (creativity) and top-p
- **New Chat**: Start fresh conversation
- **Stop**: Cancel ongoing generation

### Memory Management
- Upload PDFs, TXT, or Markdown files
- Memories are automatically chunked and embedded
- Semantic search retrieves relevant context

### Skill System
- Skills auto-activate based on keywords
- View performance metrics (SPI score)
- Enable/disable skills as needed

### System Monitor
- Real-time RAM, CPU, battery metrics
- Cognitive scaling level indicator
- Model information and controls

## Tips for Best Performance

1. **Keep device charged** - GPU acceleration works best when plugged in
2. **Close background apps** - Free up RAM for the model
3. **Use smaller models** - Phi-3 Mini is faster than Mistral 7B
4. **Monitor temperature** - App scales down if device gets hot
5. **Enable memory** - RAG significantly improves response quality

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Model won't load | Check file path, verify GGUF format |
| Slow responses | Enable GPU, reduce max tokens, close apps |
| App crashes | Clear data, restart, check available RAM |
| High battery drain | Disable GPU when unplugged |
| Poor responses | Enable memory, adjust temperature |

## Keyboard Shortcuts

None (touch interface only)

## Next Steps

- Read [PERFORMANCE_TUNING.md](PERFORMANCE_TUNING.md) for optimization
- Explore [README.md](README.md) for full documentation
- Check GitHub issues for known problems

## Support

- GitHub Issues: Report bugs and request features
- Documentation: See README.md for full details

---

**Enjoy your sovereign AI assistant!**
