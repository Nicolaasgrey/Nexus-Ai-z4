#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <android/log.h>

// llama.cpp headers
#include "llama.h"

#define LOG_TAG "llama-android"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Context wrapper for managing llama state
struct LlamaContextWrapper {
    llama_model* model = nullptr;
    llama_context* ctx = nullptr;
    bool generating = false;
    bool should_stop = false;
    std::mutex mutex;
};

// Global context map (in production, use proper management)
static std::vector<std::unique_ptr<LlamaContextWrapper>> g_contexts;
static std::mutex g_contexts_mutex;

extern "C" {

// Helper to get wrapper from pointer
static LlamaContextWrapper* get_wrapper(jlong ptr) {
    if (ptr <= 0 || ptr > static_cast<jlong>(g_contexts.size())) {
        return nullptr;
    }
    return g_contexts[static_cast<size_t>(ptr) - 1].get();
}

JNIEXPORT jlong JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_loadModel(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring model_path,
    jint context_size,
    jint gpu_layers,
    jint batch_size
) {
    const char* path = env->GetStringUTFChars(model_path, nullptr);
    LOGI("Loading model: %s", path);

    // Initialize llama backend
    llama_backend_init();

    // Model parameters
    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = gpu_layers;
    model_params.main_gpu = 0;

    // Load model
    llama_model* model = llama_load_model_from_file(path, model_params);
    env->ReleaseStringUTFChars(model_path, path);

    if (!model) {
        LOGE("Failed to load model");
        return 0;
    }

    // Context parameters
    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = context_size;
    ctx_params.n_batch = batch_size;
    ctx_params.n_threads = 4;
    ctx_params.n_threads_batch = 4;

    // Create context
    llama_context* ctx = llama_new_context_with_model(model, ctx_params);
    if (!ctx) {
        LOGE("Failed to create context");
        llama_free_model(model);
        return 0;
    }

    // Create wrapper
    auto wrapper = std::make_unique<LlamaContextWrapper>();
    wrapper->model = model;
    wrapper->ctx = ctx;

    std::lock_guard<std::mutex> lock(g_contexts_mutex);
    g_contexts.push_back(std::move(wrapper));
    jlong ptr = static_cast<jlong>(g_contexts.size());

    LOGI("Model loaded successfully, context ptr: %ld", ptr);
    return ptr;
}

JNIEXPORT void JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_unloadModel(
    JNIEnv* /*env*/,
    jobject /*thiz*/,
    jlong context_ptr
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (!wrapper) return;

    std::lock_guard<std::mutex> lock(wrapper->mutex);

    if (wrapper->ctx) {
        llama_free(wrapper->ctx);
        wrapper->ctx = nullptr;
    }
    if (wrapper->model) {
        llama_free_model(wrapper->model);
        wrapper->model = nullptr;
    }

    LOGI("Model unloaded, context ptr: %ld", context_ptr);
}

JNIEXPORT void JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_generate(
    JNIEnv* env,
    jobject thiz,
    jlong context_ptr,
    jstring prompt,
    jfloat temperature,
    jfloat top_p,
    jint max_tokens,
    jfloat repeat_penalty,
    jobject callback
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (!wrapper) {
        LOGE("Invalid context pointer");
        return;
    }

    std::lock_guard<std::mutex> lock(wrapper->mutex);
    wrapper->generating = true;
    wrapper->should_stop = false;

    const char* prompt_str = env->GetStringUTFChars(prompt, nullptr);
    std::string prompt_text(prompt_str);
    env->ReleaseStringUTFChars(prompt, prompt_str);

    // Tokenize prompt
    const int n_prompt_tokens = -llama_tokenize(
        wrapper->model,
        prompt_text.c_str(),
        prompt_text.length(),
        nullptr,
        0,
        true,
        true
    );

    std::vector<llama_token> prompt_tokens(n_prompt_tokens);
    llama_tokenize(
        wrapper->model,
        prompt_text.c_str(),
        prompt_text.length(),
        prompt_tokens.data(),
        prompt_tokens.size(),
        true,
        true
    );

    // Evaluate prompt
    llama_decode_init(wrapper->ctx);
    
    for (size_t i = 0; i < prompt_tokens.size(); i += 512) {
        size_t batch_size = std::min(size_t(512), prompt_tokens.size() - i);
        llama_batch batch = llama_batch_init(batch_size, 0, 1);
        
        for (size_t j = 0; j < batch_size; j++) {
            batch.token[j] = prompt_tokens[i + j];
            batch.pos[j] = i + j;
            batch.n_seq_id[j] = 1;
            batch.seq_id[j][0] = 0;
            batch.logits[j] = 0;
        }
        batch.logits[batch_size - 1] = 1;
        batch.n_tokens = batch_size;

        llama_decode(wrapper->ctx, batch);
        llama_batch_free(batch);
    }

    // Generation loop
    llama_token new_token_id;
    int n_generated = 0;

    // Get callback method
    jclass callback_class = env->GetObjectClass(callback);
    jmethodID on_token_method = env->GetMethodID(
        callback_class,
        "onToken",
        "(Ljava/lang/String;)Z"
    );

    while (n_generated < max_tokens && !wrapper->should_stop) {
        // Sample next token
        llama_token_data_array candidates;
        // ... sampling logic would go here

        new_token_id = llama_sample_token_greedy(wrapper->ctx, nullptr);

        // Check for end of generation
        if (llama_token_is_eog(wrapper->model, new_token_id)) {
            break;
        }

        // Convert token to string
        char token_buf[256];
        int n_chars = llama_token_to_piece(
            wrapper->model,
            new_token_id,
            token_buf,
            sizeof(token_buf),
            0,
            true
        );

        if (n_chars > 0) {
            std::string token_str(token_buf, n_chars);
            jstring jtoken = env->NewStringUTF(token_str.c_str());
            
            jboolean should_continue = env->CallBooleanMethod(
                callback,
                on_token_method,
                jtoken
            );
            
            env->DeleteLocalRef(jtoken);

            if (!should_continue) {
                break;
            }
        }

        // Evaluate the new token
        llama_batch batch = llama_batch_init(1, 0, 1);
        batch.token[0] = new_token_id;
        batch.pos[0] = prompt_tokens.size() + n_generated;
        batch.n_seq_id[0] = 1;
        batch.seq_id[0][0] = 0;
        batch.logits[0] = 1;
        batch.n_tokens = 1;

        llama_decode(wrapper->ctx, batch);
        llama_batch_free(batch);

        n_generated++;
    }

    wrapper->generating = false;
    LOGI("Generation complete: %d tokens", n_generated);
}

JNIEXPORT void JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_stopGeneration(
    JNIEnv* /*env*/,
    jobject /*thiz*/,
    jlong context_ptr
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (wrapper) {
        wrapper->should_stop = true;
        LOGI("Stop generation requested");
    }
}

JNIEXPORT jobject JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_getModelInfo(
    JNIEnv* env,
    jobject /*thiz*/,
    jlong context_ptr
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (!wrapper || !wrapper->model) {
        return nullptr;
    }

    // Create HashMap
    jclass hashmap_class = env->FindClass("java/util/HashMap");
    jmethodID hashmap_init = env->GetMethodID(hashmap_class, "<init>", "()V");
    jobject hashmap = env->NewObject(hashmap_class, hashmap_init);
    jmethodID hashmap_put = env->GetMethodID(
        hashmap_class,
        "put",
        "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
    );

    // Add model info
    const llama_model_desc* desc = llama_model_get_desc(wrapper->model);
    
    jstring key_vocab = env->NewStringUTF("vocab_size");
    jint vocab_size = llama_n_vocab(wrapper->model);
    env->CallObjectMethod(hashmap, hashmap_put, key_vocab, 
        env->NewObject(env->FindClass("java/lang/Integer"),
            env->GetMethodID(env->FindClass("java/lang/Integer"), "<init>", "(I)V"),
            vocab_size));

    jstring key_ctx = env->NewStringUTF("context_size");
    jint ctx_size = llama_n_ctx_train(wrapper->model);
    env->CallObjectMethod(hashmap, hashmap_put, key_ctx,
        env->NewObject(env->FindClass("java/lang/Integer"),
            env->GetMethodID(env->FindClass("java/lang/Integer"), "<init>", "(I)V"),
            ctx_size));

    jstring key_layers = env->NewStringUTF("layer_count");
    jint layers = llama_n_layer(wrapper->model);
    env->CallObjectMethod(hashmap, hashmap_put, key_layers,
        env->NewObject(env->FindClass("java/lang/Integer"),
            env->GetMethodID(env->FindClass("java/lang/Integer"), "<init>", "(I)V"),
            layers));

    return hashmap;
}

JNIEXPORT jintArray JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_tokenize(
    JNIEnv* env,
    jobject /*thiz*/,
    jlong context_ptr,
    jstring text
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (!wrapper || !wrapper->model) {
        return nullptr;
    }

    const char* text_str = env->GetStringUTFChars(text, nullptr);
    
    const int n_tokens = -llama_tokenize(
        wrapper->model,
        text_str,
        strlen(text_str),
        nullptr,
        0,
        true,
        true
    );

    std::vector<llama_token> tokens(n_tokens);
    llama_tokenize(
        wrapper->model,
        text_str,
        strlen(text_str),
        tokens.data(),
        tokens.size(),
        true,
        true
    );

    env->ReleaseStringUTFChars(text, text_str);

    jintArray result = env->NewIntArray(n_tokens);
    env->SetIntArrayRegion(result, 0, n_tokens, tokens.data());
    return result;
}

JNIEXPORT jint JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_countTokens(
    JNIEnv* env,
    jobject /*thiz*/,
    jlong context_ptr,
    jstring text
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (!wrapper || !wrapper->model) {
        return 0;
    }

    const char* text_str = env->GetStringUTFChars(text, nullptr);
    
    const int n_tokens = -llama_tokenize(
        wrapper->model,
        text_str,
        strlen(text_str),
        nullptr,
        0,
        true,
        true
    );

    env->ReleaseStringUTFChars(text, text_str);
    return n_tokens;
}

JNIEXPORT jboolean JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_isGenerating(
    JNIEnv* /*env*/,
    jobject /*thiz*/,
    jlong context_ptr
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    return wrapper ? wrapper->generating : false;
}

JNIEXPORT void JNICALL
Java_com_nexusz4_core_LlamaNativeBridge_resetContext(
    JNIEnv* /*env*/,
    jobject /*thiz*/,
    jlong context_ptr
) {
    LlamaContextWrapper* wrapper = get_wrapper(context_ptr);
    if (wrapper && wrapper->ctx) {
        llama_kv_cache_clear(wrapper->ctx);
        LOGI("Context reset");
    }
}

} // extern "C"
