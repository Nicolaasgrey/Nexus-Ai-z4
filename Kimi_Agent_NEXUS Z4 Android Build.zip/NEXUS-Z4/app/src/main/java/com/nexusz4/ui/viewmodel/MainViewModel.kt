package com.nexusz4.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexusz4.core.LLMEngine
import com.nexusz4.core.model.*
import com.nexusz4.memory.MemoryManager
import com.nexusz4.memory.model.MemoryStats
import com.nexusz4.meta.SelfLearningEngine
import com.nexusz4.skills.SkillEngine
import com.nexusz4.skills.model.Skill
import com.nexusz4.skills.model.SkillEngineStats
import com.nexusz4.system.PerformanceMonitor
import com.nexusz4.system.SystemMetrics
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val llmEngine: LLMEngine,
    private val memoryManager: MemoryManager,
    private val skillEngine: SkillEngine,
    private val selfLearningEngine: SelfLearningEngine,
    private val performanceMonitor: PerformanceMonitor
) : ViewModel() {

    // Chat state
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _currentSession = MutableStateFlow(ChatSession.create())
    val currentSession: StateFlow<ChatSession> = _currentSession.asStateFlow()

    // Model settings
    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    private val _topP = MutableStateFlow(0.9f)
    val topP: StateFlow<Float> = _topP.asStateFlow()

    private val _maxTokens = MutableStateFlow(2048)
    val maxTokens: StateFlow<Int> = _maxTokens.asStateFlow()

    private val _memoryEnabled = MutableStateFlow(true)
    val memoryEnabled: StateFlow<Boolean> = _memoryEnabled.asStateFlow()

    // Performance metrics
    val systemMetrics: StateFlow<SystemMetrics> = performanceMonitor.metrics
    val cognitiveLevel: StateFlow<Int> = performanceMonitor.cognitiveLevel

    // Memory stats
    private val _memoryStats = MutableStateFlow<MemoryStats?>(null)
    val memoryStats: StateFlow<MemoryStats?> = _memoryStats.asStateFlow()

    // Skills
    private val _skills = MutableStateFlow<List<Skill>>(emptyList())
    val skills: StateFlow<List<Skill>> = _skills.asStateFlow()

    private val _skillStats = MutableStateFlow<SkillEngineStats?>(null)
    val skillStats: StateFlow<SkillEngineStats?> = _skillStats.asStateFlow()

    // Model info
    private val _modelLoaded = MutableStateFlow(false)
    val modelLoaded: StateFlow<Boolean> = _modelLoaded.asStateFlow()

    private val _modelInfo = MutableStateFlow<Map<String, Any>>(emptyMap())
    val modelInfo: StateFlow<Map<String, Any>> = _modelInfo.asStateFlow()

    // Available models
    val availableModels = ModelPreset.PRESETS

    init {
        // Start collecting metrics
        viewModelScope.launch {
            while (isActive) {
                _memoryStats.value = memoryManager.getStats()
                _skills.value = skillEngine.getAllSkills()
                _skillStats.value = skillEngine.getEngineStats()
                delay(5000)
            }
        }
    }

    // Chat Operations

    fun sendMessage(content: String) {
        if (content.isBlank()) return

        viewModelScope.launch {
            // Add user message
            val userMessage = ChatMessage(
                role = MessageRole.USER,
                content = content
            )
            _chatMessages.value = _chatMessages.value + userMessage
            _currentSession.value.addMessage(MessageRole.USER, content)

            _isGenerating.value = true

            try {
                // Retrieve relevant memories
                val memoryContext = if (_memoryEnabled.value) {
                    memoryManager.retrieveForContext(content, maxTokens = 1000)
                } else ""

                // Detect skills
                val activatedSkills = skillEngine.detectSkills(content)
                val skillContext = if (activatedSkills.isNotEmpty()) {
                    val topSkill = activatedSkills.first()
                    skillEngine.applySkill(topSkill.skill, content)
                } else null

                // Build prompt
                val prompt = buildPrompt(content, memoryContext, skillContext)

                // Generate response
                val config = GenerationConfig(
                    temperature = _temperature.value,
                    topP = _topP.value,
                    maxTokens = _maxTokens.value.coerceAtMost(
                        performanceMonitor.getRecommendedMaxTokens()
                    )
                )

                val responseBuilder = StringBuilder()

                llmEngine.generateStream(prompt, config)
                    .collect { token ->
                        responseBuilder.append(token)
                    }

                val responseText = responseBuilder.toString().trim()

                // Add assistant message
                val assistantMessage = ChatMessage(
                    role = MessageRole.ASSISTANT,
                    content = responseText
                )
                _chatMessages.value = _chatMessages.value + assistantMessage
                _currentSession.value.addMessage(MessageRole.ASSISTANT, responseText)

                // Store conversation in memory
                if (_memoryEnabled.value) {
                    memoryManager.storeMemory(
                        content = "User: $content\nAssistant: $responseText",
                        type = com.nexusz4.memory.model.MemoryType.CONVERSATION,
                        domain = "general"
                    )
                }

                // Update skill performance if applicable
                activatedSkills.firstOrNull()?.let { activation ->
                    // Calculate a simple response score
                    val score = (responseText.length.toFloat() / 1000f).coerceIn(0f, 1f)
                    skillEngine.updateSkillPerformance(activation.skill.id, score)
                }

            } catch (e: Exception) {
                Timber.e(e, "Failed to generate response")
                val errorMessage = ChatMessage(
                    role = MessageRole.ASSISTANT,
                    content = "I apologize, but I encountered an error: ${e.message}",
                    metadata = mapOf("error" to "true")
                )
                _chatMessages.value = _chatMessages.value + errorMessage
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        llmEngine.stopGeneration()
        _isGenerating.value = false
    }

    fun clearChat() {
        _chatMessages.value = emptyList()
        _currentSession.value = ChatSession.create()
    }

    fun newChat() {
        clearChat()
    }

    // Model Operations

    fun loadModel(modelPath: String) {
        viewModelScope.launch {
            _modelLoaded.value = false
            val result = llmEngine.loadModel(modelPath)
            if (result.isSuccess) {
                _modelLoaded.value = true
                _modelInfo.value = llmEngine.getModelInfo()
            }
        }
    }

    fun unloadModel() {
        llmEngine.unloadModel()
        _modelLoaded.value = false
        _modelInfo.value = emptyMap()
    }

    // Settings

    fun setTemperature(value: Float) {
        _temperature.value = value.coerceIn(0f, 2f)
    }

    fun setTopP(value: Float) {
        _topP.value = value.coerceIn(0f, 1f)
    }

    fun setMaxTokens(value: Int) {
        _maxTokens.value = value.coerceIn(64, 8192)
    }

    fun setMemoryEnabled(enabled: Boolean) {
        _memoryEnabled.value = enabled
        memoryManager.setMemoryEnabled(enabled)
    }

    // Memory Operations

    fun refreshMemoryStats() {
        viewModelScope.launch {
            _memoryStats.value = memoryManager.getStats()
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            memoryManager.clearAll()
            refreshMemoryStats()
        }
    }

    fun rebuildMemoryIndex() {
        viewModelScope.launch {
            memoryManager.rebuildIndex()
            refreshMemoryStats()
        }
    }

    // Skill Operations

    fun refreshSkills() {
        _skills.value = skillEngine.getAllSkills()
        _skillStats.value = skillEngine.getEngineStats()
    }

    fun toggleSkill(id: String, active: Boolean) {
        viewModelScope.launch {
            skillEngine.toggleSkill(id, active)
            refreshSkills()
        }
    }

    fun deleteSkill(id: String) {
        viewModelScope.launch {
            skillEngine.deleteSkill(id)
            refreshSkills()
        }
    }

    // Private helpers

    private fun buildPrompt(
        userInput: String,
        memoryContext: String,
        skillContext: String?
    ): String {
        val builder = StringBuilder()

        // System prompt
        builder.appendLine("<|system|>")
        builder.appendLine("You are NEXUS Z4, a sovereign AI assistant operating entirely offline.")
        builder.appendLine("You prioritize precision, structured reasoning, and strategic clarity.")
        builder.appendLine("You never hallucinate unknown facts; state uncertainty clearly.")
        builder.appendLine()

        // Add memory context if available
        if (memoryContext.isNotBlank()) {
            builder.appendLine(memoryContext)
            builder.appendLine()
        }

        // Add skill context if available
        skillContext?.let {
            builder.appendLine(it)
            builder.appendLine()
        }

        builder.appendLine("</|system|>")
        builder.appendLine()

        // Add chat history
        _chatMessages.value.takeLast(10).forEach { message ->
            when (message.role) {
                MessageRole.USER -> {
                    builder.appendLine("<|user|>")
                    builder.appendLine(message.content)
                }
                MessageRole.ASSISTANT -> {
                    builder.appendLine("<|assistant|>")
                    builder.appendLine(message.content)
                }
                else -> {}
            }
        }

        // Current user input
        builder.appendLine("<|user|>")
        builder.appendLine(userInput)
        builder.appendLine("<|assistant|>")

        return builder.toString()
    }

    override fun onCleared() {
        super.onCleared()
        llmEngine.release()
    }
}
