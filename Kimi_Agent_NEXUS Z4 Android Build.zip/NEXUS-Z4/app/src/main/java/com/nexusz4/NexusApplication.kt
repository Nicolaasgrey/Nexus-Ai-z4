package com.nexusz4

import android.app.Application
import android.content.Context
import androidx.hilt.work.HiltWorkerFactory
import androidx.startup.Initializer
import androidx.work.Configuration
import androidx.work.WorkManager
import com.nexusz4.analytics.BehaviorTracker
import com.nexusz4.core.LLMEngine
import com.nexusz4.memory.MemoryManager
import com.nexusz4.security.EncryptionManager
import com.nexusz4.skills.SkillEngine
import com.nexusz4.system.PerformanceMonitor
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class NexusApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    @Inject
    lateinit var llmEngine: LLMEngine

    @Inject
    lateinit var memoryManager: MemoryManager

    @Inject
    lateinit var skillEngine: SkillEngine

    @Inject
    lateinit var encryptionManager: EncryptionManager

    @Inject
    lateinit var performanceMonitor: PerformanceMonitor

    @Inject
    lateinit var behaviorTracker: BehaviorTracker

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        // Initialize logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        Timber.i("=== NEXUS Z4 SOVEREIGN AI INITIALIZING ===")
        Timber.i("Version: ${BuildConfig.VERSION_NAME}")
        Timber.i("Offline Mode: ENABLED")
        Timber.i("Internet Permissions: NONE")

        // Initialize core systems
        initializeSystems()
    }

    private fun initializeSystems() {
        applicationScope.launch {
            try {
                // Initialize encryption first
                encryptionManager.initialize()
                Timber.i("[Security] Encryption initialized")

                // Initialize performance monitoring
                performanceMonitor.startMonitoring()
                Timber.i("[System] Performance monitoring active")

                // Initialize memory system
                memoryManager.initialize()
                Timber.i("[Memory] Vector database ready")

                // Initialize skill engine
                skillEngine.initialize()
                Timber.i("[Skills] Skill engine loaded")

                // Initialize LLM engine (lazy loading)
                llmEngine.prepare()
                Timber.i("[Core] LLM engine ready")

                // Initialize behavior tracking
                behaviorTracker.initialize()
                Timber.i("[Analytics] Behavior tracking active")

                Timber.i("=== NEXUS Z4 FULLY OPERATIONAL ===")
            } catch (e: Exception) {
                Timber.e(e, "Failed to initialize NEXUS Z4")
            }
        }
    }

    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when (level) {
            TRIM_MEMORY_RUNNING_CRITICAL -> {
                Timber.w("Critical memory pressure - reducing cognitive depth")
                performanceMonitor.emergencyReduce()
            }
            TRIM_MEMORY_RUNNING_LOW -> {
                Timber.w("Low memory - scaling down operations")
                performanceMonitor.scaleDown()
            }
        }
    }
}

class NexusInitializer : Initializer<NexusApplication> {
    override fun create(context: Context): NexusApplication {
        return context.applicationContext as NexusApplication
    }

    override fun dependencies(): List<Class<out Initializer<*>>> {
        return emptyList()
    }
}
