package com.nexusz4.memory

import ai.onnxruntime.*
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Embedding Engine using ONNX Runtime
 * Runs MiniLM or similar embedding models locally
 */
@Singleton
class EmbeddingEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var ortEnvironment: OrtEnvironment? = null
    private var ortSession: OrtSession? = null
    private var tokenizer: LocalTokenizer? = null

    private var isInitialized = false
    private val maxSequenceLength = 512

    companion object {
        const val EMBEDDING_DIMENSION = 384
        const val MODEL_NAME = "all-MiniLM-L6-v2-quantized.onnx"
        const val VOCAB_NAME = "vocab.txt"
    }

    /**
     * Initialize the embedding engine
     */
    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext

        try {
            Timber.i("[Embedding] Initializing ONNX Runtime...")

            // Create ONNX environment
            ortEnvironment = OrtEnvironment.getEnvironment()

            // Load model
            val modelPath = copyModelFromAssets()
            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
                setInterOpNumThreads(2)
                addConfigEntry("session.use_arena_alloc", "1")
                addConfigEntry("session.use_memory_efficient_arena", "1")
            }

            ortSession = ortEnvironment?.createSession(modelPath, sessionOptions)

            // Initialize tokenizer
            tokenizer = LocalTokenizer(context)
            tokenizer?.loadVocabulary()

            isInitialized = true
            Timber.i("[Embedding] Engine initialized successfully")
        } catch (e: Exception) {
            Timber.e(e, "[Embedding] Failed to initialize")
            throw e
        }
    }

    /**
     * Generate embedding for text
     */
    fun embed(text: String): FloatArray {
        if (!isInitialized) {
            throw IllegalStateException("Embedding engine not initialized")
        }

        return try {
            // Tokenize
            val tokens = tokenizer?.tokenize(text) ?: emptyList()

            // Truncate if needed
            val truncatedTokens = if (tokens.size > maxSequenceLength - 2) {
                tokens.take(maxSequenceLength - 2)
            } else {
                tokens
            }

            // Create input tensors
            val inputIds = mutableListOf<Long>()
            val attentionMask = mutableListOf<Long>()

            // CLS token
            inputIds.add(101)  // [CLS]
            attentionMask.add(1)

            // Content tokens
            truncatedTokens.forEach { _ ->
                inputIds.add(it.toLong())
                attentionMask.add(1)
            }

            // SEP token
            inputIds.add(102)  // [SEP]
            attentionMask.add(1)

            // Pad to max length
            val currentLength = inputIds.size
            repeat(maxSequenceLength - currentLength) {
                inputIds.add(0)  // [PAD]
                attentionMask.add(0)
            }

            // Create ONNX tensors
            val inputIdsBuffer = LongBuffer.wrap(inputIds.toLongArray())
            val attentionMaskBuffer = LongBuffer.wrap(attentionMask.toLongArray())

            val inputIdsTensor = OnnxTensor.createTensor(
                ortEnvironment,
                inputIdsBuffer,
                longArrayOf(1, maxSequenceLength.toLong())
            )

            val attentionMaskTensor = OnnxTensor.createTensor(
                ortEnvironment,
                attentionMaskBuffer,
                longArrayOf(1, maxSequenceLength.toLong())
            )

            // Run inference
            val inputs = mapOf(
                "input_ids" to inputIdsTensor,
                "attention_mask" to attentionMaskTensor
            )

            val results = ortSession?.run(inputs)
            val outputTensor = results?.get(0) as? OnnxTensor

            // Extract embeddings
            val embeddings = outputTensor?.floatBuffer?.let { buffer ->
                FloatArray(EMBEDDING_DIMENSION) { buffer.get() }
            } ?: FloatArray(EMBEDDING_DIMENSION)

            // Mean pooling (simplified - should use attention mask)
            val meanPooled = meanPool(embeddings, attentionMask)

            // Normalize
            normalize(meanPooled)

            // Cleanup
            inputIdsTensor.close()
            attentionMaskTensor.close()
            results?.close()

            meanPooled
        } catch (e: Exception) {
            Timber.e(e, "[Embedding] Failed to generate embedding")
            FloatArray(EMBEDDING_DIMENSION) { 0f }
        }
    }

    /**
     * Batch embedding for multiple texts
     */
    fun embedBatch(texts: List<String>): List<FloatArray> {
        return texts.map { embed(it) }
    }

    /**
     * Calculate similarity between two texts
     */
    fun calculateSimilarity(text1: String, text2: String): Float {
        val embedding1 = embed(text1)
        val embedding2 = embed(text2)
        return cosineSimilarity(embedding1, embedding2)
    }

    /**
     * Find most similar text from candidates
     */
    fun findMostSimilar(query: String, candidates: List<String>): Pair<String, Float>? {
        if (candidates.isEmpty()) return null

        val queryEmbedding = embed(query)
        val candidateEmbeddings = embedBatch(candidates)

        var bestMatch = candidates.first()
        var bestScore = -1f

        candidateEmbeddings.forEachIndexed { index, embedding ->
            val score = cosineSimilarity(queryEmbedding, embedding)
            if (score > bestScore) {
                bestScore = score
                bestMatch = candidates[index]
            }
        }

        return bestMatch to bestScore
    }

    /**
     * Release resources
     */
    fun release() {
        ortSession?.close()
        ortEnvironment?.close()
        tokenizer = null
        isInitialized = false
        Timber.i("[Embedding] Engine released")
    }

    // Private helpers

    private fun copyModelFromAssets(): String {
        val modelFile = File(context.filesDir, MODEL_NAME)

        if (!modelFile.exists()) {
            context.assets.open(MODEL_NAME).use { input ->
                modelFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
        }

        return modelFile.absolutePath
    }

    private fun meanPool(embeddings: FloatArray, attentionMask: List<Long>): FloatArray {
        // Simplified mean pooling
        // In production, should properly pool using attention mask
        return embeddings
    }

    private fun normalize(vector: FloatArray): FloatArray {
        val magnitude = kotlin.math.sqrt(vector.sumOf { it * it.toDouble() }).toFloat()
        return if (magnitude > 0) {
            vector.map { it / magnitude }.toFloatArray()
        } else {
            vector
        }
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dotProduct = 0f
        for (i in a.indices) {
            dotProduct += a[i] * b[i]
        }
        return dotProduct.coerceIn(-1f, 1f)
    }
}

/**
 * Simple local tokenizer for BERT-based models
 */
class LocalTokenizer(private val context: Context) {
    private val vocab = mutableMapOf<String, Int>()
    private val reverseVocab = mutableMapOf<Int, String>()

    fun loadVocabulary() {
        try {
            context.assets.open("vocab.txt").bufferedReader().useLines { lines ->
                lines.forEachIndexed { index, token ->
                    vocab[token] = index
                    reverseVocab[index] = token
                }
            }
            Timber.i("[Tokenizer] Loaded vocabulary: ${vocab.size} tokens")
        } catch (e: Exception) {
            Timber.e(e, "[Tokenizer] Failed to load vocabulary")
            // Fallback to basic tokenization
        }
    }

    fun tokenize(text: String): List<Int> {
        if (vocab.isEmpty()) {
            // Fallback: character-level tokenization
            return text.map { it.code }
        }

        val tokens = mutableListOf<Int>()
        val words = text.lowercase().split(Regex("\\s+"))

        words.forEach { word ->
            // WordPiece tokenization (simplified)
            var remaining = word
            while (remaining.isNotEmpty()) {
                val token = vocab[remaining]
                if (token != null) {
                    tokens.add(token)
                    break
                } else {
                    // Try subwords
                    var found = false
                    for (i in remaining.length downTo 1) {
                        val subword = remaining.substring(0, i)
                        val subToken = vocab[subword]
                        if (subToken != null) {
                            tokens.add(subToken)
                            remaining = remaining.substring(i)
                            found = true
                            break
                        }
                    }
                    if (!found) {
                        // Unknown token
                        tokens.add(vocab["[UNK]"] ?: 100)
                        break
                    }
                }
            }
        }

        return tokens
    }

    fun decode(tokens: List<Int>): String {
        return tokens.map { reverseVocab[it] ?: "[UNK]" }.joinToString(" ")
    }
}
