package com.nexusz4.core

import android.content.Context
import com.nexusz4.core.model.GenerationConfig
import com.nexusz4.core.model.GenerationResult
import com.nexusz4.core.model.ModelConfig
import com.nexusz4.system.PerformanceMonitor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.io.File
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Core LLM Engine using llama.cpp with Vulkan acceleration
 * Supports GGUF 4-bit quantized models
 */
@Singleton
class LLMEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val performanceMonitor: PerformanceMonitor,
    private val nativeBridge: LlamaNativeBridge
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Model state
    private var isModelLoaded = AtomicBoolean(false)
    private var currentModelPath: String? = null
    private var modelContext: Long = 0
    private val modelLock = Any()

    // Generation state
    private val isGenerating = AtomicBoolean(false)
    private val generationQueue = ConcurrentLinkedQueue<GenerationRequest>()
    private val currentTokenCount = AtomicInteger(0)

    // Performance tracking
    private var tokensPerSecond = 0.0
    private var lastGenerationTime = 0L

    // Default configuration
    private var defaultConfig = GenerationConfig(
        temperature = 0.7f,
        topP = 0.9f,
        maxTokens = 2048,
        repeatPenalty = 1.1f,
        presencePenalty = 0.0f,
        frequencyPenalty = 0.0f
    )

    data class GenerationRequest(
        val prompt: String,
        val config: GenerationConfig?,
        val callback: (GenerationResult) -> Unit
    )

    companion object {
        const val DEFAULT_MODEL = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"
        const val CONTEXT_SIZE = 4096
        const val BATCH_SIZE = 512
        const val GPU_LAYERS = 35  // Offload to Vulkan GPU
    }

    init {
        System.loadLibrary("llama-android")
    }

    /**
     * Prepare the engine (doesn't load model yet)
     */
    fun prepare() {
        Timber.i("[LLM] Engine prepared, awaiting model load")
    }

    /**
     * Load a GGUF model file
     */
    suspend fun loadModel(modelPath: String, config: ModelConfig = ModelConfig()): Result<Unit> =
        withContext(Dispatchers.IO) {
            synchronized(modelLock) {
                try {
                    if (isModelLoaded.get() && currentModelPath == modelPath) {
                        Timber.i("[LLM] Model already loaded: $modelPath")
                        return@synchronized Result.success(Unit)
                    }

                    // Unload existing model
                    unloadModel()

                    Timber.i("[LLM] Loading model: $modelPath")
                    val startTime = System.currentTimeMillis()

                    // Verify file exists
                    val modelFile = File(modelPath)
                    if (!modelFile.exists()) {
                        return@synchronized Result.failure(
                            IllegalArgumentException("Model file not found: $modelPath")
                        )
                    }

                    // Memory map the model file
                    val mappedBuffer = mapModelFile(modelFile)

                    // Load via native bridge with Vulkan
                    modelContext = nativeBridge.loadModel(
                        modelPath = modelPath,
                        contextSize = config.contextSize,
                        gpuLayers = if (config.useGpu) GPU_LAYERS else 0,
                        batchSize = config.batchSize
                    )

                    if (modelContext == 0L) {
                        return@synchronized Result.failure(
                            RuntimeException("Failed to load model via native layer")
                        )
                    }

                    currentModelPath = modelPath
                    isModelLoaded.set(true)

                    val loadTime = System.currentTimeMillis() - startTime
                    Timber.i("[LLM] Model loaded in ${loadTime}ms, context: $modelContext")

                    Result.success(Unit)
                } catch (e: Exception) {
                    Timber.e(e, "[LLM] Failed to load model")
                    Result.failure(e)
                }
            }
        }

    /**
     * Unload current model and free memory
     */
    fun unloadModel() {
        synchronized(modelLock) {
            if (modelContext != 0L) {
                nativeBridge.unloadModel(modelContext)
                modelContext = 0L
                isModelLoaded.set(false)
                currentModelPath = null
                Timber.i("[LLM] Model unloaded")
            }
        }
    }

    /**
     * Generate text with streaming output
     */
    fun generateStream(
        prompt: String,
        config: GenerationConfig? = null
): Flow<String> = callbackFlow {
        if (!isModelLoaded.get()) {
            trySend("[Error: No model loaded]")
            close()
            return@callbackFlow
        }

        if (isGenerating.get()) {
            trySend("[Error: Generation in progress]")
            close()
            return@callbackFlow
        }

        isGenerating.set(true)
        currentTokenCount.set(0)

        val effectiveConfig = config ?: defaultConfig
        val startTime = System.currentTimeMillis()

        try {
            // Apply cognitive scaling based on hardware state
            val scaledConfig = applyCognitiveScaling(effectiveConfig)

            Timber.i("[LLM] Starting generation, max_tokens=${scaledConfig.maxTokens}")

            // Native generation with callback
            nativeBridge.generate(
                contextPtr = modelContext,
                prompt = prompt,
                temperature = scaledConfig.temperature,
                topP = scaledConfig.topP,
                maxTokens = scaledConfig.maxTokens,
                repeatPenalty = scaledConfig.repeatPenalty,
                tokenCallback = { token ->
                    currentTokenCount.incrementAndGet()
                    trySend(token)
                }
            )

            val duration = System.currentTimeMillis() - startTime
            tokensPerSecond = currentTokenCount.get() * 1000.0 / duration.coerceAtLeast(1)

            Timber.i("[LLM] Generation complete: ${currentTokenCount.get()} tokens in ${duration}ms (${"%.2f".format(tokensPerSecond)} t/s)")

        } catch (e: Exception) {
            Timber.e(e, "[LLM] Generation failed")
            trySend("[Error: ${e.message}]")
        } finally {
            isGenerating.set(false)
            close()
        }
    }.flowOn(Dispatchers.Default)

    /**
     * Generate text with single response
     */
    suspend fun generate(
        prompt: String,
        config: GenerationConfig? = null
    ): GenerationResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val outputBuilder = StringBuilder()

        try {
            generateStream(prompt, config).collect { token ->
                outputBuilder.append(token)
            }

            val duration = System.currentTimeMillis() - startTime

            GenerationResult(
                text = outputBuilder.toString(),
                tokensGenerated = currentTokenCount.get(),
                tokensPerSecond = tokensPerSecond,
                durationMs = duration,
                success = true
            )
        } catch (e: Exception) {
            GenerationResult(
                text = "",
                tokensGenerated = 0,
                tokensPerSecond = 0.0,
                durationMs = System.currentTimeMillis() - startTime,
                success = false,
                error = e.message
            )
        }
    }

    /**
     * Apply cognitive scaling based on hardware constraints
     */
    private fun applyCognitiveScaling(config: GenerationConfig): GenerationConfig {
        val metrics = performanceMonitor.getCurrentMetrics()
        val cognitiveLevel = performanceMonitor.getCognitiveLevel()

        return when (cognitiveLevel) {
            0 -> config.copy(maxTokens = (config.maxTokens * 0.3).toInt())  // Critical
            1 -> config.copy(maxTokens = (config.maxTokens * 0.5).toInt())  // Low
            2 -> config.copy(maxTokens = (config.maxTokens * 0.75).toInt()) // Moderate
            3 -> config  // Normal
            4 -> config.copy(maxTokens = (config.maxTokens * 1.2).toInt())  // Optimal
            else -> config
        }.also {
            Timber.d("[LLM] Cognitive scaling applied: level=$cognitiveLevel, maxTokens=${it.maxTokens}")
        }
    }

    /**
     * Stop current generation
     */
    fun stopGeneration() {
        if (isGenerating.get()) {
            nativeBridge.stopGeneration(modelContext)
            isGenerating.set(false)
            Timber.i("[LLM] Generation stopped")
        }
    }

    /**
     * Get current model info
     */
    fun getModelInfo(): Map<String, Any> {
        return if (isModelLoaded.get()) {
            nativeBridge.getModelInfo(modelContext)
        } else {
            emptyMap()
        }
    }

    /**
     * Update default generation config
     */
    fun updateDefaultConfig(config: GenerationConfig) {
        defaultConfig = config
        Timber.i("[LLM] Default config updated: temp=${config.temperature}, topP=${config.topP}")
    }

    /**
     * Check if model is loaded
     */
    fun isReady(): Boolean = isModelLoaded.get() && !isGenerating.get()

    /**
     * Get performance stats
     */
    fun getPerformanceStats(): Map<String, Any> {
        return mapOf(
            "tokens_per_second" to tokensPerSecond,
            "model_loaded" to isModelLoaded.get(),
            "generating" to isGenerating.get(),
            "current_model" to (currentModelPath ?: "none"),
            "context_size" to CONTEXT_SIZE
        )
    }

    private fun mapModelFile(file: File): MappedByteBuffer {
        return file.inputStream().channel.use { channel ->
            channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
        }
    }

    fun release() {
        unloadModel()
        scope.cancel()
    }
}
