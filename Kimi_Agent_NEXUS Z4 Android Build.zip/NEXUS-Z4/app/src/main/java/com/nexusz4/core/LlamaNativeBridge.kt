package com.nexusz4.core

import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * JNI bridge to llama.cpp native library
 * Handles all native calls for model loading and inference
 */
@Singleton
class LlamaNativeBridge @Inject constructor() {

    init {
        try {
            System.loadLibrary("llama-android")
            Timber.i("[Native] llama-android library loaded")
        } catch (e: UnsatisfiedLinkError) {
            Timber.e(e, "[Native] Failed to load llama-android library")
            throw e
        }
    }

    /**
     * Load a GGUF model file
     * @return Context pointer (0 on failure)
     */
    external fun loadModel(
        modelPath: String,
        contextSize: Int,
        gpuLayers: Int,
        batchSize: Int
    ): Long

    /**
     * Unload model and free resources
     */
    external fun unloadModel(contextPtr: Long)

    /**
     * Generate text with streaming callback
     */
    external fun generate(
        contextPtr: Long,
        prompt: String,
        temperature: Float,
        topP: Float,
        maxTokens: Int,
        repeatPenalty: Float,
        tokenCallback: TokenCallback
    )

    /**
     * Stop ongoing generation
     */
    external fun stopGeneration(contextPtr: Long)

    /**
     * Get model information
     */
    external fun getModelInfo(contextPtr: Long): Map<String, Any>

    /**
     * Tokenize text
     */
    external fun tokenize(contextPtr: Long, text: String): IntArray

    /**
     * Count tokens in text
     */
    external fun countTokens(contextPtr: Long, text: String): Int

    /**
     * Check if generation is in progress
     */
    external fun isGenerating(contextPtr: Long): Boolean

    /**
     * Get context size
     */
    external fun getContextSize(contextPtr: Long): Int

    /**
     * Get vocabulary size
     */
    external fun getVocabSize(contextPtr: Long): Int

    /**
     * Embedding extraction
     */
    external fun getEmbedding(contextPtr: Long, text: String): FloatArray

    /**
     * Batch token evaluation
     */
    external fun evalTokens(contextPtr: Long, tokens: IntArray): Boolean

    /**
     * Sample next token
     */
    external fun sampleToken(
        contextPtr: Long,
        temperature: Float,
        topP: Float
    ): Int

    /**
     * Convert token to string
     */
    external fun tokenToString(contextPtr: Long, token: Int): String

    /**
     * Reset context (clear KV cache)
     */
    external fun resetContext(contextPtr: Long)

    /**
     * Save state to file
     */
    external fun saveState(contextPtr: Long, path: String): Boolean

    /**
     * Load state from file
     */
    external fun loadState(contextPtr: Long, path: String): Boolean

    /**
     * Token callback interface
     */
    interface TokenCallback {
        fun onToken(token: String): Boolean
    }

    /**
     * Synchronous generation (blocking)
     */
    fun generateSync(
        contextPtr: Long,
        prompt: String,
        temperature: Float,
        topP: Float,
        maxTokens: Int,
        repeatPenalty: Float
    ): String {
        val result = StringBuilder()

        generate(
            contextPtr = contextPtr,
            prompt = prompt,
            temperature = temperature,
            topP = topP,
            maxTokens = maxTokens,
            repeatPenalty = repeatPenalty,
            tokenCallback = object : TokenCallback {
                override fun onToken(token: String): Boolean {
                    result.append(token)
                    return true // Continue generation
                }
            }
        )

        return result.toString()
    }

    companion object {
        init {
            // Additional library initialization if needed
        }
    }
}
