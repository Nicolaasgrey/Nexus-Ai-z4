package com.nexusz4.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nexusz4.R
import com.nexusz4.core.model.GenerationConfig
import com.nexusz4.core.model.GenerationResult
import com.nexusz4.system.PerformanceMonitor
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import javax.inject.Inject

/**
 * Foreground service for background LLM inference
 * Maintains model in memory for faster response times
 */
@AndroidEntryPoint
class InferenceService : Service() {

    @Inject
    lateinit var llmEngine: LLMEngine

    @Inject
    lateinit var performanceMonitor: PerformanceMonitor

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val binder = InferenceBinder()

    // Pending requests queue
    private val requestQueue = MutableSharedFlow<InferenceRequest>(extraBufferCapacity = 10)
    private var processingJob: Job? = null

    data class InferenceRequest(
        val id: String,
        val prompt: String,
        val config: GenerationConfig?,
        val priority: Priority = Priority.NORMAL,
        val onResult: (GenerationResult) -> Unit,
        val onToken: ((String) -> Unit)? = null
    )

    enum class Priority {
        LOW, NORMAL, HIGH, CRITICAL
    }

    companion object {
        const val CHANNEL_ID = "nexus_inference_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.nexusz4.STOP_INFERENCE"

        fun start(context: Context) {
            val intent = Intent(context, InferenceService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, InferenceService::class.java)
            intent.action = ACTION_STOP
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Timber.i("[Service] InferenceService created")
        createNotificationChannel()
        startRequestProcessor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, createNotification())
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder = binder

    inner class InferenceBinder : Binder() {
        fun getService(): InferenceService = this@InferenceService
    }

    /**
     * Queue an inference request
     */
    fun queueRequest(request: InferenceRequest): Boolean {
        return requestQueue.tryEmit(request)
    }

    /**
     * Execute inference immediately (blocking)
     */
    suspend fun executeInference(
        prompt: String,
        config: GenerationConfig? = null
    ): GenerationResult {
        return llmEngine.generate(prompt, config)
    }

    /**
     * Stream inference with callback
     */
    fun streamInference(
        prompt: String,
        config: GenerationConfig? = null
    ): Flow<String> {
        return llmEngine.generateStream(prompt, config)
    }

    /**
     * Check if engine is ready
     */
    fun isReady(): Boolean = llmEngine.isReady()

    /**
     * Load model if not already loaded
     */
    suspend fun ensureModelLoaded(modelPath: String): Result<Unit> {
        return llmEngine.loadModel(modelPath)
    }

    /**
     * Unload model to free memory
     */
    fun releaseModel() {
        llmEngine.unloadModel()
    }

    private fun startRequestProcessor() {
        processingJob = serviceScope.launch {
            requestQueue.collect { request ->
                processRequest(request)
            }
        }
    }

    private suspend fun processRequest(request: InferenceRequest) {
        try {
            Timber.d("[Service] Processing request ${request.id}")

            if (request.onToken != null) {
                // Streaming response
                llmEngine.generateStream(request.prompt, request.config)
                    .collect { token ->
                        request.onToken.invoke(token)
                    }
            } else {
                // Single response
                val result = llmEngine.generate(request.prompt, request.config)
                request.onResult(result)
            }
        } catch (e: Exception) {
            Timber.e(e, "[Service] Request ${request.id} failed")
            request.onResult(
                GenerationResult(
                    text = "",
                    tokensGenerated = 0,
                    tokensPerSecond = 0.0,
                    durationMs = 0,
                    success = false,
                    error = e.message
                )
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEXUS Inference",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background AI inference service"
                setShowBadge(false)
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, InferenceService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NEXUS Z4")
            .setContentText("AI inference engine active")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setSilent(true)
            .addAction(R.drawable.ic_stop, "Stop", stopIntent)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        processingJob?.cancel()
        serviceScope.cancel()
        llmEngine.release()
        Timber.i("[Service] InferenceService destroyed")
    }
}

// Helper for ContextCompat
object ContextCompat {
    fun startForegroundService(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }
}
