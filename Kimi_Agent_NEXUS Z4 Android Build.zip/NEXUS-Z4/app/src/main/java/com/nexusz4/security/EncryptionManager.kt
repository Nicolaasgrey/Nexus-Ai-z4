package com.nexusz4.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import timber.log.Timber
import java.nio.ByteBuffer
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Encryption Manager
 * Handles AES encryption for local data storage
 * Supports hardware-backed keystore and biometric authentication
 */
@Singleton
class EncryptionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private val biometricManager = BiometricManager.from(context)

    private var isInitialized = false
    private var useBiometric = false

    companion object {
        const val KEY_ALIAS = "nexus_master_key"
        const val BIOMETRIC_KEY_ALIAS = "nexus_biometric_key"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val GCM_TAG_LENGTH = 128
        const val GCM_IV_LENGTH = 12
        const val AES_KEY_SIZE = 256
    }

    /**
     * Initialize encryption system
     */
    fun initialize() {
        if (isInitialized) return

        try {
            // Create master key if not exists
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                createMasterKey()
            }

            isInitialized = true
            Timber.i("[Security] Encryption initialized")
        } catch (e: Exception) {
            Timber.e(e, "[Security] Failed to initialize encryption")
            throw e
        }
    }

    /**
     * Encrypt data
     */
    fun encrypt(plaintext: String): EncryptedData {
        return encrypt(plaintext.toByteArray(Charsets.UTF_8))
    }

    /**
     * Encrypt byte array
     */
    fun encrypt(plaintext: ByteArray): EncryptedData {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getMasterKey())

        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext)

        return EncryptedData(iv, ciphertext)
    }

    /**
     * Decrypt data
     */
    fun decrypt(encryptedData: EncryptedData): String {
        return String(decryptToBytes(encryptedData), Charsets.UTF_8)
    }

    /**
     * Decrypt to byte array
     */
    fun decryptToBytes(encryptedData: EncryptedData): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, encryptedData.iv)
        cipher.init(Cipher.DECRYPT_MODE, getMasterKey(), spec)

        return cipher.doFinal(encryptedData.ciphertext)
    }

    /**
     * Check if biometric authentication is available
     */
    fun isBiometricAvailable(): Boolean {
        return when (biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        )) {
            BiometricManager.BIOMETRIC_SUCCESS -> true
            else -> false
        }
    }

    /**
     * Enable biometric authentication
     */
    fun enableBiometric() {
        if (!isBiometricAvailable()) {
            throw IllegalStateException("Biometric authentication not available")
        }

        try {
            if (!keyStore.containsAlias(BIOMETRIC_KEY_ALIAS)) {
                createBiometricKey()
            }
            useBiometric = true
            Timber.i("[Security] Biometric authentication enabled")
        } catch (e: Exception) {
            Timber.e(e, "[Security] Failed to enable biometric")
            throw e
        }
    }

    /**
     * Authenticate with biometric
     */
    suspend fun authenticateWithBiometric(
        activity: FragmentActivity,
        title: String = "Authentication Required",
        subtitle: String = "Verify your identity"
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val executor = ContextCompat.getMainExecutor(activity)

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                continuation.resume(true)
            }

            override fun onAuthenticationFailed() {
                continuation.resume(false)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                continuation.resume(false)
            }
        }

        val prompt = BiometricPrompt(activity, executor, callback)

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()

        prompt.authenticate(promptInfo)
    }

    /**
     * Encrypt with PIN/password
     */
    fun encryptWithPin(plaintext: String, pin: String): EncryptedData {
        // Derive key from PIN
        val key = deriveKeyFromPin(pin)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)

        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

        return EncryptedData(iv, ciphertext)
    }

    /**
     * Decrypt with PIN/password
     */
    fun decryptWithPin(encryptedData: EncryptedData, pin: String): String {
        val key = deriveKeyFromPin(pin)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, encryptedData.iv)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)

        return String(cipher.doFinal(encryptedData.ciphertext), Charsets.UTF_8)
    }

    /**
     * Generate secure random PIN
     */
    fun generateSecurePin(length: Int = 6): String {
        val random = SecureRandom()
        val pin = StringBuilder()

        repeat(length) {
            pin.append(random.nextInt(10))
        }

        return pin.toString()
    }

    /**
     * Hash data for integrity verification
     */
    fun hash(data: ByteArray): ByteArray {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        return digest.digest(data)
    }

    /**
     * Verify data integrity
     */
    fun verifyIntegrity(data: ByteArray, expectedHash: ByteArray): Boolean {
        return hash(data).contentEquals(expectedHash)
    }

    /**
     * Securely clear sensitive data
     */
    fun secureClear(array: ByteArray) {
        val random = SecureRandom()
        random.nextBytes(array)
        array.fill(0)
    }

    // Private methods

    private fun createMasterKey() {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )

        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(AES_KEY_SIZE)
            .setRandomizedEncryptionRequired(true)
            .build()

        keyGenerator.init(spec)
        keyGenerator.generateKey()

        Timber.i("[Security] Master key created")
    }

    private fun createBiometricKey() {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )

        val spec = KeyGenParameterSpec.Builder(
            BIOMETRIC_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(AES_KEY_SIZE)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
            .build()

        keyGenerator.init(spec)
        keyGenerator.generateKey()

        Timber.i("[Security] Biometric key created")
    }

    private fun getMasterKey(): SecretKey {
        return keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry
    }.secretKey

    private fun deriveKeyFromPin(pin: String): SecretKey {
        // Simple PBKDF2-like derivation
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)

        // In production, use proper PBKDF2
        val keyBytes = hash((pin + salt.toString()).toByteArray())

        return javax.crypto.spec.SecretKeySpec(
            keyBytes.copyOf(32),
            "AES"
        )
    }

    /**
     * Encrypted data container
     */
    data class EncryptedData(
        val iv: ByteArray,
        val ciphertext: ByteArray
    ) {
        fun toBase64(): String {
            val combined = ByteBuffer.allocate(iv.size + ciphertext.size)
                .put(iv)
                .put(ciphertext)
                .array()
            return android.util.Base64.encodeToString(combined, android.util.Base64.DEFAULT)
        }

        companion object {
            fun fromBase64(base64: String): EncryptedData {
                val combined = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
                val iv = combined.copyOfRange(0, GCM_IV_LENGTH)
                val ciphertext = combined.copyOfRange(GCM_IV_LENGTH, combined.size)
                return EncryptedData(iv, ciphertext)
            }
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as EncryptedData

            if (!iv.contentEquals(other.iv)) return false
            if (!ciphertext.contentEquals(other.ciphertext)) return false

            return true
        }

        override fun hashCode(): Int {
            var result = iv.contentHashCode()
            result = 31 * result + ciphertext.contentHashCode()
            return result
        }
    }
}

/**
 * Secure preferences wrapper
 */
class SecurePreferences(
    private val context: Context,
    private val encryptionManager: EncryptionManager
) {
    private val prefs = context.getSharedPreferences("secure_prefs", Context.MODE_PRIVATE)

    fun putString(key: String, value: String) {
        val encrypted = encryptionManager.encrypt(value)
        prefs.edit()
            .putString("${key}_iv", android.util.Base64.encodeToString(encrypted.iv, android.util.Base64.DEFAULT))
            .putString("${key}_data", android.util.Base64.encodeToString(encrypted.ciphertext, android.util.Base64.DEFAULT))
            .apply()
    }

    fun getString(key: String, defaultValue: String? = null): String? {
        val ivBase64 = prefs.getString("${key}_iv", null) ?: return defaultValue
        val dataBase64 = prefs.getString("${key}_data", null) ?: return defaultValue

        return try {
            val iv = android.util.Base64.decode(ivBase64, android.util.Base64.DEFAULT)
            val data = android.util.Base64.decode(dataBase64, android.util.Base64.DEFAULT)
            val encryptedData = EncryptionManager.EncryptedData(iv, data)
            encryptionManager.decrypt(encryptedData)
        } catch (e: Exception) {
            defaultValue
        }
    }

    fun remove(key: String) {
        prefs.edit()
            .remove("${key}_iv")
            .remove("${key}_data")
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
