package com.nexusz4.core.model

import kotlinx.serialization.Serializable

/**
 * Generation configuration for LLM inference
 */
@Serializable
data class GenerationConfig(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxTokens: Int = 2048,
    val repeatPenalty: Float = 1.1f,
    val presencePenalty: Float = 0.0f,
    val frequencyPenalty: Float = 0.0f,
    val stopSequences: List<String> = emptyList(),
    val seed: Int = -1,
    val stream: Boolean = true
) {
    init {
        require(temperature in 0.0..2.0) { "Temperature must be in [0, 2]" }
        require(topP in 0.0..1.0) { "TopP must be in [0, 1]" }
        require(maxTokens > 0) { "Max tokens must be positive" }
    }

    companion object {
        val CREATIVE = GenerationConfig(
            temperature = 0.9f,
            topP = 0.95f,
            maxTokens = 2048
        )

        val BALANCED = GenerationConfig(
            temperature = 0.7f,
            topP = 0.9f,
            maxTokens = 2048
        )

        val PRECISE = GenerationConfig(
            temperature = 0.3f,
            topP = 0.7f,
            maxTokens = 1024
        )

        val CODE = GenerationConfig(
            temperature = 0.2f,
            topP = 0.8f,
            maxTokens = 4096,
            repeatPenalty = 1.05f
        )
    }
}

/**
 * Model configuration for loading
 */
@Serializable
data class ModelConfig(
    val contextSize: Int = 4096,
    val batchSize: Int = 512,
    val useGpu: Boolean = true,
    val gpuLayers: Int = 35,
    val threads: Int = 4,
    val useMmap: Boolean = true,
    val useMlock: Boolean = false
)

/**
 * Result of a generation request
 */
@Serializable
data class GenerationResult(
    val text: String,
    val tokensGenerated: Int,
    val tokensPerSecond: Double,
    val durationMs: Long,
    val success: Boolean,
    val error: String? = null,
    val finishReason: FinishReason = FinishReason.COMPLETE
)

enum class FinishReason {
    COMPLETE,
    STOP_SEQUENCE,
    LENGTH,
    TIMEOUT,
    ERROR,
    CANCELLED
}

/**
 * Available model presets
 */
@Serializable
data class ModelPreset(
    val id: String,
    val name: String,
    val filename: String,
    val description: String,
    val parameters: String,
    val quantization: String,
    val sizeGb: Float,
    val contextSize: Int,
    val recommended: Boolean = false
) {
    companion object {
        val PRESETS = listOf(
            ModelPreset(
                id = "mistral-7b-q4",
                name = "Mistral 7B Instruct",
                filename = "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
                description = "Fast, capable general-purpose model",
                parameters = "7B",
                quantization = "Q4_K_M",
                sizeGb = 4.1f,
                contextSize = 32768,
                recommended = true
            ),
            ModelPreset(
                id = "llama-3-8b-q4",
                name = "Llama 3 8B Instruct",
                filename = "Meta-Llama-3-8B-Instruct.Q4_K_M.gguf",
                description = "Latest Llama with strong reasoning",
                parameters = "8B",
                quantization = "Q4_K_M",
                sizeGb = 4.9f,
                contextSize = 8192
            ),
            ModelPreset(
                id = "phi-3-mini-q4",
                name = "Phi-3 Mini",
                filename = "Phi-3-mini-4k-instruct.Q4_K_M.gguf",
                description = "Compact but powerful",
                parameters = "3.8B",
                quantization = "Q4_K_M",
                sizeGb = 2.3f,
                contextSize = 4096
            ),
            ModelPreset(
                id = "qwen2-7b-q4",
                name = "Qwen2 7B Instruct",
                filename = "qwen2-7b-instruct-q4_K_M.gguf",
                description = "Strong multilingual performance",
                parameters = "7B",
                quantization = "Q4_K_M",
                sizeGb = 4.4f,
                contextSize = 32768
            ),
            ModelPreset(
                id = "gemma-2b-q4",
                name = "Gemma 2B IT",
                filename = "gemma-2b-it.Q4_K_M.gguf",
                description = "Ultra-lightweight for constrained devices",
                parameters = "2B",
                quantization = "Q4_K_M",
                sizeGb = 1.6f,
                contextSize = 8192
            )
        )

        fun getById(id: String): ModelPreset? = PRESETS.find { it.id == id }
        fun getRecommended(): ModelPreset = PRESETS.first { it.recommended }
    }
}

/**
 * Chat message format
 */
@Serializable
data class ChatMessage(
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val metadata: Map<String, String> = emptyMap()
)

enum class MessageRole {
    SYSTEM,
    USER,
    ASSISTANT,
    TOOL
}

/**
 * Chat session
 */
@Serializable
data class ChatSession(
    val id: String,
    val title: String,
    val messages: MutableList<ChatMessage> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val modelId: String = ModelPreset.getRecommended().id,
    val memoryEnabled: Boolean = true
) {
    fun addMessage(role: MessageRole, content: String) {
        messages.add(ChatMessage(role = role, content = content))
        updatedAt = System.currentTimeMillis()
    }

    fun toPrompt(systemPrompt: String? = null): String {
        val builder = StringBuilder()

        systemPrompt?.let {
            builder.append("<|system|>\n$it\n")
        }

        messages.forEach { msg ->
            when (msg.role) {
                MessageRole.USER -> builder.append("<|user|>\n${msg.content}\n")
                MessageRole.ASSISTANT -> builder.append("<|assistant|>\n${msg.content}\n")
                else -> { /* Skip system in history */ }
            }
        }

        builder.append("<|assistant|>\n")
        return builder.toString()
    }

    companion object {
        fun create(title: String = "New Chat"): ChatSession {
            return ChatSession(
                id = java.util.UUID.randomUUID().toString(),
                title = title
            )
        }
    }
}

/**
 * Token usage statistics
 */
@Serializable
data class TokenStats(
    val promptTokens: Int,
    val completionTokens: Int,
    val totalTokens: Int
) {
    companion object {
        fun empty() = TokenStats(0, 0, 0)
    }
}
