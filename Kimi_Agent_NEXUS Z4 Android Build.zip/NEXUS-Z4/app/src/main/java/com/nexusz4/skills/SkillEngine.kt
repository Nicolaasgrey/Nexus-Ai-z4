package com.nexusz4.skills

import android.content.Context
import com.nexusz4.core.LLMEngine
import com.nexusz4.core.model.GenerationConfig
import com.nexusz4.security.EncryptionManager
import com.nexusz4.skills.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Skill Engine - Self-upgrading module system
 * Manages skill lifecycle, activation, and evolution
 */
@Singleton
class SkillEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val llmEngine: LLMEngine,
    private val encryptionManager: EncryptionManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Skill storage
    private val skills = ConcurrentHashMap<String, Skill>()
    private val skillStats = ConcurrentHashMap<String, SkillStatistics>()

    // Activation tracking
    private val activationHistory = mutableListOf<SkillActivation>()
    private val keywordIndex = ConcurrentHashMap<String, MutableSet<String>>()

    // Configuration
    private var config = SkillEngineConfig()
    private var isInitialized = false

    data class SkillEngineConfig(
        val autoGenerateSkills: Boolean = true,
        val minConfidenceThreshold: Float = 0.6f,
        val spiPromotionThreshold: Float = 0.75f,
        val spiDeprecationThreshold: Float = 0.3f,
        val maxSkills: Int = 100,
        val learningMode: LearningMode = LearningMode.ADAPTIVE
    )

    enum class LearningMode {
        STABLE,      // Conservative, minimal changes
        ADAPTIVE,    // Balanced adaptation
        EXPERIMENTAL // Aggressive skill generation
    }

    companion object {
        const val SKILLS_DIR = "skills"
        const val SKILLS_FILE = "skills.json"
        const val STATS_FILE = "skill_stats.json"
        const val MAX_HISTORY = 1000
    }

    /**
     * Initialize skill engine
     */
    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext

        try {
            Timber.i("[Skills] Initializing skill engine...")

            // Create skills directory
            val skillsDir = File(context.filesDir, SKILLS_DIR)
            skillsDir.mkdirs()

            // Load existing skills
            loadSkills()

            // Load statistics
            loadStatistics()

            // Build keyword index
            buildKeywordIndex()

            // Start evolution monitoring
            startEvolutionTasks()

            isInitialized = true
            Timber.i("[Skills] Loaded ${skills.size} skills")
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Initialization failed")
            throw e
        }
    }

    /**
     * Add a new skill manually
     */
    suspend fun addSkill(skill: Skill): Result<Skill> = withContext(Dispatchers.IO) {
        try {
            if (skills.size >= config.maxSkills) {
                return@withContext Result.failure(
                    IllegalStateException("Maximum skill limit reached")
                )
            }

            // Validate skill
            if (!validateSkill(skill)) {
                return@withContext Result.failure(
                    IllegalArgumentException("Invalid skill structure")
                )
            }

            // Store skill
            skills[skill.id] = skill

            // Initialize statistics
            skillStats[skill.id] = SkillStatistics(
                skillId = skill.id,
                createdAt = System.currentTimeMillis()
            )

            // Update keyword index
            skill.triggerKeywords.forEach { keyword ->
                keywordIndex.computeIfAbsent(keyword.lowercase()) { mutableSetOf() }
                    .add(skill.id)
            }

            // Persist
            saveSkills()

            Timber.i("[Skills] Added skill: ${skill.skillName}")
            Result.success(skill)
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to add skill")
            Result.failure(e)
        }
    }

    /**
     * Update existing skill
     */
    suspend fun updateSkill(
        id: String,
        updates: SkillUpdate
    ): Result<Skill> = withContext(Dispatchers.IO) {
        try {
            val existing = skills[id]
                ?: return@withContext Result.failure(IllegalArgumentException("Skill not found"))

            val updated = existing.copy(
                skillName = updates.name ?: existing.skillName,
                description = updates.description ?: existing.description,
                category = updates.category ?: existing.category,
                triggerKeywords = updates.triggerKeywords ?: existing.triggerKeywords,
                instructionTemplate = updates.instructionTemplate ?: existing.instructionTemplate,
                version = incrementVersion(existing.version),
                confidenceScore = updates.confidenceScore ?: existing.confidenceScore,
                isActive = updates.isActive ?: existing.isActive
            )

            // Update keyword index if keywords changed
            if (updates.triggerKeywords != null) {
                removeFromKeywordIndex(existing)
                updates.triggerKeywords.forEach { keyword ->
                    keywordIndex.computeIfAbsent(keyword.lowercase()) { mutableSetOf() }
                        .add(id)
                }
            }

            skills[id] = updated
            saveSkills()

            Timber.i("[Skills] Updated skill: ${updated.skillName}")
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete a skill
     */
    suspend fun deleteSkill(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val skill = skills.remove(id)
                ?: return@withContext Result.failure(IllegalArgumentException("Skill not found"))

            removeFromKeywordIndex(skill)
            skillStats.remove(id)
            saveSkills()

            Timber.i("[Skills] Deleted skill: ${skill.skillName}")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Detect and activate skills based on input
     */
    suspend fun detectSkills(input: String): List<SkillActivation> = withContext(Dispatchers.Default) {
        val activatedSkills = mutableListOf<SkillActivation>()
        val inputLower = input.lowercase()

        // Keyword matching
        val matchedSkillIds = mutableSetOf<String>()
        keywordIndex.forEach { (keyword, skillIds) ->
            if (inputLower.contains(keyword)) {
                matchedSkillIds.addAll(skillIds)
            }
        }

        // Score and filter skills
        matchedSkillIds.forEach { skillId ->
            val skill = skills[skillId] ?: return@forEach
            if (!skill.isActive) return@forEach

            val confidence = calculateActivationConfidence(skill, input)
            if (confidence >= config.minConfidenceThreshold) {
                activatedSkills.add(
                    SkillActivation(
                        skill = skill,
                        confidence = confidence,
                        matchedKeywords = skill.triggerKeywords.filter {
                            inputLower.contains(it.lowercase())
                        },
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
        }

        // Sort by confidence
        activatedSkills.sortByDescending { it.confidence }

        // Record activations
        activatedSkills.forEach { activation ->
            recordActivation(activation)
        }

        activatedSkills
    }

    /**
     * Apply skill to generate enhanced prompt
     */
    suspend fun applySkill(
        skill: Skill,
        userInput: String,
        context: Map<String, String> = emptyMap()
    ): String = withContext(Dispatchers.Default) {
        val template = skill.instructionTemplate

        // Replace placeholders
        var enhancedPrompt = template
            .replace("{input}", userInput)
            .replace("{skill_name}", skill.skillName)

        context.forEach { (key, value) ->
            enhancedPrompt = enhancedPrompt.replace("{$key}", value)
        }

        enhancedPrompt
    }

    /**
     * Generate skill from conversation pattern
     */
    suspend fun generateSkillFromPattern(
        pattern: String,
        examples: List<String>,
        category: SkillCategory
    ): Result<Skill> = withContext(Dispatchers.IO) {
        if (!config.autoGenerateSkills) {
            return@withContext Result.failure(
                IllegalStateException("Auto-generation disabled")
            )
        }

        try {
            // Use LLM to generate skill structure
            val prompt = buildSkillGenerationPrompt(pattern, examples, category)

            val result = llmEngine.generate(
                prompt = prompt,
                config = GenerationConfig.PRECISE.copy(maxTokens = 1024)
            )

            if (!result.success) {
                return@withContext Result.failure(
                    RuntimeException("LLM generation failed")
                )
            }

            // Parse generated skill
            val skill = parseGeneratedSkill(result.text, category)
                ?: return@withContext Result.failure(
                    IllegalStateException("Failed to parse generated skill")
                )

            // Add with low initial confidence
            val skillWithLowConfidence = skill.copy(
                confidenceScore = 0.5f,
                autoGenerated = true
            )

            addSkill(skillWithLowConfidence)

        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to generate skill")
            Result.failure(e)
        }
    }

    /**
     * Update skill confidence based on performance
     */
    fun updateSkillPerformance(
        skillId: String,
        responseScore: Float,
        userFeedback: Float? = null
    ) {
        val stats = skillStats[skillId] ?: return
        val skill = skills[skillId] ?: return

        // Update statistics
        val updatedStats = stats.copy(
            activationCount = stats.activationCount + 1,
            totalResponseScore = stats.totalResponseScore + responseScore,
            lastActivated = System.currentTimeMillis()
        )

        userFeedback?.let {
            updatedStats.copy(
                userFeedbackSum = stats.userFeedbackSum + it,
                userFeedbackCount = stats.userFeedbackCount + 1
            )
        }

        skillStats[skillId] = updatedStats

        // Calculate new SPI
        val spi = calculateSPI(skillId)

        // Update confidence using exponential moving average
        val alpha = when (config.learningMode) {
            LearningMode.STABLE -> 0.1f
            LearningMode.ADAPTIVE -> 0.2f
            LearningMode.EXPERIMENTAL -> 0.3f
        }

        val newConfidence = skill.confidenceScore + alpha * (responseScore - skill.confidenceScore)

        skills[skillId] = skill.copy(
            confidenceScore = newConfidence.coerceIn(0f, 1f),
            spi = spi
        )

        // Check for promotion/deprecation
        evaluateSkillStatus(skillId, spi)
    }

    /**
     * Get skill by ID
     */
    fun getSkill(id: String): Skill? = skills[id]

    /**
     * Get all skills
     */
    fun getAllSkills(): List<Skill> = skills.values.toList()

    /**
     * Get skills by category
     */
    fun getSkillsByCategory(category: SkillCategory): List<Skill> {
        return skills.values.filter { it.category == category }
    }

    /**
     * Get skill statistics
     */
    fun getSkillStatistics(skillId: String): SkillStatistics? {
        return skillStats[skillId]
    }

    /**
     * Get engine statistics
     */
    fun getEngineStats(): SkillEngineStats {
        val activeSkills = skills.values.count { it.isActive }
        val autoGenerated = skills.values.count { it.autoGenerated }
        val avgSpi = skills.values.map { it.spi }.average().toFloat()

        return SkillEngineStats(
            totalSkills = skills.size,
            activeSkills = activeSkills,
            autoGeneratedSkills = autoGenerated,
            averageSpi = avgSpi,
            totalActivations = skillStats.values.sumOf { it.activationCount },
            topSkills = getTopSkills(5)
        )
    }

    /**
     * Toggle skill active state
     */
    suspend fun toggleSkill(id: String, active: Boolean): Result<Unit> {
        return updateSkill(id, SkillUpdate(isActive = active)).map { }
    }

    /**
     * Export skills
     */
    suspend fun exportSkills(): String = withContext(Dispatchers.IO) {
        val export = SkillExport(
            version = "1.0",
            exportDate = System.currentTimeMillis(),
            skills = skills.values.toList(),
            statistics = skillStats.values.toList()
        )
        Json.encodeToString(export)
    }

    /**
     * Import skills
     */
    suspend fun importSkills(json: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val export = Json.decodeFromString<SkillExport>(json)

            var imported = 0
            export.skills.forEach { skill ->
                if (!skills.containsKey(skill.id)) {
                    skills[skill.id] = skill
                    imported++
                }
            }

            saveSkills()
            buildKeywordIndex()

            Result.success(imported)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Private helpers

    private fun validateSkill(skill: Skill): Boolean {
        return skill.skillName.isNotBlank() &&
               skill.description.isNotBlank() &&
               skill.triggerKeywords.isNotEmpty() &&
               skill.instructionTemplate.isNotBlank()
    }

    private fun calculateActivationConfidence(skill: Skill, input: String): Float {
        val inputLower = input.lowercase()
        val keywordMatches = skill.triggerKeywords.count {
            inputLower.contains(it.lowercase())
        }

        val keywordScore = keywordMatches.toFloat() / skill.triggerKeywords.size
        val confidenceBoost = skill.confidenceScore * 0.3f

        return ((keywordScore * 0.7f) + confidenceBoost).coerceIn(0f, 1f)
    }

    private fun calculateSPI(skillId: String): Float {
        val stats = skillStats[skillId] ?: return 0f
        val skill = skills[skillId] ?: return 0f

        // Average response score
        val avgResponseScore = if (stats.activationCount > 0) {
            stats.totalResponseScore / stats.activationCount
        } else 0f

        // Success rate
        val successRate = if (stats.activationCount > 0) {
            stats.successCount.toFloat() / stats.activationCount
        } else 0f

        // Usage frequency (normalized)
        val usageFreq = (stats.activationCount / 100f).coerceIn(0f, 1f)

        // Recency weight
        val daysSinceLastUse = (System.currentTimeMillis() - stats.lastActivated) /
                (1000 * 60 * 60 * 24)
        val recencyWeight = (1f - (daysSinceLastUse / 30f)).coerceIn(0f, 1f)

        // SPI formula
        return (0.4f * avgResponseScore) +
               (0.3f * successRate) +
               (0.2f * usageFreq) +
               (0.1f * recencyWeight)
    }

    private fun evaluateSkillStatus(skillId: String, spi: Float) {
        val skill = skills[skillId] ?: return

        when {
            spi >= config.spiPromotionThreshold && !skill.isPromoted -> {
                skills[skillId] = skill.copy(isPromoted = true)
                Timber.i("[Skills] Skill promoted: ${skill.skillName} (SPI: $spi)")
            }
            spi <= config.spiDeprecationThreshold && skill.isActive -> {
                skills[skillId] = skill.copy(isActive = false)
                Timber.i("[Skills] Skill deprecated: ${skill.skillName} (SPI: $spi)")
            }
        }
    }

    private fun recordActivation(activation: SkillActivation) {
        activationHistory.add(activation)

        if (activationHistory.size > MAX_HISTORY) {
            activationHistory.removeAt(0)
        }

        // Update statistics
        skillStats[activation.skill.id]?.let { stats ->
            skillStats[activation.skill.id] = stats.copy(
                activationCount = stats.activationCount + 1,
                lastActivated = activation.timestamp
            )
        }
    }

    private fun getTopSkills(limit: Int): List<SkillRanking> {
        return skills.values
            .map { skill ->
                SkillRanking(
                    skill = skill,
                    spi = skill.spi,
                    activationCount = skillStats[skill.id]?.activationCount ?: 0
                )
            }
            .sortedByDescending { it.spi }
            .take(limit)
    }

    private fun buildKeywordIndex() {
        keywordIndex.clear()
        skills.values.forEach { skill ->
            skill.triggerKeywords.forEach { keyword ->
                keywordIndex.computeIfAbsent(keyword.lowercase()) { mutableSetOf() }
                    .add(skill.id)
            }
        }
    }

    private fun removeFromKeywordIndex(skill: Skill) {
        skill.triggerKeywords.forEach { keyword ->
            keywordIndex[keyword.lowercase()]?.remove(skill.id)
        }
    }

    private fun incrementVersion(version: String): String {
        val parts = version.split(".").map { it.toIntOrNull() ?: 0 }
        val major = parts.getOrElse(0) { 1 }
        val minor = parts.getOrElse(1) { 0 }
        val patch = parts.getOrElse(2) { 0 } + 1
        return "$major.$minor.$patch"
    }

    private fun buildSkillGenerationPrompt(
        pattern: String,
        examples: List<String>,
        category: SkillCategory
    ): String {
        return """
            Analyze the following user request pattern and create a structured skill definition.
            
            Pattern: "$pattern"
            Examples:
            ${examples.joinToString("\n") { "- $it" }}
            Category: $category
            
            Generate a skill JSON with these fields:
            - skill_name: concise name (2-4 words)
            - description: what this skill does
            - trigger_keywords: array of 3-7 keywords that activate this skill
            - instruction_template: detailed prompt template with {input} placeholder
            
            Format as valid JSON only.
        """.trimIndent()
    }

    private fun parseGeneratedSkill(text: String, category: SkillCategory): Skill? {
        return try {
            // Extract JSON from text
            val jsonStart = text.indexOf("{")
            val jsonEnd = text.lastIndexOf("}") + 1
            if (jsonStart == -1 || jsonEnd <= jsonStart) return null

            val json = text.substring(jsonStart, jsonEnd)
            val parsed = Json.decodeFromString<GeneratedSkillData>(json)

            Skill(
                id = java.util.UUID.randomUUID().toString(),
                skillName = parsed.skill_name,
                description = parsed.description,
                category = category,
                triggerKeywords = parsed.trigger_keywords,
                instructionTemplate = parsed.instruction_template,
                version = "1.0.0",
                confidenceScore = 0.5f,
                spi = 0.5f,
                isActive = true,
                autoGenerated = true
            )
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to parse generated skill")
            null
        }
    }

    private fun startEvolutionTasks() {
        scope.launch {
            while (isActive) {
                delay(24 * 60 * 60 * 1000)  // Daily

                // Save statistics
                saveStatistics()

                // Evaluate all skills
                skills.keys.forEach { skillId ->
                    val spi = calculateSPI(skillId)
                    evaluateSkillStatus(skillId, spi)
                }
            }
        }
    }

    private suspend fun loadSkills() = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, "$SKILLS_DIR/$SKILLS_FILE")
            if (!file.exists()) return@withContext

            val json = file.readText()
            val skillList = Json.decodeFromString<List<Skill>>(json)

            skillList.forEach { skill ->
                skills[skill.id] = skill
            }
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to load skills")
        }
    }

    private suspend fun saveSkills() = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, "$SKILLS_DIR/$SKILLS_FILE")
            val json = Json.encodeToString(skills.values.toList())
            file.writeText(json)
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to save skills")
        }
    }

    private suspend fun loadStatistics() = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, "$SKILLS_DIR/$STATS_FILE")
            if (!file.exists()) return@withContext

            val json = file.readText()
            val statsList = Json.decodeFromString<List<SkillStatistics>>(json)

            statsList.forEach { stats ->
                skillStats[stats.skillId] = stats
            }
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to load statistics")
        }
    }

    private suspend fun saveStatistics() = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, "$SKILLS_DIR/$STATS_FILE")
            val json = Json.encodeToString(skillStats.values.toList())
            file.writeText(json)
        } catch (e: Exception) {
            Timber.e(e, "[Skills] Failed to save statistics")
        }
    }
}

@kotlinx.serialization.Serializable
private data class GeneratedSkillData(
    val skill_name: String,
    val description: String,
    val trigger_keywords: List<String>,
    val instruction_template: String
)
