package com.nexusz4.memory

import com.nexusz4.memory.model.VectorSearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Vector Database using FAISS-like indexing
 * Optimized for on-device semantic search
 */
@Singleton
class VectorDatabase @Inject constructor() {

    private var isInitialized = false
    private var dimension: Int = 384
    private var indexPath: String = ""

    // In-memory index (simplified - production would use FAISS JNI)
    private val vectors = ConcurrentHashMap<String, FloatArray>()
    private val idToIndex = ConcurrentHashMap<String, Int>()
    private val indexToId = ConcurrentHashMap<Int, String>()
    private var nextIndex = 0

    // Cache statistics
    private var searchCount = 0
    private var cacheHits = 0

    companion object {
        const val INDEX_VERSION = 1
        const val MAX_VECTORS = 100000  // Limit for mobile
    }

    /**
     * Initialize the vector database
     */
    fun initialize(indexPath: String, dimension: Int) {
        this.indexPath = indexPath
        this.dimension = dimension

        // Load existing index if available
        loadIndex()

        isInitialized = true
        Timber.i("[VectorDB] Initialized with dimension=$dimension, vectors=${vectors.size}")
    }

    /**
     * Add a vector to the index
     */
    fun addVector(id: String, vector: FloatArray): Boolean {
        if (!isInitialized) {
            Timber.e("[VectorDB] Not initialized")
            return false
        }

        if (vector.size != dimension) {
            Timber.e("[VectorDB] Dimension mismatch: expected $dimension, got ${vector.size}")
            return false
        }

        if (vectors.size >= MAX_VECTORS) {
            Timber.w("[VectorDB] Maximum capacity reached")
            return false
        }

        // Normalize vector
        val normalized = normalizeVector(vector)

        // Store vector
        vectors[id] = normalized

        // Update index mappings
        if (!idToIndex.containsKey(id)) {
            idToIndex[id] = nextIndex
            indexToId[nextIndex] = id
            nextIndex++
        }

        return true
    }

    /**
     * Update an existing vector
     */
    fun updateVector(id: String, vector: FloatArray): Boolean {
        if (!vectors.containsKey(id)) {
            return false
        }
        return addVector(id, vector)
    }

    /**
     * Remove a vector from the index
     */
    fun removeVector(id: String): Boolean {
        vectors.remove(id)
        idToIndex.remove(id)?.let { index ->
            indexToId.remove(index)
        }
        return true
    }

    /**
     * Search for similar vectors
     */
    fun search(queryVector: FloatArray, k: Int): List<VectorSearchResult> {
        if (!isInitialized || vectors.isEmpty()) {
            return emptyList()
        }

        searchCount++

        // Normalize query
        val normalizedQuery = normalizeVector(queryVector)

        // Calculate cosine similarity with all vectors
        val scores = vectors.map { (id, vector) ->
            val similarity = cosineSimilarity(normalizedQuery, vector)
            VectorSearchResult(
                id = id,
                score = similarity,
                distance = 1f - similarity
            )
        }

        // Return top k results
        return scores
            .sortedByDescending { it.score }
            .take(k)
            .also {
                if (it.isNotEmpty()) cacheHits++
            }
    }

    /**
     * Batch search for multiple queries
     */
    fun batchSearch(
        queryVectors: List<FloatArray>,
        k: Int
    ): List<List<VectorSearchResult>> {
        return queryVectors.map { search(it, k) }
    }

    /**
     * Get vector by ID
     */
    fun getVector(id: String): FloatArray? {
        return vectors[id]
    }

    /**
     * Check if vector exists
     */
    fun hasVector(id: String): Boolean {
        return vectors.containsKey(id)
    }

    /**
     * Get total number of vectors
     */
    fun getSize(): Int = vectors.size

    /**
     * Get index size in bytes
     */
    fun getIndexSize(): Long {
        val vectorSize = dimension * 4  // 4 bytes per float
        return vectors.size * vectorSize.toLong()
    }

    /**
     * Get cache hit rate
     */
    fun getCacheHitRate(): Float {
        return if (searchCount > 0) {
            cacheHits.toFloat() / searchCount
        } else {
            0f
        }
    }

    /**
     * Clear all vectors
     */
    fun clear() {
        vectors.clear()
        idToIndex.clear()
        indexToId.clear()
        nextIndex = 0
        searchCount = 0
        cacheHits = 0
        Timber.i("[VectorDB] Index cleared")
    }

    /**
     * Save index to disk
     */
    suspend fun save() = withContext(Dispatchers.IO) {
        try {
            // Serialize and save
            val file = java.io.File(indexPath)
            file.parentFile?.mkdirs()

            java.io.FileOutputStream(file).use { fos ->
                // Write header
                val header = ByteBuffer.allocate(16)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(INDEX_VERSION)
                    .putInt(dimension)
                    .putInt(vectors.size)
                    .putInt(0)  // Reserved

                fos.write(header.array())

                // Write vectors
                vectors.forEach { (id, vector) ->
                    // Write ID length and ID
                    val idBytes = id.toByteArray(Charsets.UTF_8)
                    fos.write(idBytes.size)
                    fos.write(idBytes)

                    // Write vector
                    val buffer = ByteBuffer.allocate(dimension * 4)
                        .order(ByteOrder.LITTLE_ENDIAN)
                    vector.forEach { buffer.putFloat(it) }
                    fos.write(buffer.array())
                }
            }

            Timber.i("[VectorDB] Index saved: ${vectors.size} vectors")
        } catch (e: Exception) {
            Timber.e(e, "[VectorDB] Failed to save index")
        }
    }

    /**
     * Load index from disk
     */
    private fun loadIndex() {
        try {
            val file = java.io.File(indexPath)
            if (!file.exists()) {
                Timber.i("[VectorDB] No existing index found")
                return
            }

            java.io.FileInputStream(file).use { fis ->
                // Read header
                val header = ByteArray(16)
                fis.read(header)
                val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

                val version = buffer.int
                if (version != INDEX_VERSION) {
                    Timber.w("[VectorDB] Index version mismatch: $version vs $INDEX_VERSION")
                    return
                }

                val dim = buffer.int
                if (dim != dimension) {
                    Timber.w("[VectorDB] Dimension mismatch in saved index")
                }

                val count = buffer.int

                // Read vectors
                repeat(count) {
                    // Read ID
                    val idLength = fis.read()
                    val idBytes = ByteArray(idLength)
                    fis.read(idBytes)
                    val id = String(idBytes, Charsets.UTF_8)

                    // Read vector
                    val vectorBytes = ByteArray(dimension * 4)
                    fis.read(vectorBytes)
                    val vectorBuffer = ByteBuffer.wrap(vectorBytes).order(ByteOrder.LITTLE_ENDIAN)
                    val vector = FloatArray(dimension) { vectorBuffer.getFloat() }

                    vectors[id] = vector
                    idToIndex[id] = nextIndex
                    indexToId[nextIndex] = id
                    nextIndex++
                }
            }

            Timber.i("[VectorDB] Loaded ${vectors.size} vectors from disk")
        } catch (e: Exception) {
            Timber.e(e, "[VectorDB] Failed to load index")
        }
    }

    // Mathematical operations

    private fun normalizeVector(vector: FloatArray): FloatArray {
        val magnitude = kotlin.math.sqrt(vector.sumOf { it * it.toDouble() }).toFloat()
        return if (magnitude > 0) {
            vector.map { it / magnitude }.toFloatArray()
        } else {
            vector
        }
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dotProduct = 0f
        for (i in a.indices) {
            dotProduct += a[i] * b[i]
        }
        return dotProduct.coerceIn(0f, 1f)
    }

    private fun euclideanDistance(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) {
            val diff = a[i] - b[i]
            sum += diff * diff
        }
        return kotlin.math.sqrt(sum)
    }
}
