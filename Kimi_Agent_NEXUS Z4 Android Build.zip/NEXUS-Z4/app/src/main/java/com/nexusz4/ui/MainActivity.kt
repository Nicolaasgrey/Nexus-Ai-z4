package com.nexusz4.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nexusz4.ui.screens.*
import com.nexusz4.ui.theme.NEXUSZ4Theme
import com.nexusz4.ui.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            NEXUSZ4Theme {
                val navController = rememberNavController()

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(navController = navController, viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    navController: NavHostController,
    viewModel: MainViewModel
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Screen.Chat.icon, contentDescription = "Chat") },
                    label = { Text("Chat") },
                    selected = currentRoute == Screen.Chat.route,
                    onClick = { navController.navigate(Screen.Chat.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Screen.Memory.icon, contentDescription = "Memory") },
                    label = { Text("Memory") },
                    selected = currentRoute == Screen.Memory.route,
                    onClick = { navController.navigate(Screen.Memory.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Screen.Skills.icon, contentDescription = "Skills") },
                    label = { Text("Skills") },
                    selected = currentRoute == Screen.Skills.route,
                    onClick = { navController.navigate(Screen.Skills.route) }
                )
                NavigationBarItem(
                    icon = { Icon(Screen.System.icon, contentDescription = "System") },
                    label = { Text("System") },
                    selected = currentRoute == Screen.System.route,
                    onClick = { navController.navigate(Screen.System.route) }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chat.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Chat.route) {
                ChatScreen(viewModel = viewModel)
            }
            composable(Screen.Memory.route) {
                MemoryScreen(viewModel = viewModel)
            }
            composable(Screen.Skills.route) {
                SkillsScreen(viewModel = viewModel)
            }
            composable(Screen.System.route) {
                SystemScreen(viewModel = viewModel)
            }
        }
    }
}

sealed class Screen(
    val route: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    object Chat : Screen("chat", androidx.compose.material.icons.Icons.Default.Chat)
    object Memory : Screen("memory", androidx.compose.material.icons.Icons.Default.Storage)
    object Skills : Screen("skills", androidx.compose.material.icons.Icons.Default.Build)
    object System : Screen("system", androidx.compose.material.icons.Icons.Default.Settings)
}
