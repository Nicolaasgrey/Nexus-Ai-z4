package com.nexusz4.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexusz4.memory.model.MemoryStats
import com.nexusz4.memory.model.MemoryType
import com.nexusz4.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    viewModel: MainViewModel = hiltViewModel()
) {
    val memoryStats by viewModel.memoryStats.collectAsState()
    var showClearDialog by remember { mutableStateOf(false) }
    var showRebuildDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Memory Manager") },
                actions = {
                    IconButton(onClick = { viewModel.refreshMemoryStats() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stats Card
            item {
                MemoryStatsCard(stats = memoryStats)
            }

            // Actions
            item {
                Text(
                    "Actions",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                MemoryActionCard(
                    title = "Upload Document",
                    description = "Add PDF, TXT, or Markdown files to memory",
                    icon = Icons.Default.UploadFile,
                    onClick = { /* TODO: File picker */ }
                )
            }

            item {
                MemoryActionCard(
                    title = "Rebuild Index",
                    description = "Rebuild the vector search index",
                    icon = Icons.Default.Build,
                    onClick = { showRebuildDialog = true }
                )
            }

            item {
                MemoryActionCard(
                    title = "Clear All Memory",
                    description = "Delete all stored memories (cannot be undone)",
                    icon = Icons.Default.DeleteForever,
                    isDestructive = true,
                    onClick = { showClearDialog = true }
                )
            }

            // Memory Types
            item {
                Text(
                    "Memory Types",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(MemoryType.values()) { type ->
                MemoryTypeCard(
                    type = type,
                    count = memoryStats?.byType?.get(type) ?: 0
                )
            }
        }
    }

    // Clear confirmation dialog
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear All Memory?") },
            text = {
                Text("This will permanently delete all stored memories. This action cannot be undone.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearMemory()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Rebuild confirmation dialog
    if (showRebuildDialog) {
        AlertDialog(
            onDismissRequest = { showRebuildDialog = false },
            title = { Text("Rebuild Index?") },
            text = {
                Text("This will rebuild the vector search index. It may take a few minutes depending on the amount of data.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.rebuildMemoryIndex()
                        showRebuildDialog = false
                    }
                ) {
                    Text("Rebuild")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRebuildDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun MemoryStatsCard(stats: MemoryStats?) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                "Memory Statistics",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (stats != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatItem(
                        value = stats.totalEntries.toString(),
                        label = "Total Entries"
                    )
                    StatItem(
                        value = "${(stats.vectorIndexSize / 1024 / 1024)} MB",
                        label = "Index Size"
                    )
                    StatItem(
                        value = "${(stats.cacheHitRate * 100).toInt()}%",
                        label = "Cache Hit"
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Domain distribution
                Text(
                    "Domains",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                stats.byDomain.forEach { (domain, count) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            domain.replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            count.toString(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

@Composable
fun StatItem(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun MemoryActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val contentColor = if (isDestructive) {
        MaterialTheme.colorScheme.error
    } else {
        MaterialTheme.colorScheme.primary
    }

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MemoryTypeCard(type: MemoryType, count: Int) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = when (type) {
                        MemoryType.CONVERSATION -> Icons.Default.Chat
                        MemoryType.DOCUMENT -> Icons.Default.Description
                        MemoryType.NOTE -> Icons.Default.Note
                        MemoryType.JOURNAL -> Icons.Default.Book
                        MemoryType.STRATEGY -> Icons.Default.Psychology
                        MemoryType.CODE -> Icons.Default.Code
                        MemoryType.FACT -> Icons.Default.Lightbulb
                        MemoryType.SKILL_CONTEXT -> Icons.Default.Build
                        MemoryType.USER_PREFERENCE -> Icons.Default.Settings
                        MemoryType.SYSTEM_STATE -> Icons.Default.Computer
                    },
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    type.name.replace("_", " ").lowercase()
                        .replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Text(
                count.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
