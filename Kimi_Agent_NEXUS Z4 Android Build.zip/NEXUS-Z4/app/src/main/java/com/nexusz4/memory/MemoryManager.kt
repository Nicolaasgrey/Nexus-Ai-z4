package com.nexusz4.memory

import android.content.Context
import com.nexusz4.memory.model.*
import com.nexusz4.security.EncryptionManager
import com.nexusz4.system.PerformanceMonitor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Memory Manager - RAG Architecture
 * Manages vector database, embeddings, and semantic search
 */
@Singleton
class MemoryManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val vectorDatabase: VectorDatabase,
    private val embeddingEngine: EmbeddingEngine,
    private val encryptionManager: EncryptionManager,
    private val performanceMonitor: PerformanceMonitor
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Memory cache for fast access
    private val memoryCache = ConcurrentHashMap<String, MemoryEntry>()

    // Active domains
    private val activeDomains = mutableSetOf("general", "personal", "knowledge")

    // Configuration
    private var config = MemoryConfig()
    private var isInitialized = false

    data class MemoryConfig(
        val chunkSize: Int = 512,
        val chunkOverlap: Int = 128,
        val maxRetrievalResults: Int = 5,
        val similarityThreshold: Float = 0.7f,
        val memoryEnabled: Boolean = true,
        val autoDecay: Boolean = true,
        val decayDays: Int = 90
    )

    companion object {
        const val MEMORY_DIR = "memory"
        const val VECTOR_INDEX_FILE = "vector_index.faiss"
        const val METADATA_DB = "memory_metadata.db"
        const val EMBEDDING_DIMENSION = 384  // MiniLM dimension
    }

    /**
     * Initialize memory system
     */
    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext

        try {
            Timber.i("[Memory] Initializing memory system...")

            // Create memory directory
            val memoryDir = File(context.filesDir, MEMORY_DIR)
            memoryDir.mkdirs()

            // Initialize vector database
            vectorDatabase.initialize(
                indexPath = File(memoryDir, VECTOR_INDEX_FILE).absolutePath,
                dimension = EMBEDDING_DIMENSION
            )

            // Initialize embedding engine
            embeddingEngine.initialize()

            // Load existing memories into cache
            loadMemoryCache()

            // Start maintenance tasks
            startMaintenanceTasks()

            isInitialized = true
            Timber.i("[Memory] Memory system initialized. Cached entries: ${memoryCache.size}")
        } catch (e: Exception) {
            Timber.e(e, "[Memory] Failed to initialize")
            throw e
        }
    }

    /**
     * Store a new memory entry
     */
    suspend fun storeMemory(
        content: String,
        type: MemoryType,
        domain: String = "general",
        metadata: Map<String, String> = emptyMap(),
        source: String? = null
    ): Result<MemoryEntry> = withContext(Dispatchers.IO) {
        try {
            // Chunk content if needed
            val chunks = chunkContent(content)

            val entries = chunks.mapIndexed { index, chunk ->
                // Generate embedding
                val embedding = embeddingEngine.embed(chunk)

                // Create entry
                val entry = MemoryEntry(
                    id = generateId(),
                    content = chunk,
                    type = type,
                    domain = domain,
                    embedding = embedding,
                    metadata = metadata + mapOf(
                        "chunk_index" to index.toString(),
                        "total_chunks" to chunks.size.toString(),
                        "source" to (source ?: "direct")
                    ),
                    timestamp = System.currentTimeMillis()
                )

                // Store in vector DB
                vectorDatabase.addVector(entry.id, embedding)

                // Cache entry
                memoryCache[entry.id] = entry

                entry
            }

            // Save metadata
            saveMetadata(entries)

            Timber.i("[Memory] Stored ${entries.size} chunks for $type memory")
            Result.success(entries.first())
        } catch (e: Exception) {
            Timber.e(e, "[Memory] Failed to store memory")
            Result.failure(e)
        }
    }

    /**
     * Retrieve relevant memories based on query
     */
    suspend fun retrieveRelevant(
        query: String,
        limit: Int = config.maxRetrievalResults,
        domains: List<String>? = null,
        minScore: Float = config.similarityThreshold
    ): List<RetrievedMemory> = withContext(Dispatchers.IO) {
        if (!config.memoryEnabled) {
            return@withContext emptyList()
        }

        try {
            // Generate query embedding
            val queryEmbedding = embeddingEngine.embed(query)

            // Search vector database
            val searchResults = vectorDatabase.search(
                queryVector = queryEmbedding,
                k = limit * 2  // Get more for filtering
            )

            // Filter and score results
            val results = searchResults.mapNotNull { result ->
                val entry = memoryCache[result.id] ?: return@mapNotNull null

                // Domain filter
                if (domains != null && entry.domain !in domains) {
                    return@mapNotNull null
                }

                // Calculate final relevance score
                val finalScore = calculateRelevanceScore(result.score, entry)

                if (finalScore < minScore) {
                    return@mapNotNull null
                }

                RetrievedMemory(
                    entry = entry,
                    similarityScore = finalScore,
                    vectorScore = result.score
                )
            }
            .sortedByDescending { it.similarityScore }
            .take(limit)

            // Update access stats
            results.forEach { updateAccessStats(it.entry.id) }

            Timber.d("[Memory] Retrieved ${results.size} relevant memories for query")
            results
        } catch (e: Exception) {
            Timber.e(e, "[Memory] Retrieval failed")
            emptyList()
        }
    }

    /**
     * Retrieve with context building for LLM prompt
     */
    suspend fun retrieveForContext(
        query: String,
        maxTokens: Int = 1500
    ): String = withContext(Dispatchers.IO) {
        val memories = retrieveRelevant(query, limit = 10)

        if (memories.isEmpty()) {
            return@withContext ""
        }

        val contextBuilder = StringBuilder()
        contextBuilder.appendLine("=== RELEVANT CONTEXT ===")

        var tokenCount = 0
        val tokensPerChar = 0.25  // Rough estimate

        for (memory in memories) {
            val content = memory.entry.content
            val estimatedTokens = (content.length * tokensPerChar).toInt()

            if (tokenCount + estimatedTokens > maxTokens) {
                break
            }

            contextBuilder.appendLine("[${memory.entry.domain}] ${memory.entry.type}: $content")
            tokenCount += estimatedTokens
        }

        contextBuilder.appendLine("=== END CONTEXT ===")

        contextBuilder.toString()
    }

    /**
     * Delete a memory entry
     */
    suspend fun deleteMemory(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            vectorDatabase.removeVector(id)
            memoryCache.remove(id)
            deleteMetadata(id)
            Timber.i("[Memory] Deleted memory: $id")
            Result.success(Unit)
        } catch (e: Exception) {
            Timber.e(e, "[Memory] Failed to delete memory: $id")
            Result.failure(e)
        }
    }

    /**
     * Update memory entry
     */
    suspend fun updateMemory(
        id: String,
        content: String? = null,
        metadata: Map<String, String>? = null
    ): Result<MemoryEntry> = withContext(Dispatchers.IO) {
        try {
            val existing = memoryCache[id]
                ?: return@withContext Result.failure(IllegalArgumentException("Memory not found: $id"))

            val updated = existing.copy(
                content = content ?: existing.content,
                metadata = metadata?.let { existing.metadata + it } ?: existing.metadata,
                timestamp = System.currentTimeMillis()
            )

            // Re-embed if content changed
            if (content != null) {
                val newEmbedding = embeddingEngine.embed(content)
                vectorDatabase.updateVector(id, newEmbedding)
                updated.copy(embedding = newEmbedding)
            }

            memoryCache[id] = updated
            saveMetadata(listOf(updated))

            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get memories by domain
     */
    fun getMemoriesByDomain(domain: String): List<MemoryEntry> {
        return memoryCache.values.filter { it.domain == domain }
    }

    /**
     * Get memory statistics
     */
    fun getStats(): MemoryStats {
        val byType = memoryCache.values.groupingBy { it.type }.eachCount()
        val byDomain = memoryCache.values.groupingBy { it.domain }.eachCount()

        return MemoryStats(
            totalEntries = memoryCache.size,
            byType = byType,
            byDomain = byDomain,
            vectorIndexSize = vectorDatabase.getIndexSize(),
            cacheHitRate = vectorDatabase.getCacheHitRate()
        )
    }

    /**
     * Rebuild vector index from scratch
     */
    suspend fun rebuildIndex(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            Timber.i("[Memory] Rebuilding vector index...")

            // Clear existing index
            vectorDatabase.clear()

            // Re-add all entries
            memoryCache.values.forEach { entry ->
                vectorDatabase.addVector(entry.id, entry.embedding)
            }

            vectorDatabase.save()

            Timber.i("[Memory] Index rebuilt with ${memoryCache.size} entries")
            Result.success(Unit)
        } catch (e: Exception) {
            Timber.e(e, "[Memory] Index rebuild failed")
            Result.failure(e)
        }
    }

    /**
     * Clear all memories
     */
    suspend fun clearAll(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            vectorDatabase.clear()
            memoryCache.clear()
            clearMetadata()
            Timber.i("[Memory] All memories cleared")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Update configuration
     */
    fun updateConfig(newConfig: MemoryConfig) {
        config = newConfig
        Timber.i("[Memory] Config updated: memoryEnabled=${config.memoryEnabled}")
    }

    /**
     * Toggle memory system
     */
    fun setMemoryEnabled(enabled: Boolean) {
        config = config.copy(memoryEnabled = enabled)
    }

    /**
     * Check if memory is enabled
     */
    fun isMemoryEnabled(): Boolean = config.memoryEnabled

    // Private helpers

    private fun chunkContent(content: String): List<String> {
        if (content.length <= config.chunkSize) {
            return listOf(content)
        }

        val chunks = mutableListOf<String>()
        var start = 0

        while (start < content.length) {
            val end = minOf(start + config.chunkSize, content.length)
            val chunk = content.substring(start, end)
            chunks.add(chunk)
            start += config.chunkSize - config.chunkOverlap
        }

        return chunks
    }

    private fun calculateRelevanceScore(vectorScore: Float, entry: MemoryEntry): Float {
        // Base score from vector similarity
        var score = vectorScore

        // Boost by recency
        val ageDays = (System.currentTimeMillis() - entry.timestamp) / (1000 * 60 * 60 * 24)
        val recencyBoost = (1f - (ageDays / config.decayDays.toFloat()).coerceIn(0f, 1f)) * 0.1f

        // Boost by access frequency
        val frequencyBoost = (entry.accessCount / 100f).coerceIn(0f, 1f) * 0.05f

        return (score + recencyBoost + frequencyBoost).coerceIn(0f, 1f)
    }

    private fun updateAccessStats(id: String) {
        memoryCache[id]?.let { entry ->
            memoryCache[id] = entry.copy(
                accessCount = entry.accessCount + 1,
                lastAccessed = System.currentTimeMillis()
            )
        }
    }

    private fun loadMemoryCache() {
        // Load from persistent storage
        // Implementation depends on storage backend
    }

    private fun saveMetadata(entries: List<MemoryEntry>) {
        // Persist to encrypted storage
    }

    private fun deleteMetadata(id: String) {
        // Remove from persistent storage
    }

    private fun clearMetadata() {
        // Clear all metadata
    }

    private fun generateId(): String {
        return java.util.UUID.randomUUID().toString()
    }

    private fun startMaintenanceTasks() {
        scope.launch {
            while (isActive) {
                delay(60 * 60 * 1000)  // Every hour

                if (config.autoDecay) {
                    decayOldMemories()
                }

                cleanupUnusedMemories()
            }
        }
    }

    private fun decayOldMemories() {
        val cutoff = System.currentTimeMillis() - (config.decayDays * 24 * 60 * 60 * 1000)

        memoryCache.values
            .filter { it.lastAccessed < cutoff && it.accessCount < 3 }
            .forEach { entry ->
                scope.launch {
                    deleteMemory(entry.id)
                }
            }
    }

    private fun cleanupUnusedMemories() {
        // Remove low-relevance memories if cache is too large
        if (memoryCache.size > 10000) {
            val toRemove = memoryCache.values
                .sortedBy { it.accessCount }
                .take(1000)

            toRemove.forEach { entry ->
                scope.launch {
                    deleteMemory(entry.id)
                }
            }
        }
    }
}
