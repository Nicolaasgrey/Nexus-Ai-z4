package com.nexusz4.system

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.Process
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.io.File
import java.io.RandomAccessFile
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min

/**
 * Performance Monitor
 * Tracks hardware metrics and manages cognitive scaling
 */
@Singleton
class PerformanceMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // System services
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    // Metrics state
    private val _metrics = MutableStateFlow(SystemMetrics())
    val metrics: StateFlow<SystemMetrics> = _metrics.asStateFlow()

    // Cognitive level
    private val _cognitiveLevel = MutableStateFlow(2)  // Default: Normal
    val cognitiveLevel: StateFlow<Int> = _cognitiveLevel.asStateFlow()

    // Monitoring state
    private var monitoringJob: Job? = null
    private var isMonitoring = false

    // Thermal state tracking
    private var thermalThrottlingDetected = false
    private var lastThermalCheck = 0L

    data class SystemMetrics(
        val ramUsedPercent: Float = 0f,
        val ramAvailableMb: Long = 0,
        val cpuUsagePercent: Float = 0f,
        val gpuUsagePercent: Float = 0f,
        val batteryPercent: Int = 100,
        val batteryTemperature: Float = 0f,
        val isCharging: Boolean = false,
        val isPowerSaveMode: Boolean = false,
        val thermalStatus: Int = 0,
        val timestamp: Long = System.currentTimeMillis()
    )

    companion object {
        const val TAG = "[Performance]"

        // Thresholds
        const val RAM_CRITICAL_THRESHOLD = 90f
        const val RAM_HIGH_THRESHOLD = 80f
        const val RAM_MODERATE_THRESHOLD = 70f

        const val CPU_CRITICAL_THRESHOLD = 90f
        const val CPU_HIGH_THRESHOLD = 75f
        const val CPU_MODERATE_THRESHOLD = 60f

        const val BATTERY_LOW_THRESHOLD = 20
        const val BATTERY_CRITICAL_THRESHOLD = 10

        const val TEMPERATURE_HIGH_THRESHOLD = 45f
        const val TEMPERATURE_CRITICAL_THRESHOLD = 50f

        // Sampling intervals
        const val METRICS_INTERVAL_MS = 5000L
        const val THERMAL_CHECK_INTERVAL_MS = 30000L
    }

    /**
     * Start performance monitoring
     */
    fun startMonitoring() {
        if (isMonitoring) return

        isMonitoring = true
        monitoringJob = scope.launch {
            while (isActive) {
                updateMetrics()
                delay(METRICS_INTERVAL_MS)
            }
        }

        Timber.i("$TAG Performance monitoring started")
    }

    /**
     * Stop monitoring
     */
    fun stopMonitoring() {
        monitoringJob?.cancel()
        isMonitoring = false
        Timber.i("$TAG Performance monitoring stopped")
    }

    /**
     * Get current metrics snapshot
     */
    fun getCurrentMetrics(): SystemMetrics = _metrics.value

    /**
     * Get current cognitive level (0-4)
     * 0 = Critical (minimal operations)
     * 1 = Low (reduced capabilities)
     * 2 = Normal (standard operation)
     * 3 = High (enhanced capabilities)
     * 4 = Optimal (maximum performance)
     */
    fun getCognitiveLevel(): Int = _cognitiveLevel.value

    /**
     * Emergency reduce - called on critical memory pressure
     */
    fun emergencyReduce() {
        _cognitiveLevel.value = 0
        Timber.w("$TAG EMERGENCY: Cognitive level reduced to 0")
    }

    /**
     * Scale down - called on low memory
     */
    fun scaleDown() {
        val current = _cognitiveLevel.value
        if (current > 1) {
            _cognitiveLevel.value = current - 1
            Timber.w("$TAG Scaled down to level ${_cognitiveLevel.value}")
        }
    }

    /**
     * Check if system can handle intensive task
     */
    fun canHandleIntensiveTask(): Boolean {
        val m = _metrics.value
        return m.ramUsedPercent < RAM_HIGH_THRESHOLD &&
               m.cpuUsagePercent < CPU_HIGH_THRESHOLD &&
               m.batteryPercent > BATTERY_LOW_THRESHOLD &&
               !m.isPowerSaveMode
    }

    /**
     * Get recommended max tokens based on current state
     */
    fun getRecommendedMaxTokens(): Int {
        return when (_cognitiveLevel.value) {
            0 -> 512    // Critical
            1 -> 1024   // Low
            2 -> 2048   // Normal
            3 -> 3072   // High
            4 -> 4096   // Optimal
            else -> 2048
        }
    }

    /**
     * Get recommended batch size
     */
    fun getRecommendedBatchSize(): Int {
        return when (_cognitiveLevel.value) {
            0 -> 128
            1 -> 256
            2 -> 512
            3 -> 768
            4 -> 1024
            else -> 512
        }
    }

    /**
     * Check if GPU acceleration should be used
     */
    fun shouldUseGpu(): Boolean {
        val m = _metrics.value
        return m.batteryPercent > BATTERY_LOW_THRESHOLD &&
               !m.isPowerSaveMode &&
               m.batteryTemperature < TEMPERATURE_HIGH_THRESHOLD &&
               _cognitiveLevel.value >= 2
    }

    /**
     * Get memory status string
     */
    fun getMemoryStatus(): String {
        val m = _metrics.value
        return when {
            m.ramUsedPercent >= RAM_CRITICAL_THRESHOLD -> "CRITICAL"
            m.ramUsedPercent >= RAM_HIGH_THRESHOLD -> "HIGH"
            m.ramUsedPercent >= RAM_MODERATE_THRESHOLD -> "MODERATE"
            else -> "NORMAL"
        }
    }

    /**
     * Get thermal status
     */
    fun getThermalStatus(): String {
        val m = _metrics.value
        return when {
            m.batteryTemperature >= TEMPERATURE_CRITICAL_THRESHOLD -> "CRITICAL"
            m.batteryTemperature >= TEMPERATURE_HIGH_THRESHOLD -> "HIGH"
            else -> "NORMAL"
        }
    }

    // Private methods

    private suspend fun updateMetrics() = withContext(Dispatchers.IO) {
        try {
            val memoryInfo = getMemoryInfo()
            val cpuUsage = getCpuUsage()
            val batteryInfo = getBatteryInfo()
            val thermalStatus = getThermalStatusInternal()

            val metrics = SystemMetrics(
                ramUsedPercent = memoryInfo.usedPercent,
                ramAvailableMb = memoryInfo.availableMb,
                cpuUsagePercent = cpuUsage,
                gpuUsagePercent = 0f,  // GPU usage requires vendor-specific APIs
                batteryPercent = batteryInfo.level,
                batteryTemperature = batteryInfo.temperature,
                isCharging = batteryInfo.isCharging,
                isPowerSaveMode = powerManager.isPowerSaveMode,
                thermalStatus = thermalStatus
            )

            _metrics.value = metrics

            // Update cognitive level
            updateCognitiveLevel(metrics)

            // Check for thermal throttling
            checkThermalThrottling(metrics)

        } catch (e: Exception) {
            Timber.e(e, "$TAG Failed to update metrics")
        }
    }

    private fun updateCognitiveLevel(metrics: SystemMetrics) {
        val newLevel = calculateCognitiveLevel(metrics)

        if (newLevel != _cognitiveLevel.value) {
            _cognitiveLevel.value = newLevel
            Timber.d("$TAG Cognitive level changed to $newLevel")
        }
    }

    private fun calculateCognitiveLevel(metrics: SystemMetrics): Int {
        // Start with normal level
        var level = 2

        // RAM impact
        level -= when {
            metrics.ramUsedPercent >= RAM_CRITICAL_THRESHOLD -> 2
            metrics.ramUsedPercent >= RAM_HIGH_THRESHOLD -> 1
            metrics.ramUsedPercent < RAM_MODERATE_THRESHOLD -> 0
            else -> 0
        }

        // CPU impact
        level -= when {
            metrics.cpuUsagePercent >= CPU_CRITICAL_THRESHOLD -> 1
            metrics.cpuUsagePercent >= CPU_HIGH_THRESHOLD -> 0
            else -> 0
        }

        // Battery impact
        level -= when {
            metrics.batteryPercent <= BATTERY_CRITICAL_THRESHOLD -> 2
            metrics.batteryPercent <= BATTERY_LOW_THRESHOLD -> 1
            else -> 0
        }

        // Temperature impact
        level -= when {
            metrics.batteryTemperature >= TEMPERATURE_CRITICAL_THRESHOLD -> 2
            metrics.batteryTemperature >= TEMPERATURE_HIGH_THRESHOLD -> 1
            else -> 0
        }

        // Power save mode
        if (metrics.isPowerSaveMode) {
            level -= 1
        }

        // Charging bonus
        if (metrics.isCharging && metrics.batteryPercent > 50) {
            level += 1
        }

        return level.coerceIn(0, 4)
    }

    private fun checkThermalThrottling(metrics: SystemMetrics) {
        val now = System.currentTimeMillis()

        if (now - lastThermalCheck > THERMAL_CHECK_INTERVAL_MS) {
            lastThermalCheck = now

            if (metrics.batteryTemperature >= TEMPERATURE_HIGH_THRESHOLD) {
                if (!thermalThrottlingDetected) {
                    thermalThrottlingDetected = true
                    Timber.w("$TAG Thermal throttling detected: ${metrics.batteryTemperature}°C")
                }
            } else {
                if (thermalThrottlingDetected) {
                    thermalThrottlingDetected = false
                    Timber.i("$TAG Thermal throttling ended")
                }
            }
        }
    }

    private fun getMemoryInfo(): MemoryInfo {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalMem = memoryInfo.totalMem
        val availMem = memoryInfo.availMem
        val usedMem = totalMem - availMem
        val usedPercent = (usedMem.toFloat() / totalMem.toFloat()) * 100

        return MemoryInfo(
            usedPercent = usedPercent,
            availableMb = availMem / (1024 * 1024)
        )
    }

    private fun getCpuUsage(): Float {
        return try {
            val pid = Process.myPid()
            val reader = RandomAccessFile("/proc/$pid/stat", "r")
            val line = reader.readLine()
            reader.close()

            // Parse CPU time from stat file
            val parts = line.split(" ")
            if (parts.size > 13) {
                val utime = parts[13].toLong()
                val stime = parts[14].toLong()
                val totalTime = utime + stime

                // This is a simplified calculation
                // Real CPU usage requires sampling over time
                (totalTime % 100).toFloat()
            } else {
                0f
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun getBatteryInfo(): BatteryInfo {
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

        // Temperature requires battery intent (simplified)
        val temperature = getBatteryTemperature()

        return BatteryInfo(
            level = level,
            temperature = temperature,
            isCharging = isCharging
        )
    }

    private fun getBatteryTemperature(): Float {
        return try {
            val reader = RandomAccessFile("/sys/class/power_supply/battery/temp", "r")
            val temp = reader.readLine().toFloat() / 10f
            reader.close()
            temp
        } catch (e: Exception) {
            25f  // Default room temperature
        }
    }

    private fun getThermalStatusInternal(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            powerManager.currentThermalStatus
        } else {
            0
        }
    }

    data class MemoryInfo(
        val usedPercent: Float,
        val availableMb: Long
    )

    data class BatteryInfo(
        val level: Int,
        val temperature: Float,
        val isCharging: Boolean
    )
}

/**
 * Cognitive scaling configuration
 */
data class CognitiveScalingConfig(
    val level: Int,
    val maxTokens: Int,
    val batchSize: Int,
    val useReflection: Boolean,
    val useCritic: Boolean,
    val maxRetrievalResults: Int,
    val embeddingChunkSize: Int,
    val skillEvaluationFrequency: Int
) {
    companion object {
        fun forLevel(level: Int): CognitiveScalingConfig {
            return when (level) {
                0 -> CognitiveScalingConfig(  // Critical
                    level = 0,
                    maxTokens = 512,
                    batchSize = 128,
                    useReflection = false,
                    useCritic = false,
                    maxRetrievalResults = 2,
                    embeddingChunkSize = 256,
                    skillEvaluationFrequency = 10
                )
                1 -> CognitiveScalingConfig(  // Low
                    level = 1,
                    maxTokens = 1024,
                    batchSize = 256,
                    useReflection = false,
                    useCritic = false,
                    maxRetrievalResults = 3,
                    embeddingChunkSize = 384,
                    skillEvaluationFrequency = 5
                )
                2 -> CognitiveScalingConfig(  // Normal
                    level = 2,
                    maxTokens = 2048,
                    batchSize = 512,
                    useReflection = true,
                    useCritic = false,
                    maxRetrievalResults = 5,
                    embeddingChunkSize = 512,
                    skillEvaluationFrequency = 3
                )
                3 -> CognitiveScalingConfig(  // High
                    level = 3,
                    maxTokens = 3072,
                    batchSize = 768,
                    useReflection = true,
                    useCritic = true,
                    maxRetrievalResults = 7,
                    embeddingChunkSize = 640,
                    skillEvaluationFrequency = 2
                )
                4 -> CognitiveScalingConfig(  // Optimal
                    level = 4,
                    maxTokens = 4096,
                    batchSize = 1024,
                    useReflection = true,
                    useCritic = true,
                    maxRetrievalResults = 10,
                    embeddingChunkSize = 768,
                    skillEvaluationFrequency = 1
                )
                else -> forLevel(2)
            }
        }
    }
}
