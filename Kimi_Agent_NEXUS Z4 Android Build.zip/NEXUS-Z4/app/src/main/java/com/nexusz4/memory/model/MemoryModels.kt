package com.nexusz4.memory.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Memory entry - core unit of the RAG system
 */
@Serializable
@Entity(tableName = "memories")
@TypeConverters(Converters::class)
data class MemoryEntry(
    @PrimaryKey
    val id: String,
    val content: String,
    val type: MemoryType,
    val domain: String = "general",
    val embedding: FloatArray,
    val metadata: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis(),
    val lastAccessed: Long = System.currentTimeMillis(),
    val accessCount: Int = 0,
    val relevanceScore: Float = 1.0f
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as MemoryEntry

        if (id != other.id) return false
        if (content != other.content) return false
        if (type != other.type) return false
        if (domain != other.domain) return false
        if (!embedding.contentEquals(other.embedding)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + content.hashCode()
        result = 31 * result + type.hashCode()
        result = 31 * result + domain.hashCode()
        result = 31 * result + embedding.contentHashCode()
        return result
    }

    fun getPreview(maxLength: Int = 100): String {
        return if (content.length <= maxLength) {
            content
        } else {
            content.substring(0, maxLength) + "..."
        }
    }
}

/**
 * Memory types for categorization
 */
enum class MemoryType {
    CONVERSATION,      // Chat history
    DOCUMENT,         // Ingested files
    NOTE,             // User notes
    JOURNAL,          // Journal entries
    STRATEGY,         // Strategic documents
    CODE,             // Code snippets
    FACT,             // Learned facts
    SKILL_CONTEXT,    // Skill-related context
    USER_PREFERENCE,  // User preferences
    SYSTEM_STATE      // System information
}

/**
 * Retrieved memory with relevance scoring
 */
@Serializable
data class RetrievedMemory(
    val entry: MemoryEntry,
    val similarityScore: Float,
    val vectorScore: Float
) {
    val isHighlyRelevant: Boolean
        get() = similarityScore > 0.85f

    val isModeratelyRelevant: Boolean
        get() = similarityScore in 0.7f..0.85f
}

/**
 * Memory domain for organization
 */
@Serializable
data class MemoryDomain(
    val id: String,
    val name: String,
    val description: String,
    val color: String,  // Hex color
    val priority: Int = 0,
    val autoInclude: Boolean = true
) {
    companion object {
        val DEFAULT_DOMAINS = listOf(
            MemoryDomain(
                id = "general",
                name = "General",
                description = "General knowledge and conversations",
                color = "#6366F1",
                priority = 0,
                autoInclude = true
            ),
            MemoryDomain(
                id = "personal",
                name = "Personal",
                description = "Personal information and preferences",
                color = "#EC4899",
                priority = 1,
                autoInclude = true
            ),
            MemoryDomain(
                id = "work",
                name = "Work",
                description = "Work-related documents and notes",
                color = "#3B82F6",
                priority = 2,
                autoInclude = true
            ),
            MemoryDomain(
                id = "knowledge",
                name = "Knowledge Base",
                description = "Reference materials and facts",
                color = "#10B981",
                priority = 3,
                autoInclude = true
            ),
            MemoryDomain(
                id = "projects",
                name = "Projects",
                description = "Project-specific information",
                color = "#F59E0B",
                priority = 4,
                autoInclude = false
            ),
            MemoryDomain(
                id = "archive",
                name = "Archive",
                description = "Archived memories",
                color = "#6B7280",
                priority = 5,
                autoInclude = false
            )
        )
    }
}

/**
 * Memory statistics
 */
@Serializable
data class MemoryStats(
    val totalEntries: Int,
    val byType: Map<MemoryType, Int>,
    val byDomain: Map<String, Int>,
    val vectorIndexSize: Long,
    val cacheHitRate: Float,
    val lastMaintenance: Long = System.currentTimeMillis()
) {
    fun getMostCommonType(): MemoryType? {
        return byType.maxByOrNull { it.value }?.key
    }

    fun getMostPopulatedDomain(): String? {
        return byDomain.maxByOrNull { it.value }?.key
    }
}

/**
 * Search query for memory retrieval
 */
@Serializable
data class MemoryQuery(
    val text: String,
    val domains: List<String>? = null,
    val types: List<MemoryType>? = null,
    val timeRange: TimeRange? = null,
    val limit: Int = 5,
    val minScore: Float = 0.7f,
    val includeMetadata: Boolean = false
)

@Serializable
data class TimeRange(
    val start: Long,
    val end: Long = System.currentTimeMillis()
)

/**
 * Search result from vector database
 */
@Serializable
data class VectorSearchResult(
    val id: String,
    val score: Float,
    val distance: Float
)

/**
 * File ingestion result
 */
@Serializable
data class IngestionResult(
    val success: Boolean,
    val fileName: String,
    val chunksCreated: Int,
    val memoriesStored: Int,
    val errors: List<String> = emptyList(),
    val processingTimeMs: Long = 0
)

/**
 * Memory import/export data
 */
@Serializable
data class MemoryExport(
    val version: String = "1.0",
    val exportDate: Long = System.currentTimeMillis(),
    val entries: List<MemoryEntry>,
    val domains: List<MemoryDomain>,
    val stats: MemoryStats
)

/**
 * Converters for Room database
 */
class Converters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun fromMemoryType(type: MemoryType): String = type.name

    @TypeConverter
    fun toMemoryType(value: String): MemoryType = MemoryType.valueOf(value)

    @TypeConverter
    fun fromFloatArray(array: FloatArray): String =
        array.joinToString(",") { it.toString() }

    @TypeConverter
    fun toFloatArray(value: String): FloatArray =
        if (value.isEmpty()) floatArrayOf()
        else value.split(",").map { it.toFloat() }.toFloatArray()

    @TypeConverter
    fun fromMetadataMap(map: Map<String, String>): String =
        json.encodeToString(map)

    @TypeConverter
    fun toMetadataMap(value: String): Map<String, String> =
        json.decodeFromString(value)
}

/**
 * Chunking strategy for document processing
 */
enum class ChunkingStrategy {
    FIXED_SIZE,      // Fixed token size with overlap
    SENTENCE,        // Split by sentences
    PARAGRAPH,       // Split by paragraphs
    SEMANTIC,        // Semantic boundaries
    HYBRID           // Combination approach
}

/**
 * Chunk metadata
 */
@Serializable
data class ChunkInfo(
    val index: Int,
    val totalChunks: Int,
    val startOffset: Int,
    val endOffset: Int,
    val tokenCount: Int,
    val sourceDocument: String? = null
)
