package com.nexusz4.memory

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

/**
 * File Ingestion Manager
 * Handles PDF, TXT, and Markdown file processing
 */
@Singleton
class FileIngestionManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val memoryManager: MemoryManager
) {

    init {
        PDFBoxResourceLoader.init(context)
    }

    companion object {
        const val MAX_FILE_SIZE_MB = 50
        const val CHUNK_SIZE = 512
        const val CHUNK_OVERLAP = 128
    }

    /**
     * Ingest a file from URI
     */
    suspend fun ingestFile(
        uri: Uri,
        domain: String = "documents"
    ): Result<IngestionResult> = withContext(Dispatchers.IO) {
        try {
            val fileName = getFileName(uri)
            val mimeType = context.contentResolver.getType(uri) ?: ""

            Timber.i("[Ingestion] Processing file: $fileName (type: $mimeType)")

            val startTime = System.currentTimeMillis()

            // Extract text based on file type
            val text = when {
                mimeType == "application/pdf" || fileName.endsWith(".pdf") ->
                    extractPdfText(uri)
                mimeType == "text/plain" || fileName.endsWith(".txt") ->
                    extractTextFile(uri)
                mimeType == "text/markdown" || fileName.endsWith(".md") ||
                fileName.endsWith(".markdown") ->
                    extractMarkdownFile(uri)
                else -> {
                    return@withContext Result.failure(
                        IllegalArgumentException("Unsupported file type: $mimeType")
                    )
                }
            }

            if (text.isNullOrBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("No text content extracted from file")
                )
            }

            // Chunk the text
            val chunks = chunkText(text)

            // Store each chunk as a memory
            var storedCount = 0
            chunks.forEachIndexed { index, chunk ->
                val result = memoryManager.storeMemory(
                    content = chunk,
                    type = com.nexusz4.memory.model.MemoryType.DOCUMENT,
                    domain = domain,
                    metadata = mapOf(
                        "source_file" to fileName,
                        "chunk_index" to index.toString(),
                        "total_chunks" to chunks.size.toString()
                    ),
                    source = fileName
                )

                if (result.isSuccess) {
                    storedCount++
                }
            }

            val processingTime = System.currentTimeMillis() - startTime

            val ingestionResult = IngestionResult(
                success = true,
                fileName = fileName,
                chunksCreated = chunks.size,
                memoriesStored = storedCount,
                processingTimeMs = processingTime
            )

            Timber.i("[Ingestion] Completed: $storedCount/$chunks stored in ${processingTime}ms")
            Result.success(ingestionResult)

        } catch (e: Exception) {
            Timber.e(e, "[Ingestion] Failed to process file")
            Result.failure(e)
        }
    }

    /**
     * Ingest text directly
     */
    suspend fun ingestText(
        text: String,
        title: String,
        domain: String = "notes"
    ): Result<IngestionResult> = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()

            val chunks = chunkText(text)

            var storedCount = 0
            chunks.forEachIndexed { index, chunk ->
                val result = memoryManager.storeMemory(
                    content = chunk,
                    type = com.nexusz4.memory.model.MemoryType.NOTE,
                    domain = domain,
                    metadata = mapOf(
                        "title" to title,
                        "chunk_index" to index.toString(),
                        "total_chunks" to chunks.size.toString()
                    ),
                    source = title
                )

                if (result.isSuccess) {
                    storedCount++
                }
            }

            val ingestionResult = IngestionResult(
                success = true,
                fileName = title,
                chunksCreated = chunks.size,
                memoriesStored = storedCount,
                processingTimeMs = System.currentTimeMillis() - startTime
            )

            Result.success(ingestionResult)

        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Batch ingest multiple files
     */
    suspend fun batchIngest(
        uris: List<Uri>,
        domain: String = "documents"
    ): List<Result<IngestionResult>> = withContext(Dispatchers.IO) {
        uris.map { uri ->
            ingestFile(uri, domain)
        }
    }

    // Private extraction methods

    private fun extractPdfText(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                PDDocument.load(inputStream).use { document ->
                    val stripper = PDFTextStripper()
                    stripper.startPage = 1
                    stripper.endPage = document.numberOfPages
                    stripper.getText(document)
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "[Ingestion] PDF extraction failed")
            null
        }
    }

    private fun extractTextFile(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    reader.readText()
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "[Ingestion] Text file extraction failed")
            null
        }
    }

    private fun extractMarkdownFile(uri: Uri): String? {
        // For now, treat markdown as plain text
        // Could add markdown parsing in future
        return extractTextFile(uri)
    }

    private fun getFileName(uri: Uri): String {
        var result = "unknown"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    result = cursor.getString(index) ?: "unknown"
                }
            }
        }
        return result
    }

    private fun chunkText(text: String): List<String> {
        val chunks = mutableListOf<String>()
        val cleanText = text
            .replace(Regex("\\s+"), " ")
            .trim()

        if (cleanText.length <= CHUNK_SIZE) {
            return listOf(cleanText)
        }

        var start = 0
        while (start < cleanText.length) {
            val end = minOf(start + CHUNK_SIZE, cleanText.length)

            // Try to break at sentence boundary
            var breakPoint = end
            if (end < cleanText.length) {
                // Look for sentence end within overlap range
                val searchStart = maxOf(start + CHUNK_SIZE - CHUNK_OVERLAP, start)
                val searchEnd = minOf(end + CHUNK_OVERLAP, cleanText.length)
                val searchRange = cleanText.substring(searchStart, searchEnd)

                // Find last sentence boundary
                val lastPeriod = searchRange.lastIndexOf('.')
                val lastQuestion = searchRange.lastIndexOf('?')
                val lastExclaim = searchRange.lastIndexOf('!')
                val lastBoundary = maxOf(lastPeriod, lastQuestion, lastExclaim)

                if (lastBoundary > 0) {
                    breakPoint = searchStart + lastBoundary + 1
                }
            }

            chunks.add(cleanText.substring(start, breakPoint).trim())
            start = breakPoint - CHUNK_OVERLAP
        }

        return chunks
    }
}

/**
 * Ingestion result data class
 */
data class IngestionResult(
    val success: Boolean,
    val fileName: String,
    val chunksCreated: Int,
    val memoriesStored: Int,
    val errors: List<String> = emptyList(),
    val processingTimeMs: Long = 0
)
