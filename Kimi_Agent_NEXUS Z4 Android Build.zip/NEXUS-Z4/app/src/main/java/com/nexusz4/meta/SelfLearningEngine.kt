package com.nexusz4.meta

import com.nexusz4.core.LLMEngine
import com.nexusz4.core.model.GenerationResult
import com.nexusz4.memory.MemoryManager
import com.nexusz4.skills.SkillEngine
import com.nexusz4.system.PerformanceMonitor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.util.concurrent.ConcurrentLinkedQueue
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.exp

/**
 * Self-Learning Engine
 * Evaluates responses, tracks performance, and adapts behavior
 */
@Singleton
class SelfLearningEngine @Inject constructor(
    private val llmEngine: LLMEngine,
    private val memoryManager: MemoryManager,
    private val skillEngine: SkillEngine,
    private val performanceMonitor: PerformanceMonitor,
    private val userAdaptationProfile: UserAdaptationProfile
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Response evaluation queue
    private val evaluationQueue = ConcurrentLinkedQueue<ResponseEvaluationRequest>()

    // Learning history
    private val responseHistory = mutableListOf<ResponseEvaluation>()
    private val confidenceHistory = mutableListOf<Float>()

    // Configuration
    private var config = LearningConfig()

    data class LearningConfig(
        val enableAutoRefinement: Boolean = true,
        val enableSkillEvolution: Boolean = true,
        val enableUserAdaptation: Boolean = true,
        val confidenceThreshold: Float = 0.7f,
        val refinementThreshold: Float = 0.5f,
        val maxHistorySize: Int = 1000,
        val learningRate: Float = 0.1f
    )

    companion object {
        const val TAG = "[SelfLearning]"
    }

    init {
        startEvaluationProcessor()
    }

    /**
     * Evaluate a response after generation
     */
    fun evaluateResponse(
        prompt: String,
        result: GenerationResult,
        context: EvaluationContext
    ) {
        val request = ResponseEvaluationRequest(
            prompt = prompt,
            result = result,
            context = context,
            timestamp = System.currentTimeMillis()
        )

        evaluationQueue.offer(request)
    }

    /**
     * Calculate comprehensive response score
     */
    fun calculateResponseScore(
        result: GenerationResult,
        context: EvaluationContext
    ): ResponseScore {
        // Confidence score (based on token probabilities if available)
        val confidenceScore = estimateConfidence(result)

        // Uncertainty score (higher = more uncertain)
        val uncertaintyScore = estimateUncertainty(result)

        // Token efficiency
        val tokenEfficiency = calculateTokenEfficiency(result)

        // User feedback (if available)
        val userFeedbackScore = context.userFeedback ?: 0.5f

        // Retrieval score (from RAG)
        val retrievalScore = context.retrievalScore ?: 0.5f

        // Calculate final score using formula:
        // ResponseScore = 0.3*confidence - 0.2*uncertainty + 0.15*token_efficiency + 0.25*user_feedback + 0.1*retrieval_score
        val finalScore = (
            0.3f * confidenceScore -
            0.2f * uncertaintyScore +
            0.15f * tokenEfficiency +
            0.25f * userFeedbackScore +
            0.1f * retrievalScore
        ).coerceIn(0f, 1f)

        return ResponseScore(
            overallScore = finalScore,
            confidenceScore = confidenceScore,
            uncertaintyScore = uncertaintyScore,
            tokenEfficiency = tokenEfficiency,
            userFeedbackScore = userFeedbackScore,
            retrievalScore = retrievalScore,
            hallucinationRisk = estimateHallucinationRisk(result, context)
        )
    }

    /**
     * Refine a low-quality response
     */
    suspend fun refineResponse(
        originalPrompt: String,
        originalResult: GenerationResult,
        score: ResponseScore
    ): GenerationResult? = withContext(Dispatchers.Default) {
        if (!config.enableAutoRefinement) {
            return@withContext null
        }

        if (score.overallScore >= config.refinementThreshold) {
            return@withContext null  // No refinement needed
        }

        try {
            Timber.d("$TAG Refining low-score response (score: ${score.overallScore})")

            // Build refinement prompt
            val refinementPrompt = buildRefinementPrompt(
                originalPrompt,
                originalResult.text,
                score
            )

            // Generate refined response
            val refinedResult = llmEngine.generate(
                prompt = refinementPrompt,
                config = com.nexusz4.core.model.GenerationConfig.PRECISE
            )

            if (refinedResult.success) {
                // Evaluate refinement
                val refinedScore = calculateResponseScore(
                    refinedResult,
                    EvaluationContext()
                )

                if (refinedScore.overallScore > score.overallScore) {
                    Timber.i("$TAG Refinement improved score: ${score.overallScore} -> ${refinedScore.overallScore}")
                    return@withContext refinedResult
                }
            }

            null
        } catch (e: Exception) {
            Timber.e(e, "$TAG Refinement failed")
            null
        }
    }

    /**
     * Update user adaptation profile based on interaction
     */
    fun updateUserProfile(
        interaction: UserInteraction
    ) {
        if (!config.enableUserAdaptation) return

        userAdaptationProfile.update(interaction)

        Timber.d("$TAG Updated user profile: style=${userAdaptationProfile.preferredStyle}, " +
                "complexity=${userAdaptationProfile.preferredComplexity}")
    }

    /**
     * Get adaptation hints for response generation
     */
    fun getAdaptationHints(): AdaptationHints {
        return AdaptationHints(
            style = userAdaptationProfile.preferredStyle,
            complexity = userAdaptationProfile.preferredComplexity,
            domainFocus = userAdaptationProfile.domainFocus,
            decisionSpeed = userAdaptationProfile.decisionSpeed,
            riskTolerance = userAdaptationProfile.riskTolerance,
            preferredFormat = userAdaptationProfile.preferredFormat
        )
    }

    /**
     * Detect potential hallucinations
     */
    fun detectHallucination(
        response: String,
        context: List<String> = emptyList()
    ): HallucinationReport {
        val indicators = mutableListOf<HallucinationIndicator>()

        // Check for uncertainty markers
        val uncertaintyPatterns = listOf(
            "i think", "maybe", "possibly", "perhaps", "i'm not sure",
            "i don't know", "unclear", "uncertain"
        )

        uncertaintyPatterns.forEach { pattern ->
            if (response.lowercase().contains(pattern)) {
                indicators.add(HallucinationIndicator.UncertaintyMarker(pattern))
            }
        }

        // Check for specific factual claims without context support
        val factualPatterns = Regex("""\b(is|are|was|were|has|have|had)\s+(\w+)\b""")
        val claims = factualPatterns.findAll(response).map { it.value }.toList()

        // Check against context (simplified)
        val unsupportedClaims = claims.filter { claim ->
            context.none { it.contains(claim, ignoreCase = true) }
        }

        if (unsupportedClaims.isNotEmpty()) {
            indicators.add(HallucinationIndicator.UnsupportedClaims(unsupportedClaims))
        }

        // Check for inconsistent formatting
        if (hasInconsistentFormatting(response)) {
            indicators.add(HallucinationIndicator.InconsistentFormatting)
        }

        val riskScore = calculateHallucinationRiskScore(indicators)

        return HallucinationReport(
            riskLevel = when {
                riskScore > 0.7f -> RiskLevel.HIGH
                riskScore > 0.4f -> RiskLevel.MEDIUM
                else -> RiskLevel.LOW
            },
            riskScore = riskScore,
            indicators = indicators,
            recommendations = generateRecommendations(indicators)
        )
    }

    /**
     * Get learning statistics
     */
    fun getStatistics(): LearningStatistics {
        val avgScore = if (responseHistory.isNotEmpty()) {
            responseHistory.map { it.score.overallScore }.average().toFloat()
        } else 0f

        val scoreTrend = calculateScoreTrend()

        return LearningStatistics(
            totalEvaluations = responseHistory.size,
            averageScore = avgScore,
            scoreTrend = scoreTrend,
            refinementsPerformed = responseHistory.count { it.wasRefined },
            userAdaptationLevel = userAdaptationProfile.adaptationLevel,
            confidenceCalibration = calculateConfidenceCalibration()
        )
    }

    /**
     * Update learning configuration
     */
    fun updateConfig(newConfig: LearningConfig) {
        config = newConfig
        Timber.i("$TAG Config updated: autoRefinement=${config.enableAutoRefinement}")
    }

    // Private helpers

    private fun startEvaluationProcessor() {
        scope.launch {
            while (isActive) {
                val request = evaluationQueue.poll()
                if (request != null) {
                    processEvaluation(request)
                } else {
                    delay(100)
                }
            }
        }
    }

    private suspend fun processEvaluation(request: ResponseEvaluationRequest) {
        try {
            val score = calculateResponseScore(request.result, request.context)

            // Detect hallucinations
            val hallucinationReport = detectHallucination(
                request.result.text,
                request.context.retrievedMemories
            )

            // Create evaluation record
            val evaluation = ResponseEvaluation(
                prompt = request.prompt,
                result = request.result,
                score = score,
                hallucinationReport = hallucinationReport,
                timestamp = request.timestamp,
                wasRefined = false
            )

            // Add to history
            responseHistory.add(evaluation)
            if (responseHistory.size > config.maxHistorySize) {
                responseHistory.removeAt(0)
            }

            // Update confidence history
            confidenceHistory.add(score.confidenceScore)
            if (confidenceHistory.size > 100) {
                confidenceHistory.removeAt(0)
            }

            // Trigger refinement if needed
            if (score.overallScore < config.refinementThreshold && config.enableAutoRefinement) {
                val refined = refineResponse(request.prompt, request.result, score)
                if (refined != null) {
                    evaluation.copy(wasRefined = true)
                }
            }

            // Update skill performance if applicable
            request.context.activeSkillId?.let { skillId ->
                skillEngine.updateSkillPerformance(
                    skillId = skillId,
                    responseScore = score.overallScore,
                    userFeedback = request.context.userFeedback
                )
            }

            Timber.d("$TAG Evaluated response: score=${score.overallScore}, " +
                    "hallucinationRisk=${hallucinationReport.riskLevel}")

        } catch (e: Exception) {
            Timber.e(e, "$TAG Evaluation failed")
        }
    }

    private fun estimateConfidence(result: GenerationResult): Float {
        // Estimate based on generation metrics
        // Higher tokens per second often correlates with higher confidence
        val speedScore = (result.tokensPerSecond / 50.0).coerceIn(0.0, 1.0).toFloat()

        // Token count efficiency
        val efficiencyScore = if (result.tokensGenerated > 0) {
            (result.tokensGenerated / result.maxTokens.toFloat()).coerceIn(0f, 1f)
        } else 0.5f

        return (speedScore * 0.6f + efficiencyScore * 0.4f).coerceIn(0f, 1f)
    }

    private fun estimateUncertainty(result: GenerationResult): Float {
        // Higher uncertainty if generation was very fast (potential repetition)
        val speedUncertainty = if (result.tokensPerSecond > 100) 0.3f else 0f

        // Uncertainty if response is very short
        val lengthUncertainty = if (result.tokensGenerated < 10) 0.4f else 0f

        return (speedUncertainty + lengthUncertainty).coerceIn(0f, 1f)
    }

    private fun calculateTokenEfficiency(result: GenerationResult): Float {
        return if (result.tokensGenerated > 0) {
            val ratio = result.tokensGenerated.toFloat() / result.durationMs.coerceAtLeast(1)
            (ratio / 0.1f).coerceIn(0f, 1f)  // Normalize to ~10 tokens/second as ideal
        } else 0f
    }

    private fun estimateHallucinationRisk(
        result: GenerationResult,
        context: EvaluationContext
    ): Float {
        val report = detectHallucination(result.text, context.retrievedMemories)
        return report.riskScore
    }

    private fun hasInconsistentFormatting(response: String): Boolean {
        // Check for inconsistent list markers
        val hasBulletList = response.contains("•") || response.contains("-")
        val hasNumberedList = Regex("""^\d+\.""", RegexOption.MULTILINE).containsMatchIn(response)

        // Check for mixed formatting
        return (hasBulletList && hasNumberedList &&
                response.length < 500)  // Short responses with mixed formatting
    }

    private fun calculateHallucinationRiskScore(
        indicators: List<HallucinationIndicator>
    ): Float {
        var score = 0f

        indicators.forEach { indicator ->
            score += when (indicator) {
                is HallucinationIndicator.UncertaintyMarker -> 0.1f
                is HallucinationIndicator.UnsupportedClaims -> 0.3f
                HallucinationIndicator.InconsistentFormatting -> 0.1f
                else -> 0.05f
            }
        }

        return score.coerceIn(0f, 1f)
    }

    private fun generateRecommendations(
        indicators: List<HallucinationIndicator>
    ): List<String> {
        val recommendations = mutableListOf<String>()

        if (indicators.any { it is HallucinationIndicator.UncertaintyMarker }) {
            recommendations.add("Consider requesting more context or clarification")
        }

        if (indicators.any { it is HallucinationIndicator.UnsupportedClaims }) {
            recommendations.add("Verify factual claims against known sources")
        }

        if (indicators.any { it == HallucinationIndicator.InconsistentFormatting }) {
            recommendations.add("Standardize response formatting")
        }

        return recommendations
    }

    private fun calculateScoreTrend(): ScoreTrend {
        if (confidenceHistory.size < 10) return ScoreTrend.INSUFFICIENT_DATA

        val recent = confidenceHistory.takeLast(10).average()
        val older = confidenceHistory.dropLast(10).takeLast(10).average()

        return when {
            recent > older * 1.1 -> ScoreTrend.IMPROVING
            recent < older * 0.9 -> ScoreTrend.DECLINING
            else -> ScoreTrend.STABLE
        }
    }

    private fun calculateConfidenceCalibration(): Float {
        // Measure how well confidence scores match actual accuracy
        // Simplified implementation
        return if (confidenceHistory.size >= 10) {
            val variance = confidenceHistory.zipWithNext { a, b ->
                kotlin.math.abs(a - b)
            }.average().toFloat()

            (1f - variance).coerceIn(0f, 1f)
        } else 0.5f
    }

    private fun buildRefinementPrompt(
        originalPrompt: String,
        originalResponse: String,
        score: ResponseScore
    ): String {
        return """
            The following response needs improvement. Please provide a better version.
            
            Original prompt: $originalPrompt
            
            Original response: $originalResponse
            
            Issues identified:
            ${if (score.confidenceScore < 0.5) "- Low confidence in response" else ""}
            ${if (score.uncertaintyScore > 0.5) "- High uncertainty markers" else ""}
            ${if (score.tokenEfficiency < 0.3) "- Inefficient token usage" else ""}
            
            Please provide an improved response that addresses these issues.
        """.trimIndent()
    }
}

// Supporting data classes

data class ResponseEvaluationRequest(
    val prompt: String,
    val result: GenerationResult,
    val context: EvaluationContext,
    val timestamp: Long
)

data class EvaluationContext(
    val userFeedback: Float? = null,
    val retrievalScore: Float? = null,
    val retrievedMemories: List<String> = emptyList(),
    val activeSkillId: String? = null,
    val hardwareConstraints: HardwareConstraints? = null
)

data class HardwareConstraints(
    val maxTokens: Int,
    val timeoutMs: Long,
    val memoryLimitMb: Int
)

data class ResponseScore(
    val overallScore: Float,
    val confidenceScore: Float,
    val uncertaintyScore: Float,
    val tokenEfficiency: Float,
    val userFeedbackScore: Float,
    val retrievalScore: Float,
    val hallucinationRisk: Float
)

data class ResponseEvaluation(
    val prompt: String,
    val result: GenerationResult,
    val score: ResponseScore,
    val hallucinationReport: HallucinationReport,
    val timestamp: Long,
    val wasRefined: Boolean
)

data class HallucinationReport(
    val riskLevel: RiskLevel,
    val riskScore: Float,
    val indicators: List<HallucinationIndicator>,
    val recommendations: List<String>
)

enum class RiskLevel {
    LOW, MEDIUM, HIGH
}

sealed class HallucinationIndicator {
    data class UncertaintyMarker(val phrase: String) : HallucinationIndicator()
    data class UnsupportedClaims(val claims: List<String>) : HallucinationIndicator()
    object InconsistentFormatting : HallucinationIndicator()
    data class FactualContradiction(val details: String) : HallucinationIndicator()
}

data class UserInteraction(
    val query: String,
    val response: String,
    val feedback: Float? = null,
    val interactionTimeMs: Long = 0,
    val domain: String? = null
)

data class AdaptationHints(
    val style: ResponseStyle,
    val complexity: ComplexityLevel,
    val domainFocus: List<String>,
    val decisionSpeed: DecisionSpeed,
    val riskTolerance: RiskTolerance,
    val preferredFormat: ResponseFormat
)

enum class ResponseStyle {
    CONCISE, DETAILED, TECHNICAL, CONVERSATIONAL, FORMAL
}

enum class ComplexityLevel {
    SIMPLE, MODERATE, ADVANCED, EXPERT
}

enum class DecisionSpeed {
    DELIBERATE, BALANCED, RAPID
}

enum class RiskTolerance {
    CONSERVATIVE, MODERATE, AGGRESSIVE
}

enum class ResponseFormat {
    BULLETS, PARAGRAPHS, STRUCTURED, CODE
}

enum class ScoreTrend {
    IMPROVING, STABLE, DECLINING, INSUFFICIENT_DATA
}

data class LearningStatistics(
    val totalEvaluations: Int,
    val averageScore: Float,
    val scoreTrend: ScoreTrend,
    val refinementsPerformed: Int,
    val userAdaptationLevel: Float,
    val confidenceCalibration: Float
)
