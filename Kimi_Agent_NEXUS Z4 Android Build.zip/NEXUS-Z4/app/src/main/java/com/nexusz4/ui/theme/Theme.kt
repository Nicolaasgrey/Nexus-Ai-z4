package com.nexusz4.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// NEXUS Z4 Color Palette - Dark Mode Default
private val DarkPrimary = Color(0xFF6366F1)        // Indigo 500
private val DarkOnPrimary = Color(0xFFFFFFFF)
private val DarkPrimaryContainer = Color(0xFF4338CA)  // Indigo 700
private val DarkOnPrimaryContainer = Color(0xFFE0E7FF)

private val DarkSecondary = Color(0xFF8B5CF6)      // Violet 500
private val DarkOnSecondary = Color(0xFFFFFFFF)
private val DarkSecondaryContainer = Color(0xFF6D28D9)  // Violet 700
private val DarkOnSecondaryContainer = Color(0xFFEDE9FE)

private val DarkTertiary = Color(0xFFEC4899)       // Pink 500
private val DarkOnTertiary = Color(0xFFFFFFFF)
private val DarkTertiaryContainer = Color(0xFFBE185D)   // Pink 700
private val DarkOnTertiaryContainer = Color(0xFFFCE7F3)

private val DarkError = Color(0xFFEF4444)          // Red 500
private val DarkErrorContainer = Color(0xFFB91C1C) // Red 700
private val DarkOnError = Color(0xFFFFFFFF)
private val DarkOnErrorContainer = Color(0xFFFEE2E2)

private val DarkBackground = Color(0xFF0F0F13)     // Deep dark
private val DarkOnBackground = Color(0xFFE2E2E8)
private val DarkSurface = Color(0xFF1A1A20)        // Slightly lighter
private val DarkOnSurface = Color(0xFFE2E2E8)
private val DarkSurfaceVariant = Color(0xFF25252D)
private val DarkOnSurfaceVariant = Color(0xFFA1A1AA)

private val DarkOutline = Color(0xFF52525B)
private val DarkOutlineVariant = Color(0xFF3F3F46)

private val DarkInverseSurface = Color(0xFFE2E2E8)
private val DarkInverseOnSurface = Color(0xFF1A1A20)
private val DarkInversePrimary = Color(0xFF818CF8)

private val DarkSurfaceTint = DarkPrimary
private val DarkScrim = Color(0xFF000000)

// Light theme colors (for completeness)
private val LightPrimary = Color(0xFF4F46E5)
private val LightOnPrimary = Color(0xFFFFFFFF)
private val LightPrimaryContainer = Color(0xFFE0E7FF)
private val LightOnPrimaryContainer = Color(0xFF312E81)

private val LightSecondary = Color(0xFF7C3AED)
private val LightOnSecondary = Color(0xFFFFFFFF)
private val LightSecondaryContainer = Color(0xFFEDE9FE)
private val LightOnSecondaryContainer = Color(0xFF5B21B6)

private val LightTertiary = Color(0xFFDB2777)
private val LightOnTertiary = Color(0xFFFFFFFF)
private val LightTertiaryContainer = Color(0xFFFCE7F3)
private val LightOnTertiaryContainer = Color(0xFF9D174D)

private val LightError = Color(0xFFDC2626)
private val LightErrorContainer = Color(0xFFFEE2E2)
private val LightOnError = Color(0xFFFFFFFF)
private val LightOnErrorContainer = Color(0xFF991B1B)

private val LightBackground = Color(0xFFFAFAFA)
private val LightOnBackground = Color(0xFF18181B)
private val LightSurface = Color(0xFFFFFFFF)
private val LightOnSurface = Color(0xFF18181B)
private val LightSurfaceVariant = Color(0xFFF4F4F5)
private val LightOnSurfaceVariant = Color(0xFF71717A)

private val LightOutline = Color(0xFFD4D4D8)
private val LightOutlineVariant = Color(0xFFE4E4E7)

private val LightInverseSurface = Color(0xFF18181B)
private val LightInverseOnSurface = Color(0xFFF4F4F5)
private val LightInversePrimary = Color(0xFF6366F1)

private val LightSurfaceTint = LightPrimary
private val LightScrim = Color(0xFF000000)

// Extended colors
val SuccessColor = Color(0xFF10B981)      // Emerald 500
val WarningColor = Color(0xFFF59E0B)      // Amber 500
val InfoColor = Color(0xFF3B82F6)         // Blue 500

val CognitiveLevel0 = Color(0xFFEF4444)   // Critical - Red
val CognitiveLevel1 = Color(0xFFF97316)   // Low - Orange
val CognitiveLevel2 = Color(0xFFEAB308)   // Normal - Yellow
val CognitiveLevel3 = Color(0xFF22C55E)   // High - Green
val CognitiveLevel4 = Color(0xFF10B981)   // Optimal - Emerald

// Dark Color Scheme
private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    error = DarkError,
    errorContainer = DarkErrorContainer,
    onError = DarkOnError,
    onErrorContainer = DarkOnErrorContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    inverseSurface = DarkInverseSurface,
    inverseOnSurface = DarkInverseOnSurface,
    inversePrimary = DarkInversePrimary,
    surfaceTint = DarkSurfaceTint,
    scrim = DarkScrim
)

// Light Color Scheme
private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    error = LightError,
    errorContainer = LightErrorContainer,
    onError = LightOnError,
    onErrorContainer = LightOnErrorContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
    inverseSurface = LightInverseSurface,
    inverseOnSurface = LightInverseOnSurface,
    inversePrimary = LightInversePrimary,
    surfaceTint = LightSurfaceTint,
    scrim = LightScrim
)

@Composable
fun NEXUSZ4Theme(
    darkTheme: Boolean = true,  // Default to dark
    dynamicColor: Boolean = false,  // Disable dynamic color for consistent branding
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}
