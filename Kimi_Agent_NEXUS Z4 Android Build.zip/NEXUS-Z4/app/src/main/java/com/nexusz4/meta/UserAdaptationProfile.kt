package com.nexusz4.meta

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_adaptation")

/**
 * User Adaptation Profile
 * Tracks and learns user preferences for personalized responses
 */
@Singleton
class UserAdaptationProfile @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    // Preference keys
    private val PREFERRED_STYLE = stringPreferencesKey("preferred_style")
    private val PREFERRED_COMPLEXITY = stringPreferencesKey("preferred_complexity")
    private val DOMAIN_FOCUS = stringPreferencesKey("domain_focus")
    private val DECISION_SPEED = stringPreferencesKey("decision_speed")
    private val RISK_TOLERANCE = stringPreferencesKey("risk_tolerance")
    private val PREFERRED_FORMAT = stringPreferencesKey("preferred_format")
    private val ADAPTATION_LEVEL = floatPreferencesKey("adaptation_level")
    private val INTERACTION_COUNT = intPreferencesKey("interaction_count")

    // In-memory cache
    private var cachedProfile: AdaptationProfile? = null

    data class AdaptationProfile(
        val style: ResponseStyle = ResponseStyle.BALANCED,
        val complexity: ComplexityLevel = ComplexityLevel.MODERATE,
        val domainFocus: List<String> = emptyList(),
        val decisionSpeed: DecisionSpeed = DecisionSpeed.BALANCED,
        val riskTolerance: RiskTolerance = RiskTolerance.MODERATE,
        val preferredFormat: ResponseFormat = ResponseFormat.BULLETS,
        val adaptationLevel: Float = 0f,
        val interactionCount: Int = 0
    )

    /**
     * Get current profile (cached or from datastore)
     */
    fun getProfile(): AdaptationProfile {
        return cachedProfile ?: runBlocking {
            loadProfile()
        }
    }

    /**
     * Load profile from DataStore
     */
    suspend fun loadProfile(): AdaptationProfile {
        val preferences = dataStore.data.first()

        val profile = AdaptationProfile(
            style = ResponseStyle.valueOf(preferences[PREFERRED_STYLE] ?: "BALANCED"),
            complexity = ComplexityLevel.valueOf(preferences[PREFERRED_COMPLEXITY] ?: "MODERATE"),
            domainFocus = preferences[DOMAIN_FOCUS]?.split(",") ?: emptyList(),
            decisionSpeed = DecisionSpeed.valueOf(preferences[DECISION_SPEED] ?: "BALANCED"),
            riskTolerance = RiskTolerance.valueOf(preferences[RISK_TOLERANCE] ?: "MODERATE"),
            preferredFormat = ResponseFormat.valueOf(preferences[PREFERRED_FORMAT] ?: "BULLETS"),
            adaptationLevel = preferences[ADAPTATION_LEVEL] ?: 0f,
            interactionCount = preferences[INTERACTION_COUNT] ?: 0
        )

        cachedProfile = profile
        return profile
    }

    /**
     * Save profile to DataStore
     */
    suspend fun saveProfile(profile: AdaptationProfile) {
        dataStore.edit { preferences ->
            preferences[PREFERRED_STYLE] = profile.style.name
            preferences[PREFERRED_COMPLEXITY] = profile.complexity.name
            preferences[DOMAIN_FOCUS] = profile.domainFocus.joinToString(",")
            preferences[DECISION_SPEED] = profile.decisionSpeed.name
            preferences[RISK_TOLERANCE] = profile.riskTolerance.name
            preferences[PREFERRED_FORMAT] = profile.preferredFormat.name
            preferences[ADAPTATION_LEVEL] = profile.adaptationLevel
            preferences[INTERACTION_COUNT] = profile.interactionCount
        }

        cachedProfile = profile
    }

    /**
     * Update profile based on user interaction
     */
    fun update(interaction: UserInteraction) {
        val current = getProfile()
        val updated = current.copy(
            interactionCount = current.interactionCount + 1
        )

        // Analyze query for style hints
        val detectedStyle = detectStyle(interaction.query, interaction.response)
        val detectedComplexity = detectComplexity(interaction.response)
        val detectedDomains = detectDomains(interaction.query)
        val detectedFormat = detectFormat(interaction.response)

        // Update with exponential moving average
        val alpha = 0.1f  // Learning rate

        val newProfile = updated.copy(
            style = blendStyles(current.style, detectedStyle, alpha),
            complexity = blendComplexity(current.complexity, detectedComplexity, alpha),
            domainFocus = updateDomainFocus(current.domainFocus, detectedDomains, alpha),
            preferredFormat = blendFormats(current.preferredFormat, detectedFormat, alpha),
            adaptationLevel = (current.adaptationLevel + alpha).coerceIn(0f, 1f)
        )

        runBlocking {
            saveProfile(newProfile)
        }

        // Process explicit feedback if provided
        interaction.feedback?.let { feedback ->
            processFeedback(feedback, interaction)
        }

        Timber.d("[Adaptation] Profile updated: style=${newProfile.style}, complexity=${newProfile.complexity}")
    }

    /**
     * Process explicit user feedback
     */
    private fun processFeedback(feedback: Float, interaction: UserInteraction) {
        // feedback: 0.0 = very negative, 1.0 = very positive
        val current = getProfile()

        // Adjust based on feedback
        val adjustment = when {
            feedback < 0.3f -> -0.1f  // Negative feedback
            feedback > 0.7f -> 0.05f   // Positive feedback
            else -> 0f
        }

        val newLevel = (current.adaptationLevel + adjustment).coerceIn(0f, 1f)

        runBlocking {
            saveProfile(current.copy(adaptationLevel = newLevel))
        }
    }

    // Property accessors for convenience

    val preferredStyle: ResponseStyle
        get() = getProfile().style

    val preferredComplexity: ComplexityLevel
        get() = getProfile().complexity

    val domainFocus: List<String>
        get() = getProfile().domainFocus

    val decisionSpeed: DecisionSpeed
        get() = getProfile().decisionSpeed

    val riskTolerance: RiskTolerance
        get() = getProfile().riskTolerance

    val preferredFormat: ResponseFormat
        get() = getProfile().preferredFormat

    val adaptationLevel: Float
        get() = getProfile().adaptationLevel

    val interactionCount: Int
        get() = getProfile().interactionCount

    // Detection methods

    private fun detectStyle(query: String, response: String): ResponseStyle {
        val queryLower = query.lowercase()
        val responseLower = response.lowercase()

        return when {
            queryLower.contains("explain") || queryLower.contains("tell me about") ->
                ResponseStyle.DETAILED
            queryLower.contains("brief") || queryLower.contains("quick") ||
            queryLower.contains("tl;dr") ->
                ResponseStyle.CONCISE
            queryLower.contains("code") || queryLower.contains("function") ||
            queryLower.contains("implement") ->
                ResponseStyle.TECHNICAL
            queryLower.contains("hey") || queryLower.contains("hi") ||
            responseLower.contains("i") ->
                ResponseStyle.CONVERSATIONAL
            else -> ResponseStyle.BALANCED
        }
    }

    private fun detectComplexity(response: String): ComplexityLevel {
        val wordCount = response.split(Regex("\\s+")).size
        val technicalTerms = countTechnicalTerms(response)

        return when {
            technicalTerms > 10 || wordCount > 500 -> ComplexityLevel.ADVANCED
            technicalTerms > 5 || wordCount > 200 -> ComplexityLevel.MODERATE
            else -> ComplexityLevel.SIMPLE
        }
    }

    private fun detectDomains(query: String): List<String> {
        val domains = mutableListOf<String>()
        val queryLower = query.lowercase()

        val domainKeywords = mapOf(
            "programming" to listOf("code", "program", "function", "class", "debug"),
            "science" to listOf("science", "physics", "chemistry", "biology"),
            "business" to listOf("business", "strategy", "market", "revenue"),
            "creative" to listOf("write", "story", "poem", "creative", "design"),
            "learning" to listOf("learn", "study", "understand", "explain"),
            "productivity" to listOf("plan", "organize", "schedule", "task")
        )

        domainKeywords.forEach { (domain, keywords) ->
            if (keywords.any { queryLower.contains(it) }) {
                domains.add(domain)
            }
        }

        return domains
    }

    private fun detectFormat(response: String): ResponseFormat {
        val bulletCount = response.count { it == '•' || it == '-' || it == '*' }
        val numberedCount = Regex("""^\d+\.""", RegexOption.MULTILINE).findAll(response).count()
        val codeBlocks = response.count { it == '`' } / 2

        return when {
            codeBlocks > 2 -> ResponseFormat.CODE
            bulletCount > numberedCount && bulletCount > 3 -> ResponseFormat.BULLETS
            numberedCount > bulletCount && numberedCount > 3 -> ResponseFormat.STRUCTURED
            else -> ResponseFormat.PARAGRAPHS
        }
    }

    private fun countTechnicalTerms(text: String): Int {
        val technicalPatterns = listOf(
            "algorithm", "function", "variable", "class", "object",
            "api", "database", "server", "client", "framework",
            "implementation", "architecture", "protocol", "interface"
        )

        return technicalPatterns.count { text.lowercase().contains(it) }
    }

    // Blending methods for smooth adaptation

    private fun blendStyles(
        current: ResponseStyle,
        detected: ResponseStyle,
        alpha: Float
    ): ResponseStyle {
        // If styles match, reinforce
        return if (current == detected || Math.random() < alpha) {
            detected
        } else {
            current
        }
    }

    private fun blendComplexity(
        current: ComplexityLevel,
        detected: ComplexityLevel,
        alpha: Float
    ): ComplexityLevel {
        val levels = ComplexityLevel.values()
        val currentIdx = levels.indexOf(current)
        val detectedIdx = levels.indexOf(detected)

        return if (Math.random() < alpha) {
            // Move toward detected
            when {
                detectedIdx > currentIdx -> levels.getOrNull(currentIdx + 1) ?: current
                detectedIdx < currentIdx -> levels.getOrNull(currentIdx - 1) ?: current
                else -> current
            }
        } else {
            current
        }
    }

    private fun blendFormats(
        current: ResponseFormat,
        detected: ResponseFormat,
        alpha: Float
    ): ResponseFormat {
        return if (Math.random() < alpha) detected else current
    }

    private fun updateDomainFocus(
        current: List<String>,
        detected: List<String>,
        alpha: Float
    ): List<String> {
        val combined = (current + detected).toMutableList()

        // Keep top domains by frequency
        val frequency = combined.groupingBy { it }.eachCount()
        return frequency.entries
            .sortedByDescending { it.value }
            .take(5)
            .map { it.key }
    }

    /**
     * Reset profile to defaults
     */
    suspend fun reset() {
        saveProfile(AdaptationProfile())
        Timber.i("[Adaptation] Profile reset to defaults")
    }
}

// Extended enums for profile

enum class ResponseStyle {
    CONCISE,        // Brief, to-the-point
    DETAILED,       // Comprehensive explanations
    TECHNICAL,      // Technical depth
    CONVERSATIONAL, // Friendly, casual
    FORMAL,         // Professional, structured
    BALANCED        // Adaptive mix
}

enum class ComplexityLevel {
    SIMPLE,     // Basic concepts only
    MODERATE,   // Some technical depth
    ADVANCED,   // Detailed technical
    EXPERT      // Maximum depth
}

enum class DecisionSpeed {
    DELIBERATE, // Careful, thorough
    BALANCED,   // Moderate pace
    RAPID       // Quick responses
}

enum class RiskTolerance {
    CONSERVATIVE, // Safe, proven approaches
    MODERATE,     // Balanced risk
    AGGRESSIVE    // Cutting-edge, experimental
}

enum class ResponseFormat {
    BULLETS,     // Bullet points
    PARAGRAPHS,  // Flowing text
    STRUCTURED,  // Numbered sections
    CODE         // Code-focused
}
