package com.nexusz4.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexusz4.core.model.ModelPreset
import com.nexusz4.system.CognitiveLevel
import com.nexusz4.system.SystemMetrics
import com.nexusz4.ui.theme.*
import com.nexusz4.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemScreen(
    viewModel: MainViewModel = hiltViewModel()
) {
    val metrics by viewModel.systemMetrics.collectAsState()
    val cognitiveLevel by viewModel.cognitiveLevel.collectAsState()
    val modelLoaded by viewModel.modelLoaded.collectAsState()
    val modelInfo by viewModel.modelInfo.collectAsState()

    var showModelDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Card
        item {
            StatusCard(
                modelLoaded = modelLoaded,
                cognitiveLevel = cognitiveLevel,
                onLoadModel = { showModelDialog = true },
                onUnloadModel = { viewModel.unloadModel() }
            )
        }

        // Performance Metrics
        item {
            PerformanceCard(metrics = metrics)
        }

        // Model Info
        if (modelLoaded && modelInfo.isNotEmpty()) {
            item {
                ModelInfoCard(modelInfo = modelInfo)
            }
        }

        // Cognitive Scaling
        item {
            CognitiveScalingCard(level = cognitiveLevel)
        }

        // Actions
        item {
            Text(
                "System Actions",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            SystemActionCard(
                title = "Clear Chat History",
                description = "Remove all conversation messages",
                icon = Icons.Default.Delete,
                onClick = { showClearDialog = true }
            )
        }

        item {
            SystemActionCard(
                title = "Export Data",
                description = "Export memories and skills",
                icon = Icons.Default.Upload,
                onClick = { /* TODO */ }
            )
        }

        item {
            SystemActionCard(
                title = "About NEXUS Z4",
                description = "Version 1.0.0 - Sovereign AI",
                icon = Icons.Default.Info,
                onClick = { /* TODO */ }
            )
        }
    }

    // Model selection dialog
    if (showModelDialog) {
        ModelSelectionDialog(
            availableModels = viewModel.availableModels,
            onDismiss = { showModelDialog = false },
            onSelect = { model ->
                // TODO: Get actual model path
                viewModel.loadModel("/sdcard/Android/data/com.nexusz4/files/models/${model.filename}")
                showModelDialog = false
            }
        )
    }

    // Clear confirmation
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear Chat History?") },
            text = { Text("This will remove all messages from the current conversation.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearChat()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun StatusCard(
    modelLoaded: Boolean,
    cognitiveLevel: Int,
    onLoadModel: () -> Unit,
    onUnloadModel: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                "System Status",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Model Status",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        if (modelLoaded) "Loaded" else "Not Loaded",
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (modelLoaded) SuccessColor else MaterialTheme.colorScheme.error
                    )
                }

                Button(
                    onClick = if (modelLoaded) onUnloadModel else onLoadModel,
                    colors = if (modelLoaded) {
                        ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    } else ButtonDefaults.buttonColors()
                ) {
                    Text(if (modelLoaded) "Unload" else "Load Model")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Cognitive Level",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    CognitiveLevelIndicator(level = cognitiveLevel)
                }
            }
        }
    }
}

@Composable
fun PerformanceCard(metrics: SystemMetrics) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                "Performance Metrics",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // RAM Usage
            MetricBar(
                label = "RAM",
                value = metrics.ramUsedPercent,
                maxValue = 100f,
                unit = "%",
                color = when {
                    metrics.ramUsedPercent >= 90f -> CognitiveLevel0
                    metrics.ramUsedPercent >= 80f -> CognitiveLevel1
                    metrics.ramUsedPercent >= 70f -> CognitiveLevel2
                    else -> SuccessColor
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // CPU Usage
            MetricBar(
                label = "CPU",
                value = metrics.cpuUsagePercent,
                maxValue = 100f,
                unit = "%",
                color = when {
                    metrics.cpuUsagePercent >= 90f -> CognitiveLevel0
                    metrics.cpuUsagePercent >= 75f -> CognitiveLevel1
                    metrics.cpuUsagePercent >= 60f -> CognitiveLevel2
                    else -> SuccessColor
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Battery
            MetricBar(
                label = "Battery",
                value = metrics.batteryPercent.toFloat(),
                maxValue = 100f,
                unit = "%",
                color = when {
                    metrics.batteryPercent <= 10 -> CognitiveLevel0
                    metrics.batteryPercent <= 20 -> CognitiveLevel1
                    else -> SuccessColor
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Temperature
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Temperature",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "${"%.1f".format(metrics.batteryTemperature)}°C",
                    style = MaterialTheme.typography.bodyMedium,
                    color = when {
                        metrics.batteryTemperature >= 50f -> CognitiveLevel0
                        metrics.batteryTemperature >= 45f -> CognitiveLevel1
                        else -> SuccessColor
                    }
                )
            }

            // Status indicators
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatusIndicator(
                    label = "Charging",
                    active = metrics.isCharging
                )
                StatusIndicator(
                    label = "Power Save",
                    active = metrics.isPowerSaveMode
                )
            }
        }
    }
}

@Composable
fun MetricBar(
    label: String,
    value: Float,
    maxValue: Float,
    unit: String,
    color: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${value.toInt()}$unit",
                style = MaterialTheme.typography.bodyMedium,
                color = color
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        LinearProgressIndicator(
            progress = (value / maxValue).coerceIn(0f, 1f),
            modifier = Modifier.fillMaxWidth(),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun StatusIndicator(label: String, active: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .padding(end = 4.dp)
        ) {
            if (active) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessColor,
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) SuccessColor else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ModelInfoCard(modelInfo: Map<String, Any>) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                "Model Information",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            modelInfo.forEach { (key, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        key.replace("_", " ").replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        value.toString(),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
fun CognitiveScalingCard(level: Int) {
    val config = CognitiveScalingConfig.forLevel(level)

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                "Cognitive Scaling",
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Current configuration for cognitive level $level:",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(12.dp))

            ScalingParam("Max Tokens", config.maxTokens.toString())
            ScalingParam("Batch Size", config.batchSize.toString())
            ScalingParam("Reflection", if (config.useReflection) "Enabled" else "Disabled")
            ScalingParam("Critic Model", if (config.useCritic) "Enabled" else "Disabled")
            ScalingParam("Max Retrieval", config.maxRetrievalResults.toString())
        }
    }
}

@Composable
fun ScalingParam(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun SystemActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ModelSelectionDialog(
    availableModels: List<ModelPreset>,
    onDismiss: () -> Unit,
    onSelect: (ModelPreset) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Model") },
        text = {
            Column {
                availableModels.forEach { model ->
                    ListItem(
                        headlineContent = { Text(model.name) },
                        supportingContent = {
                            Column {
                                Text("${model.parameters} • ${model.quantization}")
                                Text("${model.sizeGb} GB • ${model.contextSize} ctx")
                            }
                        },
                        leadingContent = {
                            if (model.recommended) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Recommended",
                                    tint = WarningColor
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.ModelTraining,
                                    contentDescription = null
                                )
                            }
                        },
                        modifier = Modifier.clickable { onSelect(model) }
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
