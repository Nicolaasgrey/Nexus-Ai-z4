package com.nexusz4.di

import android.content.Context
import com.nexusz4.core.LLMEngine
import com.nexusz4.core.LlamaNativeBridge
import com.nexusz4.memory.*
import com.nexusz4.meta.SelfLearningEngine
import com.nexusz4.meta.UserAdaptationProfile
import com.nexusz4.security.EncryptionManager
import com.nexusz4.skills.SkillEngine
import com.nexusz4.system.PerformanceMonitor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideLlamaNativeBridge(): LlamaNativeBridge {
        return LlamaNativeBridge()
    }

    @Provides
    @Singleton
    fun providePerformanceMonitor(
        @ApplicationContext context: Context
    ): PerformanceMonitor {
        return PerformanceMonitor(context)
    }

    @Provides
    @Singleton
    fun provideEncryptionManager(
        @ApplicationContext context: Context
    ): EncryptionManager {
        return EncryptionManager(context)
    }

    @Provides
    @Singleton
    fun provideVectorDatabase(): VectorDatabase {
        return VectorDatabase()
    }

    @Provides
    @Singleton
    fun provideEmbeddingEngine(
        @ApplicationContext context: Context
    ): EmbeddingEngine {
        return EmbeddingEngine(context)
    }

    @Provides
    @Singleton
    fun provideMemoryManager(
        @ApplicationContext context: Context,
        vectorDatabase: VectorDatabase,
        embeddingEngine: EmbeddingEngine,
        encryptionManager: EncryptionManager,
        performanceMonitor: PerformanceMonitor
    ): MemoryManager {
        return MemoryManager(
            context,
            vectorDatabase,
            embeddingEngine,
            encryptionManager,
            performanceMonitor
        )
    }

    @Provides
    @Singleton
    fun provideSkillEngine(
        @ApplicationContext context: Context,
        llmEngine: LLMEngine,
        encryptionManager: EncryptionManager
    ): SkillEngine {
        return SkillEngine(context, llmEngine, encryptionManager)
    }

    @Provides
    @Singleton
    fun provideUserAdaptationProfile(
        @ApplicationContext context: Context
    ): UserAdaptationProfile {
        return UserAdaptationProfile(context)
    }

    @Provides
    @Singleton
    fun provideSelfLearningEngine(
        llmEngine: LLMEngine,
        memoryManager: MemoryManager,
        skillEngine: SkillEngine,
        performanceMonitor: PerformanceMonitor,
        userAdaptationProfile: UserAdaptationProfile
    ): SelfLearningEngine {
        return SelfLearningEngine(
            llmEngine,
            memoryManager,
            skillEngine,
            performanceMonitor,
            userAdaptationProfile
        )
    }

    @Provides
    @Singleton
    fun provideLLMEngine(
        @ApplicationContext context: Context,
        performanceMonitor: PerformanceMonitor,
        nativeBridge: LlamaNativeBridge
    ): LLMEngine {
        return LLMEngine(context, performanceMonitor, nativeBridge)
    }

    @Provides
    @Singleton
    fun provideFileIngestionManager(
        @ApplicationContext context: Context,
        memoryManager: MemoryManager
    ): FileIngestionManager {
        return FileIngestionManager(context, memoryManager)
    }
}
