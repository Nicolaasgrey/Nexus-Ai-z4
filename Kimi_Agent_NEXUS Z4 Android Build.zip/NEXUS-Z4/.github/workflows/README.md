# GitHub Actions Workflows

This directory contains all CI/CD workflows for NEXUS Z4.

## Workflows

### 1. build.yml
**Purpose:** Main build workflow for debug and release APKs

**Triggers:**
- Push to `main` or `develop` branches
- Pull requests to `main`
- Manual dispatch with build type selection

**Jobs:**
- `build-debug`: Builds debug APK with artifacts
- `build-release`: Builds signed release APK (requires secrets)
- `build-libs`: Builds native libraries separately
- `test`: Runs unit tests
- `lint`: Performs code quality checks

**Artifacts:**
- Debug APK
- Release APK
- Native libraries
- Test reports
- Lint reports

---

### 2. release.yml
**Purpose:** Creates GitHub releases with signed APKs

**Triggers:**
- Push of version tags (`v*`)
- Manual dispatch with version input

**Jobs:**
- `create-release`: Builds release, generates changelog, creates GitHub release
- `publish-fdroid`: Prepares F-Droid metadata

**Requirements:**
- `KEYSTORE_BASE64`: Base64-encoded signing keystore
- `KEYSTORE_PASSWORD`: Keystore password
- `KEY_ALIAS`: Key alias
- `KEY_PASSWORD`: Key password

---

### 3. nightly.yml
**Purpose:** Automated nightly builds from develop branch

**Triggers:**
- Scheduled daily at 2 AM UTC
- Manual dispatch

**Jobs:**
- `nightly-build`: Builds debug APK, uploads to nightly release

**Features:**
- Automatic versioning with date and commit hash
- Updates existing `nightly` tag
- Discord notifications on failure

---

## Workflow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      GitHub Repository                       │
└─────────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
          ▼                   ▼                   ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│   Push to main  │  │   Push tag v*   │  │  Schedule 2AM   │
└─────────────────┘  └─────────────────┘  └─────────────────┘
          │                   │                   │
          ▼                   ▼                   ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│   build.yml     │  │  release.yml    │  │  nightly.yml    │
│                 │  │                 │  │                 │
│ ┌─────────────┐ │  │ ┌─────────────┐ │  │ ┌─────────────┐ │
│ │ Build Debug │ │  │ │Build Release│ │  │ │Build Debug  │ │
│ │ Build Libs  │ │  │ │Create Release│ │  │ │Nightly Tag  │ │
│ │ Run Tests   │ │  │ │F-Droid Meta │ │  │ │Discord Notify│ │
│ │ Run Lint    │ │  │ └─────────────┘ │  │ └─────────────┘ │
│ └─────────────┘ │  └─────────────────┘  └─────────────────┘
└─────────────────┘
          │
          ▼
┌─────────────────┐
│    Artifacts    │
│  ┌───────────┐  │
│  │ Debug APK │  │
│  │ Release   │  │
│  │ Libraries │  │
│  │ Reports   │  │
│  └───────────┘  │
└─────────────────┘
```

---

## Usage Examples

### Build Debug APK
```bash
# Via GitHub CLI
gh workflow run build.yml --repo USER/REPO -f build_type=debug

# Or via web interface
# Actions → Build NEXUS Z4 → Run workflow → debug
```

### Create Release
```bash
# Tag and push
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0

# Or manual dispatch
gh workflow run release.yml --repo USER/REPO -f version=1.0.0
```

### Download Latest Build
```bash
# Get latest debug build
gh run download --repo USER/REPO --name nexus-z4-debug-LATEST
```

---

## Caching Strategy

The workflows use caching to speed up builds:

| Cache | Path | Key Pattern |
|-------|------|-------------|
| Gradle | `~/.gradle/caches` | `os-gradle-hash` |
| Native | `app/.cxx` | `os-native-hash` |
| SDK | Managed by setup-android | - |

Cache is invalidated when:
- Gradle files change
- Native source files change
- 7 days pass (GitHub default)

---

## Build Matrix

Future enhancement: Build for multiple architectures

```yaml
strategy:
  matrix:
    abi: [arm64-v8a, armeabi-v7a, x86_64]
```

---

## Secrets Reference

| Secret | Required For | Description |
|--------|--------------|-------------|
| `KEYSTORE_BASE64` | Release builds | Signing keystore (base64) |
| `KEYSTORE_PASSWORD` | Release builds | Keystore password |
| `KEY_ALIAS` | Release builds | Key alias name |
| `KEY_PASSWORD` | Release builds | Key password |
| `DISCORD_WEBHOOK` | Optional | Discord notifications |

---

## Troubleshooting

### Build fails with "NDK not found"
- Check NDK_VERSION in workflow matches available version
- Workflow installs NDK automatically, may need retry

### Release fails with "keystore error"
- Verify all signing secrets are set
- Check keystore was properly base64 encoded

### Artifacts not uploading
- Check artifact path matches actual output path
- Verify build actually produced the file

---

## Customization

### Add New Workflow
1. Create `.github/workflows/my-workflow.yml`
2. Define triggers and jobs
3. Test with manual dispatch

### Modify Existing Workflow
1. Edit workflow file
2. Commit and push
3. Trigger test run

### Disable Workflow
1. Go to Actions tab
2. Click workflow name
3. Click "..." menu
4. Select "Disable workflow"

---

For more information, see [GITHUB_SETUP.md](../GITHUB_SETUP.md)
