# NEXUS Z4 - Sovereign AI Assistant

A production-ready, fully offline Android AI assistant with self-learning capabilities, RAG memory architecture, and energy-aware cognitive scaling.

## Features

### Core Capabilities
- **Local LLM Engine**: Runs GGUF 4-bit quantized models using llama.cpp with Vulkan GPU acceleration
- **RAG Memory System**: Vector database with semantic search for long-term memory
- **Skill System**: Self-upgrading modules with performance tracking (SPI)
- **Self-Learning Engine**: Evaluates responses and adapts behavior
- **Energy-Aware Scaling**: Dynamically adjusts cognition based on hardware state

### Architecture
```
/core        → LLM engine wrapper (llama.cpp JNI)
/memory      → Vector DB + embeddings (FAISS/ONNX)
/skills      → Skill engine with JSON schema
/ui          → Jetpack Compose screens
/security    → AES encryption + biometric auth
/system      → Performance monitoring
/meta        → Self-evaluation engine
/goals       → Long-term strategic memory
/critic      → Reflection micro-model
/evolution   → Skill mutation engine
/analytics   → Behavior tracking
```

## Requirements

### Hardware
- **Target Device**: Samsung Galaxy Z Flip 4
- **SoC**: Snapdragon 8+ Gen 1
- **RAM**: 8GB
- **OS**: Android 14+
- **Storage**: 10GB+ free space for models

### Software
- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- NDK 25.2.9519653
- CMake 3.22.1
- JDK 17

## Quick Start (GitHub Build - Recommended)

### 1. Fork Repository
Click **Fork** button on GitHub or create new repository

### 2. Trigger Build
- Go to **Actions** tab
- Click **Build NEXUS Z4**
- Click **Run workflow** → Select **debug**

### 3. Download APK
- Wait for build to complete (~10-15 minutes)
- Download from **Artifacts** section

### 4. Install
```bash
adb install nexus-z4-debug.apk
```

### 5. Download Model
```bash
mkdir -p /sdcard/Android/data/com.nexusz4/files/models/
wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf
```

---

## Detailed Setup Instructions

### Option 1: GitHub Actions (Easiest)

See [GITHUB_SETUP.md](GITHUB_SETUP.md) for complete guide.

### Option 2: Local Build (Advanced)

#### 1. Clone and Open Project
```bash
git clone <repository-url>
cd NEXUS-Z4
```

Open in Android Studio and sync project with Gradle files.

### 2. Download LLM Models

Place GGUF models in `/sdcard/Android/data/com.nexusz4/files/models/`:

**Recommended Models:**
| Model | Size | Filename | Performance |
|-------|------|----------|-------------|
| Mistral 7B Instruct | 4.1 GB | `mistral-7b-instruct-v0.2.Q4_K_M.gguf` | ⭐ Recommended |
| Llama 3 8B Instruct | 4.9 GB | `Meta-Llama-3-8B-Instruct.Q4_K_M.gguf` | Excellent |
| Phi-3 Mini | 2.3 GB | `Phi-3-mini-4k-instruct.Q4_K_M.gguf` | Compact |
| Qwen2 7B | 4.4 GB | `qwen2-7b-instruct-q4_K_M.gguf` | Multilingual |

**Download from:**
- [Hugging Face TheBloke](https://huggingface.co/TheBloke)
- [Model Database](https://modeldb.ai/)

### 3. Download Embedding Model

Place ONNX embedding model in `app/src/main/assets/`:
- `all-MiniLM-L6-v2-quantized.onnx`
- `vocab.txt`

### 4. Build Native Libraries

```bash
# Build llama.cpp for Android
./gradlew externalNativeBuildRelease
```

### 5. Configure Build

Create `local.properties`:
```properties
sdk.dir=/path/to/android/sdk
ndk.dir=/path/to/android/ndk/25.2.9519653
```

### 6. Build and Install

```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease

# Install to device
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Performance Tuning

### Memory Management
```kotlin
// Adjust chunk sizes based on available RAM
val config = MemoryConfig(
    chunkSize = 512,        // Tokens per chunk
    chunkOverlap = 128,     // Overlap for context
    maxRetrievalResults = 5 // Max memories per query
)
```

### Cognitive Scaling Levels

| Level | RAM Usage | Max Tokens | Features |
|-------|-----------|------------|----------|
| 0 (Critical) | < 10% | 512 | Minimal, no reflection |
| 1 (Low) | < 20% | 1024 | Basic, no critic |
| 2 (Normal) | Normal | 2048 | Standard features |
| 3 (High) | Good | 3072 | + Critic model |
| 4 (Optimal) | Excellent | 4096 | Full capabilities |

### GPU Acceleration

Enable Vulkan for Snapdragon 8+ Gen 1:
```kotlin
val modelConfig = ModelConfig(
    useGpu = true,
    gpuLayers = 35  // Offload 35 layers to GPU
)
```

### Battery Optimization

```kotlin
// Disable GPU when battery < 20%
val shouldUseGpu = batteryPercent > 20 && !isPowerSaveMode

// Reduce tokens when thermal throttling
val maxTokens = if (temperature > 45f) 1024 else 2048
```

## Usage

### Chat Interface
1. Load a model from System panel
2. Type messages in the chat input
3. Toggle memory retrieval with the memory icon
4. Adjust temperature/top-p in settings

### Memory Management
1. Upload PDFs, TXT, or Markdown files
2. Memories are automatically chunked and embedded
3. Rebuild index if needed
4. Clear memory to start fresh

### Skill System
1. Skills auto-activate based on trigger keywords
2. View skill performance (SPI score)
3. Toggle skills on/off
4. Skills evolve based on usage

### System Panel
- Monitor RAM, CPU, battery, temperature
- View cognitive scaling level
- Load/unload models
- Export/import data

## Security

### Encryption
- All data encrypted with AES-256-GCM
- Hardware-backed keystore when available
- Optional biometric authentication

### Privacy
- **NO INTERNET PERMISSIONS**
- All processing on-device
- No data leaves the device

## API Reference

### LLM Engine
```kotlin
// Load model
llmEngine.loadModel("/path/to/model.gguf")

// Generate text
llmEngine.generateStream(prompt, config)
    .collect { token -> /* handle token */ }

// Get model info
val info = llmEngine.getModelInfo()
```

### Memory Manager
```kotlin
// Store memory
memoryManager.storeMemory(
    content = "Important information",
    type = MemoryType.NOTE,
    domain = "personal"
)

// Retrieve relevant memories
val memories = memoryManager.retrieveRelevant(
    query = "What was discussed?",
    limit = 5
)
```

### Skill Engine
```kotlin
// Detect applicable skills
val activations = skillEngine.detectSkills(userInput)

// Apply skill
val enhancedPrompt = skillEngine.applySkill(
    skill = activation.skill,
    userInput = userInput
)
```

## Troubleshooting

### Model Won't Load
- Check file path is correct
- Verify model is GGUF format
- Ensure sufficient storage space
- Check logcat for native errors

### Out of Memory
- Reduce `gpuLayers` in model config
- Lower `maxTokens` in generation config
- Clear memory cache
- Unload unused models

### Slow Generation
- Enable GPU acceleration
- Use smaller models (Phi-3 Mini)
- Reduce context size
- Close background apps

### App Crashes
- Check NDK version matches (25.2.9519653)
- Verify CMake version (3.22.1)
- Clear app data and retry
- Check thermal throttling

## Development

### Project Structure
```
NEXUS-Z4/
├── app/
│   ├── src/main/
│   │   ├── cpp/              # Native code (llama.cpp)
│   │   ├── java/com/nexusz4/
│   │   │   ├── core/         # LLM engine
│   │   │   ├── memory/       # RAG system
│   │   │   ├── skills/       # Skill engine
│   │   │   ├── ui/           # Compose UI
│   │   │   ├── security/     # Encryption
│   │   │   ├── system/       # Performance
│   │   │   └── meta/         # Self-learning
│   │   └── res/              # Resources
│   └── build.gradle.kts
├── gradle/
└── README.md
```

### Adding New Skills
```kotlin
val skill = Skill(
    id = UUID.randomUUID().toString(),
    skillName = "Code Review",
    description = "Review code for issues",
    category = SkillCategory.CODING,
    triggerKeywords = listOf("review code", "check code"),
    instructionTemplate = "Review this code: {input}",
    version = "1.0.0"
)

skillEngine.addSkill(skill)
```

### Custom Model Support
1. Convert to GGUF format using llama.cpp
2. Place in models directory
3. Update ModelPreset in code
4. Rebuild and install

## License

This project is licensed under the MIT License - see LICENSE file for details.

## Acknowledgments

- [llama.cpp](https://github.com/ggerganov/llama.cpp) - LLM inference engine
- [ONNX Runtime](https://onnxruntime.ai/) - Embedding inference
- [Jetpack Compose](https://developer.android.com/jetpack/compose) - UI framework

## Support

For issues and feature requests, please use the GitHub issue tracker.

---

**NEXUS Z4** - Sovereign Intelligence, Offline First.
