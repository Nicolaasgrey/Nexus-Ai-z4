# GitHub Build Guide - NEXUS Z4

Complete step-by-step guide to build NEXUS Z4 using GitHub Actions and install on your Android device.

---

## 📋 Prerequisites

- GitHub account (free)
- Android device with:
  - Android 9.0+ (API 28)
  - 6GB+ RAM (8GB recommended)
  - 5GB+ free storage
- USB cable (for ADB)

---

## 🚀 Step-by-Step Instructions

### Step 1: Create GitHub Repository

#### Option A: Fork Existing Repository

1. Go to the NEXUS Z4 repository
2. Click **Fork** button (top right)
3. Select your account
4. Wait for fork to complete

#### Option B: Create New Repository

1. Go to https://github.com/new
2. Repository name: `NEXUS-Z4`
3. Description: `Sovereign AI Assistant - Fully Offline`
4. Visibility: **Public**
5. Check: **Add a README file**
6. Click **Create repository**

---

### Step 2: Upload Source Code

#### Method 1: Using Git (Computer)

```bash
# Navigate to NEXUS-Z4 folder
cd /path/to/NEXUS-Z4

# Initialize git (if not already)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: NEXUS Z4"

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/NEXUS-Z4.git

# Push
git push -u origin main
```

#### Method 2: Using GitHub Web (Browser)

1. Open your repository on GitHub
2. Click **Add file** → **Upload files**
3. Drag and drop NEXUS-Z4 folder contents
4. Add commit message: "Initial commit"
5. Click **Commit changes**

#### Method 3: Using GitHub Desktop

1. Download [GitHub Desktop](https://desktop.github.com/)
2. File → Add local repository
3. Select NEXUS-Z4 folder
4. Click **Publish repository**

---

### Step 3: Trigger First Build

1. Go to your repository on GitHub
2. Click **Actions** tab
3. Click **Build NEXUS Z4** workflow
4. Click **Run workflow** button (blue)
5. Select:
   - **Branch:** `main`
   - **Build type:** `debug`
6. Click **Run workflow**

![Build Workflow](https://docs.github.com/assets/images/help/actions/workflow-dispatch.png)

---

### Step 4: Wait for Build

Build time: **10-20 minutes**

Progress indicators:
- ⏳ **Yellow dot** = Running
- ✅ **Green check** = Success
- ❌ **Red X** = Failed

Build stages:
1. Setup environment (1 min)
2. Install NDK (2 min)
3. Build native libraries (5-10 min)
4. Compile Kotlin code (3-5 min)
5. Package APK (1 min)

---

### Step 5: Download APK

#### Method 1: Web Browser

1. Click on completed workflow run
2. Scroll to **Artifacts** section
3. Click on `nexus-z4-debug-X`
4. ZIP file downloads automatically
5. Extract to get `app-debug.apk`

#### Method 2: GitHub CLI

```bash
# Install GitHub CLI
# https://cli.github.com/

# Login
gh auth login

# Download latest artifact
gh run download --repo YOUR_USERNAME/NEXUS-Z4 \
  --name nexus-z4-debug-1

# File saved as: app-debug.apk
```

#### Method 3: Direct URL

```
https://github.com/YOUR_USERNAME/NEXUS-Z4/actions/runs/RUN_ID/artifacts/ARTIFACT_ID
```

---

### Step 6: Install on Android Device

#### Enable Developer Options

1. Open **Settings**
2. Go to **About phone**
3. Tap **Build number** 7 times
4. Enter PIN/password
5. "You are now a developer!"

#### Enable USB Debugging

1. Go to **Settings** → **System** → **Developer options**
2. Turn on **USB debugging**
3. Tap **OK** on warning

#### Install via ADB

```bash
# Connect device via USB
adb devices

# Should show:
# List of devices attached
# xxxxxxxx    device

# Install APK
adb install app-debug.apk

# Success message:
# Performing Streamed Install
# Success
```

#### Alternative: Direct Install

1. Transfer APK to device (USB, email, cloud)
2. Open file manager
3. Tap APK file
4. Tap **Install**
5. If blocked: Settings → Allow from this source

---

### Step 7: Download AI Model

NEXUS Z4 requires a GGUF model file.

#### Option 1: Download on Device (Termux)

```bash
# Install Termux from F-Droid
# https://f-droid.org/packages/com.termux/

# Create directory
mkdir -p /sdcard/Android/data/com.nexusz4/files/models/

# Download Mistral 7B (Recommended, 4.1GB)
cd /sdcard/Android/data/com.nexusz4/files/models/
wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf

# Or download Phi-3 Mini (Faster, 2.3GB)
wget https://huggingface.co/TheBloke/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct.Q4_K_M.gguf
```

#### Option 2: Transfer from Computer

```bash
# On computer with model file
adb push mistral-7b-instruct-v0.2.Q4_K_M.gguf \
  /sdcard/Android/data/com.nexusz4/files/models/
```

#### Option 3: Browser Download

1. Open browser on Android
2. Go to: https://huggingface.co/TheBloke
3. Find model (Mistral 7B Instruct recommended)
4. Download `Q4_K_M` version
5. Move to: `/sdcard/Android/data/com.nexusz4/files/models/`

---

### Step 8: Launch NEXUS Z4

1. Open **NEXUS Z4** app
2. Tap **System** tab (bottom right)
3. Tap **Load Model**
4. Select your downloaded model
5. Wait for loading (30-60 seconds)
6. Go to **Chat** tab
7. Start chatting! 💬

---

## 🔄 Updating to New Version

### Automatic Updates (Nightly Builds)

1. Go to **Actions** → **Nightly Build**
2. Download latest nightly APK
3. Install (overwrites previous version)

### Manual Update

1. Trigger new build
2. Download new APK
3. Install:
   ```bash
   adb install -r app-debug.apk
   ```

---

## 📊 Build Status

Add this badge to your README:

```markdown
[![Build](https://github.com/YOUR_USERNAME/NEXUS-Z4/workflows/Build%20NEXUS%20Z4/badge.svg)](https://github.com/YOUR_USERNAME/NEXUS-Z4/actions)
```

---

## 🛠️ Troubleshooting

### Build Fails

| Error | Solution |
|-------|----------|
| "NDK not found" | Re-run workflow |
| "Out of memory" | Use debug build, not release |
| "Build timeout" | Split into smaller commits |

### APK Won't Install

```bash
# Check existing installation
adb shell pm list packages | grep nexusz4

# Uninstall if exists
adb uninstall com.nexusz4

# Reinstall
adb install app-debug.apk
```

### Model Won't Load

| Issue | Fix |
|-------|-----|
| "Model not found" | Check file path |
| "Out of memory" | Use smaller model (Phi-3) |
| "Corrupted file" | Re-download, verify MD5 |

### App Crashes

```bash
# View logs
adb logcat -s "NEXUS-Z4:*" -d

# Clear data
adb shell pm clear com.nexusz4
```

---

## 📱 Device-Specific Notes

### Samsung Galaxy Z Flip 4 (Recommended)

- Optimal settings in `PERFORMANCE_TUNING.md`
- GPU acceleration enabled by default
- Expected: 15-20 tokens/sec with Mistral 7B

### Other Devices

| RAM | Recommended Model | Expected Speed |
|-----|-------------------|----------------|
| 12GB+ | Mistral 7B | 15-20 t/s |
| 8GB | Mistral 7B | 10-15 t/s |
| 6GB | Phi-3 Mini | 20-25 t/s |
| 4GB | Gemma 2B | 30+ t/s |

---

## 🎓 Advanced Options

### Create Release Build

1. Generate signing key:
   ```bash
   keytool -genkey -v -keystore nexus-z4.keystore -alias nexusz4 -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Add secrets to GitHub:
   - `KEYSTORE_BASE64`: `base64 nexus-z4.keystore`
   - `KEYSTORE_PASSWORD`: Your password
   - `KEY_ALIAS`: `nexusz4`
   - `KEY_PASSWORD`: Your key password

3. Trigger release build

### Custom Build

Edit `.github/workflows/build.yml`:

```yaml
env:
  JAVA_VERSION: '17'  # Change Java version
  NDK_VERSION: '26.0.0'  # Change NDK version
```

---

## 📚 Additional Resources

- [GITHUB_SETUP.md](GITHUB_SETUP.md) - Complete setup guide
- [PERFORMANCE_TUNING.md](PERFORMANCE_TUNING.md) - Optimization tips
- [QUICK_START.md](QUICK_START.md) - Quick reference
- [README.md](README.md) - Full documentation

---

## ✅ Checklist

- [ ] GitHub repository created
- [ ] Source code uploaded
- [ ] First build triggered
- [ ] Build completed successfully
- [ ] APK downloaded
- [ ] APK installed on device
- [ ] AI model downloaded
- [ ] Model loaded in app
- [ ] Chat working!

---

## 🎉 Success!

You now have a fully functional sovereign AI assistant running entirely offline on your Android device!

**Next steps:**
- Upload documents to memory
- Explore skills system
- Monitor system performance
- Customize settings

---

**Questions?** Check the [troubleshooting section](#-troubleshooting) or open an issue on GitHub.
