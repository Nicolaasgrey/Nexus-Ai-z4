# Quick Build Reference

## One-Command Setup

```bash
# 1. Fork repo on GitHub, then:
git clone https://github.com/YOUR_USERNAME/NEXUS-Z4.git
cd NEXUS-Z4

# 2. Push to trigger build
git push origin main

# 3. Download APK (after build completes)
gh run download --repo YOUR_USERNAME/NEXUS-Z4 --name nexus-z4-debug-1

# 4. Install
adb install nexus-z4-debug.apk
```

## Build Commands

| Action | Command |
|--------|---------|
| Debug Build | Go to Actions → Build NEXUS Z4 → Run workflow → debug |
| Release Build | Go to Actions → Build NEXUS Z4 → Run workflow → release |
| Create Release | `git tag v1.0.0 && git push origin v1.0.0` |
| Download Latest | `gh run download --repo USER/REPO --name nexus-z4-debug-LATEST` |

## Common Issues

| Issue | Fix |
|-------|-----|
| Build fails | Re-run workflow, check logs |
| APK won't install | `adb uninstall com.nexusz4` then reinstall |
| Model won't load | Check file path, verify GGUF format |

## Links

- **Actions:** `https://github.com/YOUR_USERNAME/NEXUS-Z4/actions`
- **Releases:** `https://github.com/YOUR_USERNAME/NEXUS-Z4/releases`
- **Full Guide:** See [GITHUB_SETUP.md](GITHUB_SETUP.md)
